package dev.zenocl;

import dev.zenocl.command.Commands;
import dev.zenocl.core.ModuleManager;
import dev.zenocl.gui.ClickGui;
import dev.zenocl.util.Project;
import dev.zenocl.hud.HudModule;
import dev.zenocl.modules.combat.KillAura;
import dev.zenocl.core.Module;
import net.fabricmc.api.ClientModInitializer;
import dev.zenocl.modules.combat.AutoCrystal;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientEntityEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class ZenoCL implements ClientModInitializer {
    public static final String MOD_ID = "zenocl";
    private boolean shiftWasDown;

    @Override
    public void onInitializeClient() {
        ModuleManager.init();

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            Project.tick();
            ModuleManager.tick(mc);
            pollGuiKey(mc);
        });

        HudElementRegistry.attachElementAfter(
                VanillaHudElements.CHAT,
                Identifier.of(MOD_ID, "hud"),
                (ctx, tickCounter) -> {
                    MinecraftClient mc = MinecraftClient.getInstance();
                    if (mc.player == null) {
                        return;
                    }
                    ModuleManager.get(KillAura.class).frame();
                    Project.begin(mc, ctx.getScaledWindowWidth(), ctx.getScaledWindowHeight(), tickCounter.getTickProgress(false));
                    if (mc.options.hudHidden) {
                        return;
                    }
                    int sw = ctx.getScaledWindowWidth();
                    int sh = ctx.getScaledWindowHeight();
                    for (Module m : ModuleManager.all()) {
                        if (m instanceof HudModule hud && m.isEnabled()) {
                            hud.draw(ctx, sw, sh);
                        }
                    }
                });

        // Чат-команды: сообщение с префиксом (по умолчанию точка) не уходит на сервер
        ClientSendMessageEvents.ALLOW_CHAT.register(msg -> !Commands.handle(msg));

        // Мгновенный удар по новому кристаллу в тот же тик, когда он появился у клиента
        ClientEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (entity instanceof EndCrystalEntity c) {
                ModuleManager.get(AutoCrystal.class).onSpawn(c);
            }
        });

        ClientLifecycleEvents.CLIENT_STOPPING.register(mc -> ModuleManager.save());
    }

    /** Right Shift открывает ClickGUI (закрывается тем же в самом экране). */
    private void pollGuiKey(MinecraftClient mc) {
        boolean down = GLFW.glfwGetKey(mc.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
        if (down && !shiftWasDown && mc.currentScreen == null && mc.player != null) {
            mc.setScreen(new ClickGui());
        }
        shiftWasDown = down;
    }
}
