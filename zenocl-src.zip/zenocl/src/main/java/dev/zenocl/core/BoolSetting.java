package dev.zenocl.core;

public class BoolSetting extends Setting<Boolean> {
    public BoolSetting(String name, boolean def) {
        super(name, def);
    }

    public void toggle() {
        value = !value;
    }

    @Override
    public String serialize() {
        return Boolean.toString(value);
    }

    @Override
    public void deserialize(String s) {
        value = Boolean.parseBoolean(s);
    }
}
