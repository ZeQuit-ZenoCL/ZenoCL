package dev.zenocl.core;

import dev.zenocl.hud.Notifications;
import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    public final String name;
    public final Category category;
    public final List<Setting<?>> settings = new ArrayList<>();

    boolean keyWasDown;
    private float animValue;
    private long animStamp = System.nanoTime();

    /** Плавная анимация включения (0..1), зависит от времени, а не от числа вызовов. */
    public float anim() {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - animStamp) / 1.0e9f);
        animStamp = now;
        float target = enabled ? 1f : 0f;
        float step = dt * 5f;
        if (animValue < target) {
            animValue = Math.min(target, animValue + step);
        } else if (animValue > target) {
            animValue = Math.max(target, animValue - step);
        }
        return animValue * animValue * (3f - 2f * animValue);
    }

    private boolean enabled;
    private int key;

    protected Module(String name, Category category) {
        this.name = name;
        this.category = category;
    }

    protected static MinecraftClient mc() {
        return MinecraftClient.getInstance();
    }

    protected <S extends Setting<?>> S add(S setting) {
        settings.add(setting);
        return setting;
    }

    /** Модуль без включения (только настройки), например Client. */
    public boolean isSettingsOnly() {
        return false;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void toggle() {
        setEnabled(!enabled);
    }

    public void setEnabled(boolean value) {
        if (value == enabled) {
            return;
        }
        enabled = value;
        if (value) {
            onEnable();
        } else {
            onDisable();
        }
        Notifications.push(name, value);
    }

    /** Загрузка из конфига при старте: без уведомлений и без onEnable (мира ещё нет). */
    public void loadEnabled(boolean value) {
        enabled = value;
    }

    /**
     * Применение состояния из конфига во время игры: вызывает onEnable/onDisable, чтобы модуль
     * не остался в подвешенном состоянии, но без уведомлений (иначе загрузка профиля засыпает экран).
     */
    public void applyEnabled(boolean value) {
        if (value == enabled) {
            return;
        }
        enabled = value;
        if (value) {
            onEnable();
        } else {
            onDisable();
        }
    }

    /** Сбрасывает все настройки модуля (включая служебные, например позицию HUD) к значениям по умолчанию. Бинд и включение не трогает. */
    public void resetSettings() {
        for (Setting<?> s : settings) {
            s.reset();
        }
    }

    public int getKey() {
        return key;
    }

    public void setKey(int key) {
        this.key = key;
    }

    public void onEnable() {
    }

    public void onDisable() {
    }

    public void onTick() {
    }
}
