package dev.zenocl.core;

public class NumSetting extends Setting<Double> {
    public final double min;
    public final double max;
    public final double step;

    public NumSetting(String name, double def, double min, double max, double step) {
        super(name, def);
        this.min = min;
        this.max = max;
        this.step = step;
    }

    @Override
    public void set(Double v) {
        double x = v;
        if (step > 0) {
            x = Math.round((x - min) / step) * step + min;
        }
        value = Math.max(min, Math.min(max, x));
    }

    public float getFloat() {
        return value.floatValue();
    }

    public int getInt() {
        return (int) Math.round(value);
    }

    public double progress() {
        return (value - min) / (max - min);
    }

    @Override
    public String serialize() {
        return Double.toString(value);
    }

    @Override
    public void deserialize(String s) {
        try {
            double d = Double.parseDouble(s.trim());
            // NaN/Infinity из битого конфига испортили бы значение навсегда (clamp их не лечит)
            if (Double.isFinite(d)) {
                set(d);
            }
        } catch (NumberFormatException ignored) {
        }
    }
}
