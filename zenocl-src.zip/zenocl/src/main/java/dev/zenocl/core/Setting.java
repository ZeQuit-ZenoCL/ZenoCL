package dev.zenocl.core;

public abstract class Setting<T> {
    public final String name;
    protected T value;
    private final T def;
    /** Служебная настройка (позиции HUD): хранится в конфиге, но не показывается в панели настроек. */
    public boolean hidden;

    protected Setting(String name, T value) {
        this.name = name;
        this.value = value;
        this.def = value;
    }

    /** Возвращает значение по умолчанию (то, что задано в конструкторе). */
    public void reset() {
        value = def;
    }

    public T get() {
        return value;
    }

    public void set(T value) {
        this.value = value;
    }

    public abstract String serialize();

    public abstract void deserialize(String s);
}
