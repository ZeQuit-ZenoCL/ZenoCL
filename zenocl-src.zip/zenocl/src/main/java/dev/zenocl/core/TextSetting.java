package dev.zenocl.core;

/** Текстовая настройка без строки в панели (правится чат-командой). Переводы строк хранятся как \\n. */
public class TextSetting extends Setting<String> {
    public TextSetting(String name, String def) {
        super(name, def);
        hidden = true;
    }

    @Override
    public String serialize() {
        return value.replace("\n", "\\n");
    }

    @Override
    public void deserialize(String s) {
        value = s.replace("\\n", "\n");
    }
}
