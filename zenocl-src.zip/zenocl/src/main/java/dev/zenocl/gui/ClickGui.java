package dev.zenocl.gui;

import dev.zenocl.core.BoolSetting;
import dev.zenocl.core.Category;
import dev.zenocl.core.ModeSetting;
import dev.zenocl.core.Module;
import dev.zenocl.core.ModuleManager;
import dev.zenocl.core.NumSetting;
import dev.zenocl.core.Setting;
import dev.zenocl.hud.Graphics;
import dev.zenocl.hud.Logo;
import dev.zenocl.hud.Render;
import dev.zenocl.hud.Theme;
import dev.zenocl.modules.misc.ClientSettings;
import dev.zenocl.util.Friends;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * ClickGUI ZenoCL: сайдбар с категориями, поиск, секции в два столбца, всплывающая панель настроек.
 * Тёмно-алая тема, дешёвая отрисовка (только прямоугольники, аура из нескольких статичных слоёв).
 */
public class ClickGui extends Screen {
    private static final int SIDE = 132;
    private static final int ROW = 19;
    private static final int RH = 30;
    private static final int SR = 24;
    private static final int HEAD = 21;
    private static final int PAGE_PRESETS = 5;
    private static final int PAGE_CONFIG = 6;
    private static final int PAGE_GRAPHICS = 8;
    private static final int SEARCH_SCROLL = 7;
    private static final int DIM = 0xFF8D868C;
    private static final int FAINT = 0xFF5A5358;
    private static final int[] SEARCH_KEYS = searchKeys();

    private int page = 0;
    private final float[] scroll = new float[9];
    private float maxScroll;

    private Module expanded;
    private final java.util.Map<Object, Float> expandAnim = new java.util.IdentityHashMap<>();
    private final java.util.Map<Object, Float> hoverAnim = new java.util.IdentityHashMap<>();
    // прозрачность панелей на текущем кадре: открытие окна * профиль графики (читает tint)
    private static float galpha = 1f;
    private static float gOpen = 1f;
    private long closingAt;
    private final float[] shownScroll = new float[9];
    private final float[] selAnim = new float[9];
    private final java.util.Map<Object, Float> switchAnim = new java.util.IdentityHashMap<>();
    private final long openedAt = System.nanoTime();
    private long lastFrame = System.nanoTime();
    private float frameDt;
    private int lastView = -1;
    private long viewAt = System.nanoTime();

    private dev.zenocl.hud.HudModule hudDrag;
    private int hudDragX;
    private int hudDragY;
    private Module hoverCard;
    private Module tipMod;
    private long tipSince;
    private Module listening;
    private NumSetting dragging;
    private int dragX;
    private int dragW;

    private boolean searching;
    private final StringBuilder query = new StringBuilder();
    private final boolean[] prevKey = new boolean[GLFW.GLFW_KEY_LAST + 1];

    private boolean prevL;
    private boolean prevR;
    private boolean prevM;
    private boolean prevShift = true;
    private boolean prevEsc;
    private int mx;
    private int my;
    private boolean cl;
    private boolean cr;
    private boolean cm;

    private String toast = "";
    private boolean toastOk = true;
    private long toastAt;

    // страница "Конфиг": кэш списка профилей (чтение диска не на каждом кадре), поле имени, подтверждение удаления
    private List<String> profileCache = new ArrayList<>();
    private boolean profilesDirty = true;
    private boolean naming;
    private final StringBuilder profileName = new StringBuilder();
    private String confirmDelete = "";
    private long confirmAt;
    private boolean prevEnter;

    public ClickGui() {
        super(Text.literal("ZenoCL"));
    }

    private static int[] searchKeys() {
        int[] k = new int[26 + 10 + 3];
        int n = 0;
        for (int c = GLFW.GLFW_KEY_A; c <= GLFW.GLFW_KEY_Z; c++) {
            k[n++] = c;
        }
        for (int c = GLFW.GLFW_KEY_0; c <= GLFW.GLFW_KEY_9; c++) {
            k[n++] = c;
        }
        k[n++] = GLFW.GLFW_KEY_SPACE;
        k[n++] = GLFW.GLFW_KEY_MINUS;
        k[n] = GLFW.GLFW_KEY_BACKSPACE;
        return k;
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return listening == null && !searching && !naming;
    }

    /** Закрытие идёт через короткую анимацию: реальный close() вызывается из render(). */
    @Override
    public void close() {
        if (closingAt == 0) {
            closingAt = System.nanoTime();
        }
    }

    @Override
    public void removed() {
        ModuleManager.save();
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontal, double vertical) {
        int i = query.length() > 0 ? SEARCH_SCROLL : page;
        scroll[i] = Math.max(0f, Math.min(maxScroll, scroll[i] - (float) vertical * 18f));
        return true;
    }

    // ------------------------------------------------------------------ цвета

    private static int tint(float f) {
        int a = Math.max(0, Math.min(255, (int) (255 * galpha)));
        return (a << 24) | (Theme.dark(f) & 0xFFFFFF);
    }

    private static int acc() {
        return Render.accent(0);
    }

    private static boolean in(int px, int py, int x, int y, int w, int h) {
        return px >= x && px < x + w && py >= y && py < y + h;
    }

    // ------------------------------------------------------------------ главный цикл

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        long nowN = System.nanoTime();
        frameDt = Math.min(0.05f, (nowN - lastFrame) / 1.0e9f);
        lastFrame = nowN;
        float openSec = Math.max(0.001f, Graphics.openSeconds());
        float open = ease(Math.min(1f, (nowN - openedAt) / (openSec * 1.0e9f)));
        if (closingAt != 0) {
            float cp = (nowN - closingAt) / (openSec * 0.75f * 1.0e9f);
            if (cp >= 1f) {
                super.close();
                return;
            }
            open = Math.min(open, 1f - ease(cp));
        }
        int view = query.length() > 0 ? SEARCH_SCROLL : page;
        if (view != lastView) {
            lastView = view;
            viewAt = nowN;
            if (view == PAGE_CONFIG) {
                profilesDirty = true; // файлы могли измениться снаружи или чат-командой
            }
        }
        // экспоненциальное сглаживание: от частоты кадров не зависит
        float k = 1f - (float) Math.exp(-frameDt * Graphics.scrollSharpness());
        gOpen = open;
        galpha = open * Graphics.panelAlpha();
        for (int i = 0; i < shownScroll.length; i++) {
            shownScroll[i] += (scroll[i] - shownScroll[i]) * k;
        }

        long win = MinecraftClient.getInstance().getWindow().getHandle();
        boolean l = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean r = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        boolean m = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_MIDDLE) == GLFW.GLFW_PRESS;
        cl = l && !prevL;
        cr = r && !prevR;
        cm = m && !prevM;
        prevL = l;
        prevR = r;
        prevM = m;
        mx = mouseX;
        my = mouseY;

        boolean shift = GLFW.glfwGetKey(win, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
        if (shift && !prevShift && listening == null && !naming) {
            prevShift = true;
            close();
            return;
        }
        prevShift = shift;

        pollKeys(win);
        if (hudDrag != null) {
            if (!l || !hudDrag.isEnabled()) {
                hudDrag = null;
            } else {
                // меню скрыто: элемент HUD виден на экране и едет за курсором
                hudDrag.moveTo(mx - hudDragX, my - hudDragY, width, height);
                String hint = "Отпусти ЛКМ, чтобы закрепить";
                Render.text(ctx, hint, width / 2 - Render.width(hint) / 2, 8, 0xFFFFFFFF);
                return;
            }
        }
        if (dragging != null) {
            if (!l) {
                dragging = null;
            } else {
                double t = Math.max(0, Math.min(1, (mx - dragX) / (double) dragW));
                dragging.set(dragging.min + t * (dragging.max - dragging.min));
            }
        }

        int w = Math.min(560, width - 12);
        int h = Math.min(380, height - 12);
        int x0 = (width - w) / 2;
        int y0 = (height - h) / 2 + (int) ((1f - open) * 18f);

        ctx.fill(0, 0, width, height, ((int) (0x77 * open) << 24));
        drawWindow(ctx, x0, y0, w, h);
        drawParticles(ctx, x0, y0, w, h);
        drawSidebar(ctx, x0, y0, h);
        drawContent(ctx, x0 + SIDE + 10, y0, w - SIDE - 20, h);
        drawTooltip(ctx);
        hoverCard = null;

    }

    private void drawWindow(DrawContext ctx, int x0, int y0, int w, int h) {
        // аура: несколько статичных полупрозрачных слоёв с лёгкой пульсацией
        float pulse = Graphics.pulse() ? (float) (0.8 + 0.2 * Math.sin(System.currentTimeMillis() / 900.0)) : 1f;
        int a = acc();
        int layers = Graphics.auraLayers();
        for (int i = layers; i >= 1; i--) {
            Render.rrect(ctx, x0 - i * 3, y0 - i * 3, w + i * 6, h + i * 6, Render.withAlpha(a, gOpen * 0.05f * pulse / (i * 0.8f)));
        }
        Render.rrect(ctx, x0 - 1, y0 - 1, w + 2, h + 2, Render.withAlpha(a, 0.5f * gOpen));
        Render.rrect(ctx, x0, y0, w, h, tint(0.055f));
        if (Graphics.headerGradient()) {
            ctx.fillGradient(x0 + 2, y0 + 2, x0 + w - 2, y0 + 52, Render.withAlpha(a, 0.13f * gOpen), Render.withAlpha(a, 0f));
        }
        ctx.fill(x0 + SIDE, y0 + 10, x0 + SIDE + 1, y0 + h - 10, 0x14FFFFFF);
        if (y0 >= 12) {
            String t = "Меню";
            Render.text(ctx, t, x0 + w / 2 - Render.width(t) / 2, y0 - 11, DIM);
        }
    }

    /** Медленно всплывающие точки. Позиция считается из времени, поэтому состояния нет и кадр почти бесплатный. */
    private void drawParticles(DrawContext ctx, int x0, int y0, int w, int h) {
        int n = Graphics.particles();
        if (n == 0) {
            return;
        }
        double t = System.currentTimeMillis() / 1000.0;
        for (int i = 0; i < n; i++) {
            double fx = (i * 0.6180339887) % 1.0;
            double fy = (i * 0.7548776662) % 1.0;
            double speed = 0.012 + 0.02 * ((i * 0.3819660113) % 1.0);
            double py = ((fy - t * speed) % 1.0 + 1.0) % 1.0;
            double px = fx + Math.sin(t * 0.5 + i) * 0.012;
            float tw = (float) (0.5 + 0.5 * Math.sin(t * 1.3 + i * 1.7));
            // у верхнего и нижнего края гаснут, чтобы не появлялись из ниоткуда
            float edge = (float) Math.min(1.0, Math.min(py, 1.0 - py) * 8.0);
            int sz = i % 3 == 0 ? 2 : 1;
            int x = x0 + 4 + (int) (px * (w - 8));
            int y = y0 + 4 + (int) (py * (h - 8));
            ctx.fill(x, y, x + sz, y + sz, Render.withAlpha(acc(), (0.10f + 0.22f * tw) * edge * gOpen));
        }
    }

    // ------------------------------------------------------------------ сайдбар

    private static final String[] CAT_TITLES = {"Бой", "Движение", "Визуалы", "Игрок", "Разное"};

    private void drawSidebar(DrawContext ctx, int x0, int y0, int h) {
        Logo.draw(ctx, x0 + 27, y0 + 30, 26f);
        Render.text(ctx, "ZENOCL", x0 + 50, y0 + 21, 0xFFFFFFFF);
        Render.text(ctx, "2.0 · HvH", x0 + 50, y0 + 33, FAINT);

        Render.text(ctx, "ФУНКЦИИ", x0 + 18, y0 + 62, FAINT);
        int y = y0 + 76;
        for (int i = 0; i < Category.values().length; i++) {
            sideItem(ctx, x0, y, i, CAT_TITLES[i]);
            y += 24;
        }
        y += 10;
        Render.text(ctx, "УПРАВЛЕНИЕ", x0 + 18, y, FAINT);
        y += 14;
        sideItem(ctx, x0, y, PAGE_PRESETS, "Пресеты");
        y += 24;
        sideItem(ctx, x0, y, PAGE_CONFIG, "Конфиг");
        y += 24;
        sideItem(ctx, x0, y, PAGE_GRAPHICS, "Графика");

        // профиль внизу
        String name = MinecraftClient.getInstance().getSession().getUsername();
        int py = y0 + h - 40;
        Render.rrect(ctx, x0 + 10, py, SIDE - 20, 30, Render.withAlpha(0xFFFFFFFF, 0.05f * gOpen));
        Render.rrect(ctx, x0 + 15, py + 5, 20, 20, Render.withAlpha(acc(), 0.30f));
        String ini = name.isEmpty() ? "?" : name.substring(0, 1).toUpperCase();
        Render.text(ctx, ini, x0 + 25 - Render.width(ini) / 2, py + 11, 0xFFFFFFFF);
        Render.text(ctx, fit(name, SIDE - 56), x0 + 42, py + 7, 0xFFE8E2E6);
        Render.text(ctx, "1.21.11", x0 + 42, py + 17, FAINT);
    }

    /** Полоса, плавно гаснущая слева направо: дешёвая замена горизонтального градиента. */
    private static void hfade(DrawContext ctx, int x, int y, int w, int h, int color, float alpha) {
        int n = 14;
        int sw = Math.max(1, w / n);
        for (int i = 0; i < n; i++) {
            float k = 1f - i / (float) n;
            int x2 = i == n - 1 ? x + w : x + (i + 1) * sw;
            ctx.fill(x + i * sw, y, x2, y + h, Render.withAlpha(color, alpha * k * k * gOpen));
        }
    }

    private void sideItem(DrawContext ctx, int x0, int y, int idx, String title) {
        boolean sel = page == idx && query.length() == 0;
        boolean hover = in(mx, my, x0 + 8, y, SIDE - 16, 22);
        selAnim[idx] += ((sel ? 1f : 0f) - selAnim[idx]) * (1f - (float) Math.exp(-frameDt * 14f));
        float sa = selAnim[idx];
        if (sa > 0.02f) {
            hfade(ctx, x0 + 8, y, SIDE - 16, 22, acc(), 0.34f * sa);
            Render.rrect(ctx, x0 + 3, y + 4, 3, 14, Render.withAlpha(acc(), sa));
            Render.rrect(ctx, x0 + 2, y + 3, 5, 16, Render.withAlpha(acc(), 0.22f * sa));
        } else if (hover) {
            Render.rrect(ctx, x0 + 8, y, SIDE - 16, 22, 0x10FFFFFF);
        }
        int col = Render.lerp(hover ? 0xFFFFFFFF : DIM, 0xFFFFFFFF, sa);
        Render.text(ctx, title, x0 + 18 + (int) (sa * 3), y + 7, col);
        if (hover && cl) {
            page = idx;
            searching = false;
            naming = false;
            query.setLength(0);
        }
    }

    private void drawContent(DrawContext ctx, int cx, int y0, int cw, int h) {
        drawSearch(ctx, cx + cw - 150, y0 + 14, 150);
        drawTitle(ctx, cx + 2, y0 + 12);

        int cy = y0 + 48;
        int ch = h - 56;
        boolean results = query.length() > 0;
        int si = results ? SEARCH_SCROLL : page;
        boolean inClip = in(mx, my, cx - 2, cy, cw + 4, ch);

        float viewEase = ease(Math.min(1f, (System.nanoTime() - viewAt) / 2.0e8f));
        int off = Math.round(shownScroll[si]) - (int) ((1f - viewEase) * 14f);
        int[] colY = {cy - off, cy - off};
        ctx.enableScissor(cx - 2, cy, cx + cw + 2, cy + ch);
        if (!results && page == PAGE_PRESETS) {
            drawPresets(ctx, cx, cy - off, cw, inClip, colY);
        } else if (!results && page == PAGE_CONFIG) {
            drawConfig(ctx, cx, cy - off, cw, inClip, colY);
        } else if (!results && page == PAGE_GRAPHICS) {
            drawGraphics(ctx, cx, cy - off, cw, inClip, colY);
        } else {
            drawModules(ctx, cx, cy, ch, cw, inClip, results, colY);
        }
        ctx.disableScissor();

        float total = Math.max(colY[0], colY[1]) - (cy - off) - 8;
        maxScroll = Math.max(0, total - ch);
        scroll[si] = Math.min(scroll[si], maxScroll);
    }

    private void drawTitle(DrawContext ctx, int x, int y) {
        boolean results = query.length() > 0;
        String title = results ? "Поиск" : page < CAT_TITLES.length ? CAT_TITLES[page]
                : page == PAGE_PRESETS ? "Пресеты" : page == PAGE_CONFIG ? "Конфиг" : "Графика";
        var m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(x, y);
        m.scale(1.7f, 1.7f);
        Render.text(ctx, title, 0, 0, Render.withAlpha(0xFFFFFFFF, gOpen));
        m.popMatrix();
        String sub = "";
        if (!results && page < CAT_TITLES.length) {
            int total = 0;
            int on = 0;
            for (Module mod : ModuleManager.byCategory(Category.values()[page])) {
                total++;
                if (mod.isEnabled()) {
                    on++;
                }
            }
            sub = total + " модулей · " + on + " включено";
        }
        Render.text(ctx, sub, x + 1, y + 21, FAINT);
    }

    private void drawSearch(DrawContext ctx, int cx, int sy, int cw) {
        int sbw = cw;
        boolean hover = in(mx, my, cx, sy, sbw, 20);
        if (searching) {
            Render.rrect(ctx, cx - 1, sy - 1, sbw + 2, 22, Render.withAlpha(acc(), 0.55f));
        }
        Render.rrect(ctx, cx, sy, sbw, 20, tint(searching ? 0.16f : 0.11f));
        // лупа
        int lx = cx + 8, ly = sy + 6;
        int c = searching ? acc() : FAINT;
        ctx.fill(lx + 1, ly, lx + 4, ly + 1, c);
        ctx.fill(lx + 1, ly + 4, lx + 4, ly + 5, c);
        ctx.fill(lx, ly + 1, lx + 1, ly + 4, c);
        ctx.fill(lx + 4, ly + 1, lx + 5, ly + 4, c);
        ctx.fill(lx + 5, ly + 5, lx + 7, ly + 7, c);

        String text;
        int tc;
        if (query.length() == 0 && !searching) {
            text = "Поиск";
            tc = FAINT;
        } else {
            boolean caret = searching && (System.currentTimeMillis() / 450) % 2 == 0;
            text = query + (caret ? "|" : "");
            tc = 0xFFFFFFFF;
        }
        Render.text(ctx, text, cx + 22, sy + 6, tc);

        if (cl) {
            searching = hover;
            if (hover) {
                listening = null;
            }
        }
    }

    private static String sectionOf(Module m) {
        return switch (m.name) {
            case "KillAura", "TriggerBot", "AimAssist", "Criticals" -> "Драка";
            case "AutoCrystal" -> "Кристаллы";
            case "AutoTotem", "AutoGapple", "Velocity" -> "Защита";
            case "AntiBot", "Surround", "AutoLog", "AutoPot", "AutoXP", "PearlThrow" -> "Тактика";
            case "BowAim" -> "Дальний бой";
            case "Sprint", "Speed", "TargetStrafe" -> "Скорость";
            case "Fly", "Glide" -> "Полёт";
            case "Jesus", "Spider", "Step", "AutoWalk" -> "Перемещение";
            case "Bhop", "Strafe", "HighJump", "AirJump", "FastFall", "AntiVoid", "NoFall" -> "Прыжки";
            case "ESP", "Tracers", "Arrows" -> "ESP и цели";
            case "Fullbright", "Zoom", "LowHealth" -> "Эффекты экрана";
            case "Watermark", "Info", "Session", "CPS", "FpsGraph", "Compass" -> "Информация";
            case "ArrayList", "Notifications", "TargetInfo", "Potions", "ArmorHUD", "Inventory", "Keystrokes", "Radar" -> "Панели";
            case "AutoArmor", "ChestStealer", "AutoEat" -> "Инвентарь";
            case "FastPlace", "AutoRespawn", "AutoSneak", "AutoMine", "MiddleClickFriend" -> "Действия";
            case "Client" -> "Клиент";
            case "AntiAFK", "Spammer", "Panic" -> "Прочее";
            default -> m.category == Category.VISUAL ? "HUD" : "Прочее";
        };
    }

    private void drawModules(DrawContext ctx, int cx, int cy, int ch, int cw, boolean inClip, boolean results, int[] colY) {
        Map<String, List<Module>> secs = new LinkedHashMap<>();
        if (results) {
            String q = query.toString().toLowerCase();
            List<Module> found = new ArrayList<>();
            for (Module m : ModuleManager.all()) {
                if (m.name.toLowerCase().contains(q) || ModuleInfo.of(m.name).toLowerCase().contains(q)) {
                    found.add(m);
                }
            }
            if (!found.isEmpty()) {
                secs.put("Результаты", found);
            }
        } else {
            for (Module m : ModuleManager.byCategory(Category.values()[page])) {
                secs.computeIfAbsent(sectionOf(m), k -> new ArrayList<>()).add(m);
            }
        }
        if (secs.isEmpty()) {
            Render.text(ctx, "Ничего не найдено", cx + 4, cy + 6, FAINT);
            return;
        }

        int y = Math.max(colY[0], colY[1]);
        for (Map.Entry<String, List<Module>> e : secs.entrySet()) {
            String title = e.getKey().toUpperCase();
            if (y + 14 >= cy && y <= cy + ch) {
                Render.text(ctx, title, cx + 4, y + 2, acc());
                ctx.fill(cx + 4 + Render.width(title) + 6, y + 6, cx + cw - 4, y + 7, 0x14FFFFFF);
            }
            y += 16;
            for (Module mod : e.getValue()) {
                y += drawModuleRow(ctx, mod, cx, y, cw, inClip, cy, ch);
            }
            y += 6;
        }
        colY[0] = y;
        colY[1] = y;
    }

    private static float ease3(float v) {
        return v * v * (3f - 2f * v);
    }

    /** Строка модуля: название, описание, бинд, переключатель, стрелка. Раскрытие настроек плавно выдвигается под строкой. */
    private int drawModuleRow(DrawContext ctx, Module mod, int x, int y, int w, boolean inClip, int cy, int ch) {
        float ex = expandAnim.getOrDefault(mod, 0f);
        float tgt = expanded == mod ? 1f : 0f;
        ex = ex < tgt ? Math.min(tgt, ex + frameDt * 7f) : Math.max(tgt, ex - frameDt * 7f);
        if (!Graphics.popupAnim()) {
            ex = tgt; // профиль графики Low: раскрытие без анимации
        }
        expandAnim.put(mod, ex);
        int sh = (int) (settingsHeight(mod) * ease3(ex));
        int total = RH + sh;
        if (y + total < cy || y > cy + ch) {
            return total + 4;
        }
        boolean only = mod.isSettingsOnly();
        float a = only ? 0f : mod.anim();
        boolean hover = inClip && in(mx, my, x, y, w, RH);
        float hv = hoverAmt(mod, hover);
        if (hover) {
            hoverCard = mod;
        }
        if (sh > 0) {
            Render.rrect(ctx, x, y, w, total, Render.withAlpha(0xFFFFFFFF, 0.04f * gOpen));
        }
        if (hv > 0.01f) {
            Render.rrect(ctx, x, y, w, RH, Render.withAlpha(0xFFFFFFFF, 0.04f * hv * gOpen));
        }
        if (a > 0.01f) {
            hfade(ctx, x, y, w, RH, acc(), 0.30f * a);
            Render.rrect(ctx, x, y + 7, 3, RH - 14, Render.withAlpha(acc(), a));
            Render.rrect(ctx, x - 1, y + 5, 5, RH - 10, Render.withAlpha(acc(), 0.22f * a));
        }
        Render.text(ctx, mod.name, x + 14 + (int) (a * 2), y + 11, Render.lerp(0xFFB5ADB9, 0xFFFFFFFF, Math.max(a, hv * 0.6f)));
        int rightW = 92;
        String info = ModuleInfo.of(mod.name);
        Render.text(ctx, fit(info, w - 118 - rightW), x + 118, y + 11, Render.lerp(FAINT, DIM, a));

        int px = x + w - 52;
        if (!only) {
            pill(ctx, px, y + 9, 24, 12, a);
        }
        if (mod.getKey() != 0) {
            String kn = keyName(mod.getKey());
            int kw = Render.width(kn) + 8;
            int kx = (only ? x + w - 28 : px - 8) - kw;
            Render.rrect(ctx, kx, y + 8, kw, 14, Render.withAlpha(acc(), 0.16f * gOpen));
            Render.text(ctx, kn, kx + 4, y + 11, Render.withAlpha(acc(), 0.95f));
        }
        boolean chevHover = hover && mx >= x + w - 24;
        Render.text(ctx, ex > 0.5f ? "^" : "v", x + w - 16, y + 11, chevHover || ex > 0.5f ? acc() : FAINT);

        if (hover) {
            if (cl) {
                if (only || mx >= x + w - 24) {
                    expanded = expanded == mod ? null : mod;
                } else {
                    mod.toggle();
                }
            } else if (cr) {
                expanded = expanded == mod ? null : mod;
            } else if (cm) {
                listening = mod;
                searching = false;
            }
        }
        if (sh > 1) {
            ctx.enableScissor(x, y + RH, x + w, y + RH + sh);
            drawSettings(ctx, mod, x, y + RH, w, inClip && ex > 0.6f, y + RH + sh);
            ctx.disableScissor();
        }
        return total + 4;
    }

    private int settingsHeight(Module m) {
        int h = 8 + SR + 30;
        if (m instanceof dev.zenocl.hud.HudModule hm && hm.movable()) {
            h += SR;
        }
        for (Setting<?> s : m.settings) {
            if (s.visible()) {
                h += SR;
            }
        }
        return h;
    }

    /** Настройки модуля внутри раскрытой строки; act - можно ли с ними взаимодействовать, lim - нижняя граница видимой части. */
    private void drawSettings(DrawContext ctx, Module m, int x, int y, int w, boolean act, int lim) {
        int ix = x + 14;
        int iw = w - 28;
        y += 8;
        // бинд
        {
            boolean hov = act && my < lim && in(mx, my, x, y, w, SR);
            boolean wait = listening == m;
            String v = wait ? "нажми клавишу..." : keyName(m.getKey());
            Render.text(ctx, "Bind", ix, y + 8, 0xFFCFC9CD);
            int bw = Render.width(v) + 14;
            Render.rrect(ctx, ix + iw - bw, y + 4, bw, 16, Render.withAlpha(acc(), (hov || wait ? 0.32f : 0.18f) * gOpen));
            Render.text(ctx, v, ix + iw - bw + 7, y + 8, wait ? 0xFFFFFFFF : acc());
            if (hov && cl) {
                listening = m;
                searching = false;
            }
            y += SR;
        }
        if (m instanceof dev.zenocl.hud.HudModule hm && hm.movable()) {
            int bw = (iw - 6) / 2;
            boolean can = hm.isEnabled() && hm.fresh();
            boolean h1 = act && can && my < lim && in(mx, my, ix, y + 2, bw, 20);
            Render.rrect(ctx, ix, y + 2, bw, 20, h1 ? Render.withAlpha(acc(), 0.32f) : tint(0.16f));
            String mv = can ? "Переместить" : "Включи модуль";
            Render.text(ctx, mv, ix + bw / 2 - Render.width(mv) / 2, y + 8, can ? (h1 ? 0xFFFFFFFF : DIM) : FAINT);
            if (h1 && cl) {
                hudDrag = hm;
                hudDragX = mx - hm.bx();
                hudDragY = my - hm.by();
            }
            boolean h2 = act && my < lim && in(mx, my, ix + bw + 6, y + 2, bw, 20);
            Render.rrect(ctx, ix + bw + 6, y + 2, bw, 20, h2 ? Render.withAlpha(acc(), 0.32f) : tint(0.16f));
            String rp = "Позиция по умолч.";
            Render.text(ctx, fit(rp, bw - 6), ix + bw + 6 + bw / 2 - Render.width(fit(rp, bw - 6)) / 2, y + 8, h2 ? 0xFFFFFFFF : DIM);
            if (h2 && cl) {
                hm.resetPos();
            }
            y += SR;
        }
        for (Setting<?> st : m.settings) {
            if (!st.visible()) {
                continue;
            }
            boolean hov = act && my < lim && in(mx, my, x, y, w, SR);
            Render.text(ctx, st.name, ix, y + 8, hov ? 0xFFFFFFFF : 0xFFCFC9CD);
            if (st instanceof BoolSetting b) {
                pill(ctx, ix + iw - 24, y + 6, 24, 12, boolAnim(b));
                if (hov && cl) {
                    b.toggle();
                }
            } else if (st instanceof ModeSetting ms) {
                String v = ms.get();
                int bw = Render.width(v) + 16;
                Render.rrect(ctx, ix + iw - bw, y + 4, bw, 16, Render.withAlpha(acc(), (hov ? 0.30f : 0.16f) * gOpen));
                Render.text(ctx, v, ix + iw - bw + 8, y + 8, acc());
                if (hov && cl) {
                    ms.cycle();
                }
            } else if (st instanceof NumSetting n) {
                String v = n.step >= 1 ? Integer.toString(n.getInt()) : String.format("%.2f", n.get());
                int tx = ix + 104;
                int tw = Math.max(20, iw - 104 - 44);
                int ty = y + 10;
                Render.rrect(ctx, tx, ty, tw, 4, 0xFF2D2528);
                int fill = (int) (tw * n.progress());
                ctx.fillGradient(tx, ty, tx + Math.max(2, fill), ty + 4, Render.accent(0), Render.accent(1.5));
                Render.rrect(ctx, tx + fill - 4, ty - 2, 8, 8, 0xFFFFFFFF);
                Render.text(ctx, v, ix + iw - Render.width(v), y + 8, 0xFFFFFFFF);
                if (hov && cl && mx >= tx - 6) {
                    dragging = n;
                    dragX = tx;
                    dragW = tw;
                }
            }
            y += SR;
        }
        boolean hov = act && my < lim && in(mx, my, ix, y + 6, iw, 18);
        Render.rrect(ctx, ix, y + 6, iw, 18, hov ? Render.withAlpha(0xFFE5484D, 0.32f) : tint(0.16f));
        String label = "Сбросить настройки";
        Render.text(ctx, label, ix + iw / 2 - Render.width(label) / 2, y + 11, hov ? 0xFFFFFFFF : DIM);
        if (hov && cl) {
            m.resetSettings();
        }
    }

    /** Подсказка: через 3 секунды неподвижного наведения на карточку плавно появляется полное описание. */
    private void drawTooltip(DrawContext ctx) {
        long now = System.currentTimeMillis();
        if (hoverCard != tipMod) {
            tipMod = hoverCard;
            tipSince = now;
        }
        if (tipMod == null || expanded == tipMod || now - tipSince < 3000) {
            return;
        }
        String text = ModuleInfo.of(tipMod.name);
        if (text.isEmpty()) {
            return;
        }
        float f = Math.min(1f, (now - tipSince - 3000) / 200f);
        int w = Render.width(text) + 16;
        int x = Math.max(4, Math.min(width - w - 4, mx + 10));
        int y = Math.max(4, Math.min(height - 40, my + 14 - (int) ((1f - f) * -4)));
        Render.rrect(ctx, x - 1, y - 1, w + 2, 36, Render.withAlpha(acc(), 0.35f * f));
        Render.rrect(ctx, x, y, w, 34, ((int) (0xF2 * f) << 24) | (Theme.dark(0.07f) & 0xFFFFFF));
        Render.text(ctx, tipMod.name, x + 8, y + 6, Render.withAlpha(acc(), f));
        Render.text(ctx, text, x + 8, y + 19, Render.withAlpha(0xFFE8E2E6, f));
    }

    /** Плавное значение наведения 0..1; на профиле Low включается мгновенно. */
    private float hoverAmt(Object key, boolean hover) {
        float target = hover ? 1f : 0f;
        if (!Graphics.hoverFade()) {
            return target;
        }
        float v = hoverAnim.getOrDefault(key, 0f);
        v += (target - v) * (1f - (float) Math.exp(-frameDt * 18f));
        hoverAnim.put(key, v);
        return v;
    }


    private static void chevron(DrawContext ctx, int x, int y, int c) {
        ctx.fill(x + 2, y, x + 3, y + 1, c);
        ctx.fill(x + 1, y + 1, x + 4, y + 2, c);
        ctx.fill(x, y + 2, x + 5, y + 3, c);
        ctx.fill(x, y + 5, x + 5, y + 6, c);
        ctx.fill(x + 1, y + 6, x + 4, y + 7, c);
        ctx.fill(x + 2, y + 7, x + 3, y + 8, c);
    }

    private static float ease(float t) {
        float u = 1f - t;
        return 1f - u * u * u * u * u;
    }

    /** Плавное значение переключателя настройки 0..1 со сглаженной кривой. */
    private float boolAnim(BoolSetting b) {
        float target = b.get() ? 1f : 0f;
        float v = switchAnim.getOrDefault(b, target);
        float step = frameDt * 6f;
        v = v < target ? Math.min(target, v + step) : Math.max(target, v - step);
        switchAnim.put(b, v);
        return v * v * (3f - 2f * v);
    }

    private static void pill(DrawContext ctx, int x, int y, int w, int h, float a) {
        Render.rrect(ctx, x, y, w, h, Render.lerp(0xFF2D2528, acc(), a));
        int k = h - 4;
        int stretch = (int) (Math.sin(Math.PI * a) * 3);
        int kx = x + 2 + (int) ((w - k - 4 - stretch) * a);
        ctx.fill(kx, y + 2, kx + k + stretch, y + 2 + k, 0xFFFFFFFF);
    }

    // ------------------------------------------------------------------ страницы "Пресеты" и "Конфиг"

    private void drawPresets(DrawContext ctx, int cx, int top, int cw, boolean inClip, int[] colY) {
        String[] names = Theme.names();
        String current = ClientSettings.INSTANCE.theme.get();
        int rows = (names.length + 1) / 2;
        int ph = HEAD + rows * 33 + 4;
        Render.rrect(ctx, cx, top, cw, ph, tint(0.105f));
        Render.text(ctx, "Темы", cx + 10, top + 6, acc());
        chevron(ctx, cx + cw - 15, top + 5, acc());

        int cardW = (cw - 26) / 2;
        for (int i = 0; i < names.length; i++) {
            int x = cx + 9 + (i % 2) * (cardW + 8);
            int y = top + HEAD + (i / 2) * 33;
            boolean sel = names[i].equalsIgnoreCase(current);
            boolean hover = inClip && in(mx, my, x, y, cardW, 28);
            if (sel) {
                Render.rrect(ctx, x - 1, y - 1, cardW + 2, 30, Render.withAlpha(acc(), 0.7f));
            }
            Render.rrect(ctx, x, y, cardW, 28, tint(hover ? 0.19f : 0.14f));
            swatch(ctx, names[i], x + 8, y + 9);
            Render.text(ctx, names[i], x + 34, y + 10, sel ? 0xFFFFFFFF : DIM);
            if (hover && cl) {
                ClientSettings.INSTANCE.theme.deserialize(names[i]);
            }
        }
        int y = top + ph + 8;
        int rh = ROW * 1 + 8;
        Render.rrect(ctx, cx, y, cw, rh, tint(0.105f));
        drawRow(ctx, ClientSettings.INSTANCE, cx, y + 4, cw, inClip, false);
        colY[0] = y + rh + 8;
        colY[1] = colY[0];
    }

    private static void swatch(DrawContext ctx, String name, int x, int y) {
        for (Theme.T t : Theme.all()) {
            if (!t.name().equals(name)) {
                continue;
            }
            if (Theme.rainbow(t)) {
                for (int i = 0; i < 6; i++) {
                    ctx.fill(x + i * 3, y, x + i * 3 + 3, y + 10, Theme.hsv(i / 6f, 0.6f, 1f));
                }
            } else {
                ctx.fill(x, y, x + 9, y + 10, t.a());
                ctx.fill(x + 9, y, x + 18, y + 10, t.b());
            }
            return;
        }
    }

    private void drawGraphics(DrawContext ctx, int cx, int top, int cw, boolean inClip, int[] colY) {
        int cur = Graphics.index();
        int ph = HEAD + 2 * 35 + 2;
        Render.rrect(ctx, cx, top, cw, ph, tint(0.105f));
        Render.text(ctx, "Профиль графики", cx + 10, top + 6, acc());
        chevron(ctx, cx + cw - 15, top + 5, acc());
        int cardW = (cw - 26) / 2;
        for (int i = 0; i < Graphics.NAMES.length; i++) {
            int x = cx + 9 + (i % 2) * (cardW + 8);
            int y = top + HEAD + (i / 2) * 35;
            boolean sel = i == cur;
            boolean hover = inClip && in(mx, my, x, y, cardW, 30);
            float hv = hoverAmt(Graphics.NAMES[i], hover);
            if (sel) {
                Render.rrect(ctx, x - 1, y - 1, cardW + 2, 32, Render.withAlpha(acc(), 0.7f));
            }
            Render.rrect(ctx, x, y, cardW, 30, tint(0.14f + 0.05f * hv));
            Render.text(ctx, Graphics.NAMES[i], x + 10, y + 6, sel ? 0xFFFFFFFF : DIM);
            Render.text(ctx, Graphics.TITLES[i], x + 10, y + 17, sel ? acc() : FAINT);
            if (hover && cl) {
                ClientSettings.INSTANCE.graphics.deserialize(Graphics.NAMES[i]);
            }
        }

        int y = top + ph + 8;
        String[] lines = Graphics.describe();
        int hh = HEAD + lines.length * 13 + 22;
        Render.rrect(ctx, cx, y, cw, hh, tint(0.105f));
        Render.text(ctx, "Что включено в профиле " + Graphics.NAMES[cur], cx + 10, y + 6, acc());
        for (int i = 0; i < lines.length; i++) {
            Render.text(ctx, fit(lines[i], cw - 24), cx + 12, y + HEAD + i * 13, DIM);
        }
        Render.text(ctx, "Применяется сразу и сохраняется в конфиге", cx + 12, y + hh - 14, FAINT);
        colY[0] = y + hh + 8;
        colY[1] = colY[0];
    }

    private void setToast(ModuleManager.Result r) {
        toast = r.message();
        toastOk = r.ok();
        toastAt = System.currentTimeMillis();
    }

    /** Обрезает строку по ширине, чтобы длинное сообщение об ошибке не вылезало из панели. */
    private static String fit(String text, int maxW) {
        if (Render.width(text) <= maxW) {
            return text;
        }
        String t = text;
        while (t.length() > 1 && Render.width(t + "...") > maxW) {
            t = t.substring(0, t.length() - 1);
        }
        return t + "...";
    }

    private void drawConfig(DrawContext ctx, int cx, int top, int cw, boolean inClip, int[] colY) {
        if (profilesDirty) {
            profileCache = ModuleManager.profiles();
            profilesDirty = false;
        }
        if (!confirmDelete.isEmpty() && System.currentTimeMillis() - confirmAt > 2500) {
            confirmDelete = "";
        }

        // --- панель 1: основной конфиг, создание профиля, статус последней операции
        int ph = HEAD + 24 + 6 + 24 + 6 + 14;
        Render.rrect(ctx, cx, top, cw, ph, tint(0.105f));
        Render.text(ctx, "Конфиги", cx + 10, top + 6, acc());
        chevron(ctx, cx + cw - 15, top + 5, acc());
        int bw = (cw - 26) / 2;
        if (button(ctx, cx + 9, top + HEAD, bw, 24, "Сохранить", inClip, false)) {
            setToast(ModuleManager.save());
        }
        if (button(ctx, cx + 17 + bw, top + HEAD, bw, 24, "Загрузить", inClip, false)) {
            setToast(ModuleManager.load());
        }

        int ry = top + HEAD + 30;
        int createW = 84;
        int fw = cw - 18 - createW - 6;
        boolean fHover = inClip && in(mx, my, cx + 9, ry, fw, 24);
        if (cl) {
            naming = fHover;
            if (fHover) {
                searching = false;
                listening = null;
            }
        }
        if (naming) {
            Render.rrect(ctx, cx + 8, ry - 1, fw + 2, 26, Render.withAlpha(acc(), 0.55f));
        }
        Render.rrect(ctx, cx + 9, ry, fw, 24, tint(naming ? 0.16f : 0.11f));
        if (profileName.length() == 0 && !naming) {
            Render.text(ctx, "Имя нового профиля", cx + 17, ry + 8, FAINT);
        } else {
            boolean caret = naming && (System.currentTimeMillis() / 450) % 2 == 0;
            Render.text(ctx, profileName + (caret ? "|" : ""), cx + 17, ry + 8, 0xFFFFFFFF);
        }
        if (button(ctx, cx + 9 + fw + 6, ry, createW, 24, "Создать", inClip, false)) {
            createProfile();
        }

        boolean fresh = !toast.isEmpty() && System.currentTimeMillis() - toastAt < 4000;
        String status = fresh ? toast : "Основной конфиг сохраняется при закрытии меню";
        Render.text(ctx, fit(status, cw - 20), cx + 10, top + ph - 15, fresh ? (toastOk ? 0xFF55E58A : 0xFFFF5A5F) : FAINT);

        // --- панель 2: сохранённые профили
        int y = top + ph + 8;
        int rows = Math.max(1, profileCache.size());
        int hh = HEAD + rows * 22 + 4;
        Render.rrect(ctx, cx, y, cw, hh, tint(0.105f));
        Render.text(ctx, "Профили", cx + 10, y + 6, acc());
        if (button(ctx, cx + cw - 96, y + 2, 72, 16, "Папка", inClip, false)) {
            setToast(ModuleManager.openFolder());
        }
        chevron(ctx, cx + cw - 15, y + 5, acc());
        if (profileCache.isEmpty()) {
            Render.text(ctx, "Профилей пока нет - введи имя и нажми «Создать»", cx + 12, y + HEAD + 6, FAINT);
        }
        int tw = 40;
        int x3 = cx + cw - 12 - tw;
        int x2 = x3 - 4 - tw;
        int x1 = x2 - 4 - tw;
        for (int i = 0; i < profileCache.size(); i++) {
            String name = profileCache.get(i);
            int py = y + HEAD + i * 22;
            Render.rrect(ctx, cx + 8, py, cw - 16, 20, tint(0.14f));
            Render.text(ctx, fit(name, x1 - (cx + 14) - 4), cx + 14, py + 6, 0xFFE8E2E6);
            if (button(ctx, x1, py + 2, tw, 16, "Загр.", inClip, false)) {
                setToast(ModuleManager.loadProfile(name));
            }
            if (button(ctx, x2, py + 2, tw, 16, "Сохр.", inClip, false)) {
                setToast(ModuleManager.saveProfile(name));
            }
            boolean armed = confirmDelete.equals(name);
            if (button(ctx, x3, py + 2, tw, 16, armed ? "Точно?" : "Удал.", inClip, true)) {
                if (armed) {
                    confirmDelete = "";
                    setToast(ModuleManager.deleteProfile(name));
                    profilesDirty = true;
                } else {
                    confirmDelete = name;
                    confirmAt = System.currentTimeMillis();
                }
            }
        }

        // --- панель 3: друзья и команды
        int y3 = y + hh + 8;
        List<String> lines = new ArrayList<>();
        lines.add(Friends.all().isEmpty() ? "Друзей нет" : "Друзья: " + String.join(", ", Friends.all()));
        lines.add(".friend add Ник  -  добавить друга");
        lines.add(".bind add \"KillAura\" \"R\"  -  бинд");
        lines.add(".set TargetStrafe Radius 3  -  настройка");
        lines.add(".config save|load|list|delete Имя  -  профили");
        lines.add(".help  -  все команды");
        int h3 = HEAD + lines.size() * 13 + 6;
        Render.rrect(ctx, cx, y3, cw, h3, tint(0.105f));
        Render.text(ctx, "Друзья и команды", cx + 10, y3 + 6, acc());
        for (int i = 0; i < lines.size(); i++) {
            Render.text(ctx, fit(lines.get(i), cw - 24), cx + 12, y3 + HEAD + i * 13, i == 0 ? 0xFFE8E2E6 : DIM);
        }
        colY[0] = y3 + h3 + 8;
        colY[1] = colY[0];
    }

    /** Создание профиля из поля имени: существующий профиль не перезаписывается молча. */
    private void createProfile() {
        String name = ModuleManager.cleanName(profileName.toString());
        if (name.isEmpty()) {
            setToast(new ModuleManager.Result(false, "Введи имя профиля (буквы, цифры, - и _)"));
            return;
        }
        for (String existing : profileCache) {
            if (existing.equalsIgnoreCase(name)) {
                setToast(new ModuleManager.Result(false, "Профиль «" + existing + "» уже есть - используй «Сохр.»"));
                return;
            }
        }
        ModuleManager.Result r = ModuleManager.saveProfile(name);
        setToast(r.ok() ? new ModuleManager.Result(true, "Профиль создан: " + name) : r);
        if (r.ok()) {
            profileName.setLength(0);
            naming = false;
            profilesDirty = true;
        }
    }

    /** Кнопка с реальным результатом: true в кадр клика. danger - красная (удаление). */
    private boolean button(DrawContext ctx, int x, int y, int w, int h, String label, boolean inClip, boolean danger) {
        boolean hover = inClip && in(mx, my, x, y, w, h);
        int base = danger ? 0xFFE5484D : acc();
        Render.rrect(ctx, x, y, w, h, hover ? Render.withAlpha(base, 0.30f) : tint(0.16f));
        int tc = hover ? 0xFFFFFFFF : (danger && label.endsWith("?") ? base : DIM);
        Render.text(ctx, label, x + w / 2 - Render.width(label) / 2, y + (h - 8) / 2, tc);
        return hover && cl;
    }

    // ------------------------------------------------------------------ ввод с клавиатуры (без событий Screen)

    private static boolean down(long win, int key) {
        return GLFW.glfwGetKey(win, key) == GLFW.GLFW_PRESS;
    }

    private void pollKeys(long win) {
        boolean esc = down(win, GLFW.GLFW_KEY_ESCAPE);
        if (esc && !prevEsc) {
            if (listening != null) {
                listening = null;
            } else if (searching) {
                searching = false;
            } else if (naming) {
                naming = false;
            }
        }
        prevEsc = esc;

        boolean enter = down(win, GLFW.GLFW_KEY_ENTER) || down(win, GLFW.GLFW_KEY_KP_ENTER);
        if (enter && !prevEnter && naming && listening == null) {
            createProfile();
        }
        prevEnter = enter;

        if (listening != null) {
            for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
                if (k != GLFW.GLFW_KEY_ESCAPE && down(win, k)) {
                    listening.setKey(k == GLFW.GLFW_KEY_BACKSPACE || k == GLFW.GLFW_KEY_DELETE ? 0 : k);
                    listening = null;
                    break;
                }
            }
        }

        for (int k : SEARCH_KEYS) {
            boolean d = down(win, k);
            if (d && !prevKey[k] && listening == null) {
                if (searching) {
                    typeSearch(k);
                } else if (naming) {
                    typeName(win, k);
                }
            }
            prevKey[k] = d;
        }
    }

    private void typeSearch(int k) {
        if (k == GLFW.GLFW_KEY_BACKSPACE) {
            if (query.length() > 0) {
                query.setLength(query.length() - 1);
            }
        } else if (query.length() < 18) {
            if (k == GLFW.GLFW_KEY_SPACE) {
                query.append(' ');
            } else if (k >= GLFW.GLFW_KEY_A && k <= GLFW.GLFW_KEY_Z) {
                query.append((char) (k + 32));
            } else {
                query.append((char) k);
            }
        }
    }

    /** Имя профиля: только A-Z, 0-9, '-' и '_' (Shift+'-'); пробел игнорируется, чтобы имя файла было безопасным. */
    private void typeName(long win, int k) {
        if (k == GLFW.GLFW_KEY_BACKSPACE) {
            if (profileName.length() > 0) {
                profileName.setLength(profileName.length() - 1);
            }
            return;
        }
        if (profileName.length() >= ModuleManager.MAX_PROFILE_NAME) {
            return;
        }
        boolean shift = down(win, GLFW.GLFW_KEY_LEFT_SHIFT) || down(win, GLFW.GLFW_KEY_RIGHT_SHIFT);
        if (k >= GLFW.GLFW_KEY_A && k <= GLFW.GLFW_KEY_Z) {
            profileName.append((char) (shift ? k : k + 32));
        } else if (k >= GLFW.GLFW_KEY_0 && k <= GLFW.GLFW_KEY_9) {
            profileName.append((char) k);
        } else if (k == GLFW.GLFW_KEY_MINUS) {
            profileName.append(shift ? '_' : '-');
        }
    }

    public static String keyName(int k) {
        if (k == 0) {
            return "NONE";
        }
        switch (k) {
            case GLFW.GLFW_KEY_SPACE: return "SPACE";
            case GLFW.GLFW_KEY_TAB: return "TAB";
            case GLFW.GLFW_KEY_LEFT_SHIFT: return "LSHIFT";
            case GLFW.GLFW_KEY_RIGHT_SHIFT: return "RSHIFT";
            case GLFW.GLFW_KEY_LEFT_CONTROL: return "LCTRL";
            case GLFW.GLFW_KEY_RIGHT_CONTROL: return "RCTRL";
            case GLFW.GLFW_KEY_LEFT_ALT: return "LALT";
            case GLFW.GLFW_KEY_RIGHT_ALT: return "RALT";
            case GLFW.GLFW_KEY_UP: return "UP";
            case GLFW.GLFW_KEY_DOWN: return "DOWN";
            case GLFW.GLFW_KEY_LEFT: return "LEFT";
            case GLFW.GLFW_KEY_RIGHT: return "RIGHT";
            default:
                break;
        }
        if (k >= GLFW.GLFW_KEY_F1 && k <= GLFW.GLFW_KEY_F12) {
            return "F" + (k - GLFW.GLFW_KEY_F1 + 1);
        }
        String n = GLFW.glfwGetKeyName(k, 0);
        return n != null ? n.toUpperCase() : "KEY" + k;
    }
}
