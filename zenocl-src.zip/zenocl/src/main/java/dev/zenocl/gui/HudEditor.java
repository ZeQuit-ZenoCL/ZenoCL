package dev.zenocl.gui;

import dev.zenocl.core.Module;
import dev.zenocl.core.ModuleManager;
import dev.zenocl.hud.HudModule;
import dev.zenocl.hud.Render;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * Редактор HUD. Элементы перетаскиваются мышью (с примагничиванием к краям и центру экрана),
 * у выбранного элемента настраивается прозрачность, позиция сбрасывается ПКМ или кнопкой.
 * Позиции и прозрачность сохраняются в конфиг при выходе. Ввод читается опросом GLFW, как в ClickGui.
 */
public class HudEditor extends Screen {
    private static final int SNAP = 5;
    private static final int DIM = 0xFF8D868C;

    private final List<HudModule> mods = new ArrayList<>();
    private HudModule selected;
    private boolean dragging;
    private boolean sliding;
    private int offX;
    private int offY;
    private int guideX = -1;
    private int guideY = -1;
    private boolean prevL;
    private boolean prevR;
    private int mx;
    private int my;
    private boolean cl;
    private boolean cr;

    public HudEditor() {
        super(Text.literal("HUD"));
        HudModule.editing = true;
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void removed() {
        HudModule.editing = false;
        ModuleManager.save();
    }

    /** Русские названия для интерфейса; внутренние идентификаторы модулей не меняются. */
    static String title(HudModule m) {
        return switch (m.name) {
            case "ArmorHUD" -> "Броня";
            case "ArrayList" -> "Список модулей";
            case "Inventory" -> "Инвентарь";
            case "Info" -> "Информация";
            case "Keystrokes" -> "Клавиши";
            case "Notifications" -> "Уведомления";
            case "Potions" -> "Эффекты";
            case "Radar" -> "Радар";
            case "Session" -> "Сессия";
            case "TargetInfo" -> "Цель";
            case "Watermark" -> "Ватермарк";
            case "Compass" -> "Компас";
            case "FpsGraph" -> "График FPS";
            default -> m.name;
        };
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontal, double vertical) {
        HudModule h = hit(mx, my);
        if (h == null) {
            h = selected;
        }
        if (h != null) {
            selected = h;
            h.opacity.set(h.opacity.get() + Math.signum(vertical) * 0.05);
        }
        return true;
    }

    private static boolean in(int px, int py, int x, int y, int w, int h) {
        return px >= x && px < x + w && py >= y && py < y + h;
    }

    private HudModule hit(int px, int py) {
        for (int i = mods.size() - 1; i >= 0; i--) {
            HudModule m = mods.get(i);
            if (m.isEnabled() && m.fresh() && in(px, py, m.bx(), m.by(), m.bw(), m.bh())) {
                return m;
            }
        }
        return null;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        mx = mouseX;
        my = mouseY;
        long win = MinecraftClient.getInstance().getWindow().getHandle();
        boolean l = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean r = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        cl = l && !prevL;
        cr = r && !prevR;
        prevL = l;
        prevR = r;

        mods.clear();
        for (Module m : ModuleManager.all()) {
            if (m instanceof HudModule h && h.movable()) {
                mods.add(h);
            }
        }

        ctx.fill(0, 0, width, height, 0x38000000);
        int acc = Render.accent(0);

        boolean overUi = drawChips(ctx, acc);
        overUi |= drawToolbar(ctx, acc, l);

        // выбор и перетаскивание
        if (cl && !overUi) {
            selected = hit(mx, my);
            if (selected != null) {
                dragging = true;
                offX = mx - selected.bx();
                offY = my - selected.by();
            }
        }
        if (cr && !overUi) {
            HudModule h = hit(mx, my);
            if (h != null) {
                h.resetPos();
                selected = h;
            }
        }
        guideX = -1;
        guideY = -1;
        if (dragging && l && selected != null) {
            drag();
        } else {
            dragging = false;
        }

        // рамки элементов
        for (HudModule m : mods) {
            if (!m.isEnabled() || !m.fresh()) {
                continue;
            }
            boolean sel = m == selected;
            boolean hov = !overUi && m == hit(mx, my);
            int c = sel ? acc : hov ? 0xCCFFFFFF : 0x66FFFFFF;
            frame(ctx, m.bx() - 1, m.by() - 1, m.bw() + 2, m.bh() + 2, c);
            if (sel || hov) {
                String t = title(m);
                int ty = m.by() > 14 ? m.by() - 12 : m.by() + m.bh() + 3;
                Render.text(ctx, t, m.bx(), ty, sel ? acc : 0xFFFFFFFF);
            }
        }
        if (guideX >= 0) {
            ctx.fill(guideX, 0, guideX + 1, height, Render.withAlpha(acc, 0.5f));
        }
        if (guideY >= 0) {
            ctx.fill(0, guideY, width, guideY + 1, Render.withAlpha(acc, 0.5f));
        }
        if (selected == null) {
            String hint = "ЛКМ - перетащить   ПКМ - сбросить позицию   Колесо - прозрачность   Esc - выйти";
            int w = Render.width(hint) + 16;
            Render.rrect(ctx, width / 2 - w / 2, height - 28, w, 18, Render.bg());
            Render.text(ctx, hint, width / 2 - w / 2 + 8, height - 23, DIM);
        }
    }

    private void drag() {
        int bw = selected.bw();
        int bh = selected.bh();
        int nx = mx - offX;
        int ny = my - offY;
        int cxs = (width - bw) / 2;
        int cys = (height - bh) / 2;
        if (Math.abs(nx - cxs) <= SNAP) {
            nx = cxs;
            guideX = width / 2;
        } else if (Math.abs(nx) <= SNAP) {
            nx = 0;
        } else if (Math.abs(nx - (width - bw)) <= SNAP) {
            nx = width - bw;
        }
        if (Math.abs(ny - cys) <= SNAP) {
            ny = cys;
            guideY = height / 2;
        } else if (Math.abs(ny) <= SNAP) {
            ny = 0;
        } else if (Math.abs(ny - (height - bh)) <= SNAP) {
            ny = height - bh;
        }
        selected.moveTo(nx, ny, width, height);
    }

    private static void frame(DrawContext ctx, int x, int y, int w, int h, int c) {
        ctx.fill(x, y, x + w, y + 1, c);
        ctx.fill(x, y + h - 1, x + w, y + h, c);
        ctx.fill(x, y, x + 1, y + h, c);
        ctx.fill(x + w - 1, y, x + w, y + h, c);
    }

    /** Верхняя панель: все двигаемые элементы, клик включает/выключает. true - курсор над панелью. */
    private boolean drawChips(DrawContext ctx, int acc) {
        int x = 8;
        int y = 8;
        boolean over = false;
        for (HudModule m : mods) {
            String label = title(m);
            int w = Render.width(label) + 14;
            if (x + w > width - 8) {
                x = 8;
                y += 19;
            }
            boolean hover = in(mx, my, x, y, w, 16);
            Render.rrect(ctx, x, y, w, 16, m.isEnabled() ? Render.withAlpha(acc, hover ? 0.5f : 0.35f) : Render.withAlpha(0xFF14141C, hover ? 0.95f : 0.8f));
            Render.text(ctx, label, x + 7, y + 4, m.isEnabled() ? 0xFFFFFFFF : DIM);
            if (hover) {
                over = true;
                if (cl) {
                    m.toggle();
                    if (m == selected && !m.isEnabled()) {
                        selected = null;
                    }
                }
            }
            x += w + 4;
        }
        return over;
    }

    /** Панель выбранного элемента: прозрачность и сброс позиции. true - курсор над панелью. */
    private boolean drawToolbar(DrawContext ctx, int acc, boolean leftDown) {
        if (selected == null) {
            sliding = false;
            return false;
        }
        int w = 300;
        int h = 58;
        int x = (width - w) / 2;
        int y = height - h - 12;
        Render.rrect(ctx, x - 1, y - 1, w + 2, h + 2, Render.withAlpha(acc, 0.4f));
        Render.rrect(ctx, x, y, w, h, 0xF0101018);
        Render.text(ctx, title(selected), x + 10, y + 7, acc);
        String st = selected.isMoved() ? "позиция изменена" : "позиция по умолчанию";
        Render.text(ctx, st, x + w - 10 - Render.width(st), y + 7, DIM);

        Render.text(ctx, "Прозрачность", x + 10, y + 24, 0xFFCFC9CD);
        int sx = x + 100;
        int sw = 130;
        int sy = y + 27;
        boolean sHover = in(mx, my, sx - 4, sy - 6, sw + 8, 16);
        if (cl && sHover) {
            sliding = true;
        }
        if (!leftDown) {
            sliding = false;
        }
        if (sliding) {
            double t = Math.max(0, Math.min(1, (mx - sx) / (double) sw));
            selected.opacity.set(0.1 + t * 0.9);
        }
        double p = (selected.opacity.get() - 0.1) / 0.9;
        Render.fill(ctx, sx, sy, sx + sw, sy + 3, 0xFF2D2528);
        int fill = (int) (sw * p);
        Render.gradient(ctx, sx, sy, sx + Math.max(1, fill), sy + 3, Render.accent(0), Render.accent(1.5));
        Render.fill(ctx, sx + fill - 1, sy - 2, sx + fill + 1, sy + 5, 0xFFFFFFFF);
        String pct = Math.round(selected.opacity.get() * 100) + "%";
        Render.text(ctx, pct, x + w - 10 - Render.width(pct), y + 24, 0xFFFFFFFF);

        int bw = (w - 28) / 2;
        if (button(ctx, x + 10, y + 38, bw, 15, "Сбросить позицию", acc)) {
            selected.resetPos();
        }
        if (button(ctx, x + 18 + bw, y + 38, bw, 15, "Скрыть элемент", acc)) {
            selected.toggle();
            selected = null;
            return true;
        }
        return in(mx, my, x - 1, y - 1, w + 2, h + 2) || sliding;
    }

    private boolean button(DrawContext ctx, int x, int y, int w, int h, String label, int acc) {
        boolean hover = in(mx, my, x, y, w, h);
        Render.rrect(ctx, x, y, w, h, hover ? Render.withAlpha(acc, 0.3f) : 0xFF1C1C26);
        Render.text(ctx, label, x + w / 2 - Render.width(label) / 2, y + 4, hover ? 0xFFFFFFFF : DIM);
        return hover && cl;
    }
}
