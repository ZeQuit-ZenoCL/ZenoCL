package dev.zenocl.gui;

import java.util.Map;

/** Короткие описания модулей для карточек и подсказки (появляется через 3 секунды наведения). */
public final class ModuleInfo {
    private static final Map<String, String> TEXT = Map.ofEntries(
            Map.entry("AutoPot", "Сам бросает зелья лечения и усиления, когда нужно"),
            Map.entry("AutoGapple", "Ест золотое яблоко при низком здоровье"),
            Map.entry("BowAim", "Наводит лук на цель с упреждением"),
            Map.entry("Surround", "Ставит блоки вокруг ног, защищая от кристаллов"),
            Map.entry("AntiBot", "Отсеивает фейковых игроков-ботов из целей"),
            Map.entry("AutoLog", "Выходит с сервера при опасно низком здоровье"),
            Map.entry("KillAura", "Сам бьёт ближайшую цель: поворот, крит, орбита, за спину"),
            Map.entry("AutoXP", "Бросает пузырьки опыта для починки брони"),
            Map.entry("TriggerBot", "Бьёт, когда прицел наведён на цель; задержка реакции как у человека"),
            Map.entry("Criticals", "Каждый удар становится критическим, даже с земли"),
            Map.entry("AimAssist", "Мягко доводит прицел к цели, как человек"),
            Map.entry("Velocity", "Уменьшает или убирает отбрасывание от ударов"),
            Map.entry("AutoTotem", "Держит тотем бессмертия в левой руке"),
            Map.entry("PearlThrow", "Бросает жемчуг эндера в нужную сторону по кнопке"),
            Map.entry("AutoCrystal", "Ставит и взрывает кристаллы эндера у цели"),
            Map.entry("CPS", "Показывает клики в секунду"),
            Map.entry("Fullbright", "Максимальная яркость без факела и зелья"),
            Map.entry("FpsGraph", "График FPS на экране"),
            Map.entry("Notifications", "Всплывающие уведомления о включении модулей"),
            Map.entry("Keystrokes", "Показывает нажатые клавиши движения и мыши"),
            Map.entry("TargetInfo", "Карточка цели: голова, ник, здоровье, броня"),
            Map.entry("ArmorHUD", "Броня и прочность на экране"),
            Map.entry("Inventory", "Содержимое инвентаря на экране"),
            Map.entry("Session", "Время сессии и статистика"),
            Map.entry("Potions", "Активные эффекты зелий"),
            Map.entry("Arrows", "Стрелки на краю экрана к игрокам вне поля зрения"),
            Map.entry("LowHealth", "Красная виньетка при низком здоровье"),
            Map.entry("Compass", "Компас со сторонами света"),
            Map.entry("Swing", "Скорость и плавность анимации взмаха руки"),
            Map.entry("TargetESP", "Эффект на цели киллауры: 10 вариантов"),
            Map.entry("Tracers", "Линии от прицела к игрокам"),
            Map.entry("Watermark", "Название клиента на экране"),
            Map.entry("ESP", "Рамки, скелет и заливка игроков; рамки предметов на земле"),
            Map.entry("SeeInvisible", "Показывает невидимых игроков, видимость 10-100%"),
            Map.entry("Zoom", "Приближение камеры на зажатую клавишу"),
            Map.entry("Radar", "Мини-радар с игроками вокруг"),
            Map.entry("ArrayList", "Список включённых модулей"),
            Map.entry("Info", "Координаты, пинг, FPS и скорость"),
            Map.entry("AntiVoid", "Не даёт упасть в бездну"),
            Map.entry("AirJump", "Прыжки в воздухе"),
            Map.entry("Glide", "Медленное падение (планирование)"),
            Map.entry("Speed", "Скорость: Legacy, Grim, Entity, Custom, Water"),
            Map.entry("Strafe", "Управление в воздухе без потери скорости"),
            Map.entry("HighJump", "Высокий прыжок"),
            Map.entry("NoFall", "Убирает урон от падения"),
            Map.entry("AutoWalk", "Сам идёт вперёд"),
            Map.entry("Jesus", "Хождение по воде: Vanilla и Solid"),
            Map.entry("Bhop", "Авто-прыжки с постоянной скоростью"),
            Map.entry("Spider", "Лазание по стенам: Climb и Hop"),
            Map.entry("FastFall", "Быстрое падение"),
            Map.entry("Sprint", "Автоспринт"),
            Map.entry("TargetStrafe", "Бег по кругу вокруг цели"),
            Map.entry("Fly", "Полёт"),
            Map.entry("Step", "Подъём на блоки без прыжка"),
            Map.entry("Spammer", "Сообщения в чат по таймеру; команда .spam add Текст"),
            Map.entry("Panic", "Мгновенно выключает все модули"),
            Map.entry("Client", "Тема, шрифт, графика, оптимизация настроек Minecraft"),
            Map.entry("AntiAFK", "Не даёт серверу кикнуть за бездействие"),
            Map.entry("AutoArmor", "Сам надевает лучшую броню"),
            Map.entry("AutoRespawn", "Сам возрождается после смерти"),
            Map.entry("AutoMine", "Автоматически копает блок под прицелом"),
            Map.entry("AutoSneak", "Автоприсед"),
            Map.entry("AutoEat", "Сам ест, когда голодно"),
            Map.entry("MiddleClickFriend", "СКМ по игроку добавляет его в друзья"),
            Map.entry("FastPlace", "Быстрая установка блоков"),
            Map.entry("ChestStealer", "Быстро забирает предметы из сундука"));

    private ModuleInfo() {
    }

    public static String of(String module) {
        return TEXT.getOrDefault(module, "");
    }
}
