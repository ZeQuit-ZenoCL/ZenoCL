package dev.zenocl.hud;

import dev.zenocl.modules.misc.ClientSettings;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/**
 * Текст с кастомным шрифтом (assets/zenocl/font/main.json - Inter, machine.json - Machine BT).
 * Если после обновления Minecraft сломается компиляция - править нужно только эту строку-стиль.
 * Machine BT не содержит кириллицы: русские буквы берутся из шрифта игры (reference в machine.json).
 */
public final class FontText {
    private static final Style INTER = Style.EMPTY.withFont(new StyleSpriteSource.Font(Identifier.of("zenocl", "main")));
    private static final Style MACHINE = Style.EMPTY.withFont(new StyleSpriteSource.Font(Identifier.of("zenocl", "machine")));

    private FontText() {
    }

    public static Text of(String s) {
        ClientSettings cs = ClientSettings.INSTANCE;
        return Text.literal(s).setStyle(cs != null && cs.font.is("Machine") ? MACHINE : INTER);
    }
}
