package dev.zenocl.hud;

import dev.zenocl.modules.misc.ClientSettings;

/**
 * Профили графики Low / Medium / High / Ultra. Каждый параметр реально читается отрисовкой ClickGUI,
 * поэтому профиль переключается на лету, без перезапуска. Размытия фона здесь нет: на текущей архитектуре
 * (без своих шейдеров) его не реализовать, и фиктивной настройки для него не показывается.
 */
public final class Graphics {
    public static final String[] NAMES = {"Low", "Medium", "High", "Ultra"};
    public static final String[] TITLES = {"Минимум", "Баланс", "Улучшенная", "Максимум"};

    //                          open  aura pulse  hover popup  parts alpha scroll header
    private static final float[][] T = {
            {0.00f, 0, 0, 0, 0, 0, 1.00f, 40f, 0},
            {0.18f, 2, 0, 1, 1, 0, 1.00f, 18f, 1},
            {0.26f, 3, 1, 1, 1, 14, 0.97f, 14f, 1},
            {0.36f, 5, 1, 1, 1, 32, 0.92f, 11f, 1},
    };

    private Graphics() {
    }

    public static int index() {
        ClientSettings cs = ClientSettings.INSTANCE;
        if (cs != null) {
            String v = cs.graphics.get();
            for (int i = 0; i < NAMES.length; i++) {
                if (NAMES[i].equalsIgnoreCase(v)) {
                    return i;
                }
            }
        }
        return 2; // High - то, как меню выглядело до появления профилей
    }

    private static float[] row() {
        return T[index()];
    }

    /** Длительность открытия окна, сек (0 = мгновенно). */
    public static float openSeconds() {
        return row()[0];
    }

    public static int auraLayers() {
        return (int) row()[1];
    }

    public static boolean pulse() {
        return row()[2] > 0;
    }

    public static boolean hoverFade() {
        return row()[3] > 0;
    }

    public static boolean popupAnim() {
        return row()[4] > 0;
    }

    public static int particles() {
        return (int) row()[5];
    }

    /** Непрозрачность панелей: меньше 1 даёт эффект стекла, сквозь панели видно свечение. */
    public static float panelAlpha() {
        return row()[6];
    }

    /** Скорость сглаживания прокрутки, 1/сек: меньше - мягче и дольше. */
    public static float scrollSharpness() {
        return row()[7];
    }

    public static boolean headerGradient() {
        return row()[8] > 0;
    }

    /** Живое описание выбранного профиля для страницы «Графика». */
    public static String[] describe() {
        float[] r = row();
        return new String[]{
                "Открытие окна: " + (r[0] == 0 ? "мгновенно" : String.format("%.2f с", r[0])),
                "Свечение окна: " + (r[1] == 0 ? "выкл" : (int) r[1] + " сл."),
                "Пульсация свечения: " + (r[2] > 0 ? "вкл" : "выкл"),
                "Плавная подсветка строк: " + (r[3] > 0 ? "вкл" : "выкл"),
                "Анимация панели настроек: " + (r[4] > 0 ? "вкл" : "выкл"),
                "Частицы: " + (r[5] == 0 ? "выкл" : (int) r[5] + " шт."),
                "Прозрачность панелей: " + Math.round(r[6] * 100) + "%",
                "Инерция прокрутки: " + (r[7] >= 30 ? "нет" : r[7] >= 16 ? "лёгкая" : r[7] >= 13 ? "средняя" : "высокая"),
        };
    }
}
