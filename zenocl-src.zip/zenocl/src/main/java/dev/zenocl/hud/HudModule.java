package dev.zenocl.hud;

import dev.zenocl.core.Category;
import dev.zenocl.core.Module;
import dev.zenocl.core.NumSetting;
import net.minecraft.client.gui.DrawContext;

/**
 * Модуль, который что-то рисует на экране. Живёт в категории Visual.
 * Двигаемые элементы (movable) сами считают позицию по умолчанию и передают её в place():
 * если пользователь перетащил элемент в редакторе HUD, place() вернёт сохранённую позицию.
 */
public abstract class HudModule extends Module {
    /** true, пока открыт редактор HUD: пустые элементы рисуют заглушку, чтобы их можно было схватить мышью. */
    public static boolean editing;

    public final NumSetting opacity = add(new NumSetting("Opacity", 1.0, 0.1, 1.0, 0.05));
    // позиция в долях экрана (не пикселях): не ломается при смене разрешения и масштаба GUI; -1 = по умолчанию
    private final NumSetting posX = hiddenNum("PosX");
    private final NumSetting posY = hiddenNum("PosY");

    private int bx;
    private int by;
    private int bw;
    private int bh;
    private long boundsStamp;

    protected HudModule(String name) {
        super(name, Category.VISUAL);
    }

    private NumSetting hiddenNum(String name) {
        NumSetting s = new NumSetting(name, -1, -1, 1.0, 0);
        s.hidden = true;
        return add(s);
    }

    public abstract void render(DrawContext ctx, int sw, int sh);

    /** Точка входа для HUD-колбэка: применяет индивидуальную прозрачность элемента. */
    public final void draw(DrawContext ctx, int sw, int sh) {
        Render.hudAlpha = opacity.getFloat();
        try {
            render(ctx, sw, sh);
        } finally {
            Render.hudAlpha = 1f;
        }
    }

    /** false - элемент не имеет своей рамки (ESP, виньетка): в редакторе его нельзя двигать. */
    public boolean movable() {
        return true;
    }

    /** true - сохранённая позиция задаёт правый край (для списков, растущих влево). */
    protected boolean anchorRight() {
        return false;
    }

    /** Возвращает {x, y} с учётом сохранённой позиции и запоминает рамку для редактора. */
    protected final int[] place(int defX, int defY, int w, int h, int sw, int sh) {
        int x = defX;
        int y = defY;
        if (isMoved()) {
            x = (int) Math.round(posX.get() * sw);
            y = (int) Math.round(posY.get() * sh);
            if (anchorRight()) {
                x -= w;
            }
        }
        x = Math.max(0, Math.min(Math.max(0, sw - w), x));
        y = Math.max(0, Math.min(Math.max(0, sh - h), y));
        bx = x;
        by = y;
        bw = w;
        bh = h;
        boundsStamp = System.nanoTime();
        return new int[]{x, y};
    }

    public boolean isMoved() {
        return posX.get() >= 0 && posY.get() >= 0;
    }

    public void moveTo(int x, int y, int sw, int sh) {
        posX.set((anchorRight() ? x + bw : x) / (double) Math.max(1, sw));
        posY.set(y / (double) Math.max(1, sh));
    }

    public void resetPos() {
        posX.set(-1.0);
        posY.set(-1.0);
    }

    public int bx() {
        return bx;
    }

    public int by() {
        return by;
    }

    public int bw() {
        return bw;
    }

    public int bh() {
        return bh;
    }

    /** Рамка актуальна, если элемент рисовался в последние ~0.3 с. */
    public boolean fresh() {
        return System.nanoTime() - boundsStamp < 300_000_000L;
    }
}
