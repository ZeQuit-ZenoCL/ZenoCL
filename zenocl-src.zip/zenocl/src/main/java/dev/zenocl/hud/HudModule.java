package dev.zenocl.hud;

import dev.zenocl.core.Category;
import dev.zenocl.core.Module;
import dev.zenocl.core.NumSetting;
import net.minecraft.client.gui.DrawContext;

/**
 * Модуль, который что-то рисует на экране. Живёт в категории Visual.
 * Двигаемые элементы считают позицию по умолчанию и передают её в place(). Масштаб, прозрачность и позиция
 * настраиваются в панели модуля (ПКМ в ClickGUI); позиция хранится долями экрана и не ломается при смене разрешения.
 */
public abstract class HudModule extends Module {
    /** Оставлено для заглушек элементов; редактора HUD больше нет, всегда false. */
    public static boolean editing;

    public final NumSetting opacity = add(new NumSetting("Opacity", 1.0, 0.1, 1.0, 0.05));
    public final NumSetting scale = add(new NumSetting("Scale", 1.0, 0.5, 2.0, 0.1));
    private final NumSetting posX = hiddenNum("PosX");
    private final NumSetting posY = hiddenNum("PosY");

    private float curScale = 1f;
    private int bx;
    private int by;
    private int bw;
    private int bh;
    private long boundsStamp;

    protected HudModule(String name) {
        super(name, Category.VISUAL);
        // у элементов без своей рамки (ESP и т.п.) масштаб и прозрачность в панели не показываются
        opacity.showIf(this::movable);
        scale.showIf(this::movable);
    }

    private NumSetting hiddenNum(String name) {
        NumSetting s = new NumSetting(name, -1, -1, 1.0, 0);
        s.hidden = true;
        return add(s);
    }

    public abstract void render(DrawContext ctx, int sw, int sh);

    /** Вход для HUD-колбэка: прозрачность и масштаб элемента. Масштаб работает через виртуальный размер экрана sw/scale. */
    public final void draw(DrawContext ctx, int sw, int sh) {
        float s = movable() ? scale.getFloat() : 1f;
        Render.hudAlpha = opacity.getFloat();
        curScale = s;
        try {
            if (s == 1f) {
                render(ctx, sw, sh);
            } else {
                var m = ctx.getMatrices();
                m.pushMatrix();
                m.scale(s, s);
                try {
                    render(ctx, Math.round(sw / s), Math.round(sh / s));
                } finally {
                    m.popMatrix();
                }
            }
        } finally {
            Render.hudAlpha = 1f;
        }
    }

    /** false - у элемента нет своей рамки (ESP, виньетка): масштаб и перемещение не применяются. */
    public boolean movable() {
        return true;
    }

    protected boolean anchorRight() {
        return false;
    }

    /** {x, y} в виртуальных координатах с учётом сохранённой позиции; рамка запоминается в пикселях экрана. */
    protected final int[] place(int defX, int defY, int w, int h, int sw, int sh) {
        int x = defX;
        int y = defY;
        if (isMoved()) {
            x = (int) Math.round(posX.get() * sw);
            y = (int) Math.round(posY.get() * sh);
            if (anchorRight()) {
                x -= w;
            }
        }
        x = Math.max(0, Math.min(Math.max(0, sw - w), x));
        y = Math.max(0, Math.min(Math.max(0, sh - h), y));
        bx = Math.round(x * curScale);
        by = Math.round(y * curScale);
        bw = Math.round(w * curScale);
        bh = Math.round(h * curScale);
        boundsStamp = System.nanoTime();
        return new int[]{x, y};
    }

    public boolean isMoved() {
        return posX.get() >= 0 && posY.get() >= 0;
    }

    /** x, y, sw, sh - в пикселях экрана. */
    public void moveTo(int x, int y, int sw, int sh) {
        posX.set((anchorRight() ? x + bw : x) / (double) Math.max(1, sw));
        posY.set(y / (double) Math.max(1, sh));
    }

    public void resetPos() {
        posX.set(-1.0);
        posY.set(-1.0);
    }

    public int bx() {
        return bx;
    }

    public int by() {
        return by;
    }

    public int bw() {
        return bw;
    }

    public int bh() {
        return bh;
    }

    /** Рамка актуальна, если элемент рисовался в последние ~0.3 с. */
    public boolean fresh() {
        return System.nanoTime() - boundsStamp < 300_000_000L;
    }
}
