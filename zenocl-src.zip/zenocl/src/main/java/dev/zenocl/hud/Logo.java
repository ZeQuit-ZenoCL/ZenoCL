package dev.zenocl.hud;

import net.minecraft.client.gui.DrawContext;

/**
 * Вращающаяся объёмная "Z": плоская буква, выдавленная слоями по глубине и повёрнутая вокруг вертикальной оси
 * (сжатие по X на cos угла и сдвиг слоя на sin). Цвета - из темы, у передней грани светлее, задние слои темнеют.
 * Около 30 примитивов на кадр вместо построчной закраски многоугольников, поэтому на FPS не влияет.
 * Цикл 5 секунд: пауза лицом вперёд, плавный оборот, свечение и три искры вокруг.
 */
public final class Logo {
    private static final int LAYERS = 9;

    private Logo() {
    }

    private static double smooth(double x) {
        x = Math.max(0, Math.min(1, x));
        return x * x * (3 - 2 * x);
    }

    /** cx, cy - центр, size - высота буквы в пикселях GUI. */
    public static void draw(DrawContext ctx, int cx, int cy, float size) {
        double t = System.currentTimeMillis() / 1000.0;
        double ph = (t / 5.0) % 1.0;
        double ang = ph < 0.35 ? 0.0 : smooth((ph - 0.35) / 0.65) * Math.PI * 2;
        double cosA = Math.cos(ang);
        double sinA = Math.sin(ang);

        float s = size;
        double a = s * 0.34;
        double b = s * 0.46;
        double th = s * 0.21;
        double depth = s * 0.30;
        int c0 = Render.accent(0);
        int c1 = Render.accent(1.5);

        // свечение пульсирует
        float pulse = 0.5f + 0.5f * (float) Math.sin(t * 2.0);
        int g = Math.round(s * (1.55f + 0.08f * pulse)) / 2;
        Render.rrect(ctx, cx - g, cy - g, g * 2, g * 2, Render.withAlpha(c0, 0.07f));
        int g2 = Math.round(g * 0.78f);
        Render.rrect(ctx, cx - g2, cy - g2, g2 * 2, g2 * 2, Render.withAlpha(c1, 0.09f + 0.05f * pulse));

        double edge = Math.abs(sinA);
        for (int idx = 0; idx < LAYERS; idx++) {
            int k = cosA >= 0 ? idx : LAYERS - 1 - idx;
            double d = (k / (LAYERS - 1.0) - 0.5) * depth;
            double near = idx / (LAYERS - 1.0);
            // у боковой грани все слои освещены ровнее, спереди - яркий перед и тёмный зад
            double shade = 0.28 + 0.72 * Math.pow(near, 1.6);
            shade = shade + (0.62 - shade) * edge;
            boolean front = idx == LAYERS - 1;
            int top = shadeColor(c1, shade, front);
            int bot = shadeColor(c0, shade, front);
            int mid = Render.lerp(top, bot, 0.5f);
            double off = d * sinA;
            double sx = cosA;

            double y1 = cy - b;
            double y2 = cy + b;
            bar(ctx, cx + off, sx, -a, a, y1, y1 + th, top);
            bar(ctx, cx + off, sx, -a, a, y2 - th, y2, bot);
            int lt = Math.max(1, (int) Math.round(th * 1.05 * Math.max(0.3, Math.abs(sx))));
            Render.line(ctx, cx + off + (a - th * 0.45) * sx, y1 + th * 0.8, cx + off + (-a + th * 0.45) * sx, y2 - th * 0.8, mid, lt);
            if (front) {
                // блик по верхней кромке передней грани
                bar(ctx, cx + off, sx, -a, a, y1, y1 + 1, Render.withAlpha(0xFFFFFFFF, 0.45f));
            }
        }

        // искры вокруг
        for (int i = 0; i < 3; i++) {
            double u = t * 1.6 + i * 2.094;
            int px = cx + (int) Math.round(Math.cos(u) * s * 0.78);
            int py = cy + (int) Math.round(Math.sin(u * 0.9) * s * 0.58);
            float al = 0.35f + 0.65f * (float) Math.abs(Math.sin(u * 1.7));
            int sp = i == 1 ? 2 : 1;
            Render.fill(ctx, px - sp, py - sp, px + sp, py + sp, Render.withAlpha(i == 1 ? c1 : 0xFFFFFFFF, al));
        }
    }

    private static int shadeColor(int base, double shade, boolean front) {
        int dark = 0xFF0B0B10;
        int c = Render.lerp(dark, base, (float) Math.max(0, Math.min(1, shade)));
        return front ? Render.lerp(c, 0xFFFFFFFF, 0.12f) : c;
    }

    private static void bar(DrawContext ctx, double ox, double sx, double xa, double xb, double y1, double y2, int color) {
        int x1 = (int) Math.round(ox + xa * sx);
        int x2 = (int) Math.round(ox + xb * sx);
        int lo = Math.min(x1, x2);
        int hi = Math.max(x1, x2);
        if (hi - lo < 1) {
            hi = lo + 1;
        }
        Render.fill(ctx, lo, (int) Math.round(y1), hi, Math.max((int) Math.round(y1) + 1, (int) Math.round(y2)), color);
    }
}
