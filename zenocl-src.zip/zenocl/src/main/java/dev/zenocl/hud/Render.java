package dev.zenocl.hud;

import dev.zenocl.modules.misc.ClientSettings;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

/** Помощники отрисовки в стиле Nursultan: тёмные панели + градиентный акцент темы + шрифт Inter. */
public final class Render {
    public static final int BG_LIGHT = 0xCC1A1A24;
    public static final int TEXT = 0xFFFFFFFF;
    public static final int TEXT_DIM = 0xFF9A9AAE;

    /** Множитель прозрачности текущего HUD-элемента (1 вне HUD). Применяется только в rrect/text/fill/gradient. */
    public static float hudAlpha = 1f;

    private Render() {
    }

    private static int ha(int c) {
        if (hudAlpha >= 0.999f) {
            return c;
        }
        int a = (int) (((c >>> 24) & 0xFF) * hudAlpha);
        return (a << 24) | (c & 0x00FFFFFF);
    }

    public static void fill(DrawContext ctx, int x1, int y1, int x2, int y2, int color) {
        ctx.fill(x1, y1, x2, y2, ha(color));
    }

    public static void gradient(DrawContext ctx, int x1, int y1, int x2, int y2, int top, int bottom) {
        ctx.fillGradient(x1, y1, x2, y2, ha(top), ha(bottom));
    }

    public static TextRenderer font() {
        return MinecraftClient.getInstance().textRenderer;
    }

    /** Фон панелей; прозрачность берётся из настройки Client.Background. */
    public static int bg() {
        ClientSettings cs = ClientSettings.INSTANCE;
        double a = cs != null ? cs.background.get() : 0.8;
        return ((int) (a * 255) << 24) | Theme.dark(0.075f);
    }

    /** Акцентный цвет текущей темы; offset сдвигает фазу градиента. */
    public static int accent(double offset) {
        ClientSettings cs = ClientSettings.INSTANCE;
        double speed = cs != null ? cs.gradientSpeed.get() : 1.0;
        long now = System.currentTimeMillis();
        Theme.T th = Theme.current();
        if (Theme.rainbow(th)) {
            double h = (now / (5000.0 / Math.max(0.2, speed)) + offset * 0.08) % 1.0;
            return Theme.hsv((float) h, 0.6f, 1f);
        }
        double t = (Math.sin(now / 700.0 * speed + offset) + 1.0) / 2.0;
        return lerp(th.a(), th.b(), (float) t);
    }

    public static int lerp(int a, int b, float t) {
        int aa = (a >>> 24) & 0xFF, ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF;
        int ba = (b >>> 24) & 0xFF, br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF;
        int ra = (int) (aa + (ba - aa) * t);
        int rr = (int) (ar + (br - ar) * t);
        int rg = (int) (ag + (bg - ag) * t);
        int rb = (int) (ab + (bb - ab) * t);
        return (ra << 24) | (rr << 16) | (rg << 8) | rb;
    }

    public static int withAlpha(int color, float alpha) {
        int a = (int) (((color >>> 24) & 0xFF) * Math.max(0f, Math.min(1f, alpha)));
        return (a << 24) | (color & 0x00FFFFFF);
    }

    /** Прямоугольник со скруглёнными (срезанными) углами. */
    public static void rrect(DrawContext ctx, int x, int y, int w, int h, int color) {
        color = ha(color);
        if (w < 4 || h < 4) {
            ctx.fill(x, y, x + w, y + h, color);
            return;
        }
        ctx.fill(x + 2, y, x + w - 2, y + h, color);
        ctx.fill(x, y + 2, x + w, y + h - 2, color);
        ctx.fill(x + 1, y + 1, x + w - 1, y + h - 1, color);
    }

    private static boolean fontOk;
    private static long fontCheckedAt;
    private static String checkedChoice = "";

    /**
     * Проверка, что шрифт Inter реально отрисуется, а не покажет квадраты. У недогруженного или сломанного шрифта
     * все символы - один и тот же "пустой" глиф, поэтому: у разных букв должна быть разная ширина, а кириллица
     * или латиница не должна совпадать с шириной заведомо отсутствующего символа.
     * Результат пересматривается каждые 3 секунды (шрифты грузятся асинхронно при перезагрузке ресурсов),
     * так что ошибочный ответ в момент запуска игры сам исправляется.
     */
    private static boolean fontLoaded() {
        long now = System.currentTimeMillis();
        String choice = ClientSettings.INSTANCE != null ? ClientSettings.INSTANCE.font.get() : "";
        if (!choice.equals(checkedChoice)) {
            checkedChoice = choice;
            fontCheckedAt = 0;
        }
        if (fontCheckedAt != 0 && now - fontCheckedAt < 3000) {
            return fontOk;
        }
        fontCheckedAt = now;
        try {
            var f = font();
            int missing = f.getWidth(FontText.of("\uE0FE"));
            int narrow = f.getWidth(FontText.of("i"));
            int wide = f.getWidth(FontText.of("W"));
            int cyr = f.getWidth(FontText.of("\u0424"));
            int lat = f.getWidth(FontText.of("Z"));
            fontOk = narrow != wide && (cyr != missing || lat != missing);
        } catch (RuntimeException e) {
            fontOk = false;
        }
        return fontOk;
    }

    private static boolean customFont() {
        ClientSettings cs = ClientSettings.INSTANCE;
        return cs != null && !cs.font.is("Vanilla") && fontLoaded();
    }

    private static boolean shadow() {
        ClientSettings cs = ClientSettings.INSTANCE;
        return cs == null || cs.textShadow.get();
    }

    public static void text(DrawContext ctx, String s, int x, int y, int color) {
        color = ha(color);
        if (customFont()) {
            ctx.drawText(font(), FontText.of(s), x, y, color, shadow());
        } else {
            ctx.drawText(font(), s, x, y, color, shadow());
        }
    }

    public static int width(String s) {
        return customFont() ? font().getWidth(FontText.of(s)) : font().getWidth(s);
    }
}
