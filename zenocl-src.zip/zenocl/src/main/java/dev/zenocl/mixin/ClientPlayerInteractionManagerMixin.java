package dev.zenocl.mixin;

import dev.zenocl.core.ModuleManager;
import dev.zenocl.modules.combat.Criticals;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Единая точка всех атак игрока: сюда попадают и ручные удары, и KillAura/TriggerBot. */
@Mixin(ClientPlayerInteractionManager.class)
public class ClientPlayerInteractionManagerMixin {
    // require = 0: если метод в этой версии называется иначе, игра не падает, а Criticals просто не срабатывает
    @Inject(method = "attackEntity", at = @At("HEAD"), cancellable = true, require = 0)
    private void zenocl$criticals(PlayerEntity player, Entity target, CallbackInfo ci) {
        var self = MinecraftClient.getInstance().player;
        if (self != null && player == self && ModuleManager.isOn(Criticals.class)) {
            if (ModuleManager.get(Criticals.class).beforeAttack(self, target)) {
                ci.cancel();
            }
        }
    }
}
