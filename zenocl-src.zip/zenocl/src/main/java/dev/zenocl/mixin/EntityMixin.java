package dev.zenocl.mixin;

import dev.zenocl.core.ModuleManager;
import dev.zenocl.modules.visual.SeeInvisible;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public class EntityMixin {
    // require = 0: если сигнатура изменится, игра не падает, SeeInvisible просто не работает
    @Inject(method = "isInvisibleTo", at = @At("HEAD"), cancellable = true, require = 0)
    private void zenocl$seeInvisible(PlayerEntity viewer, CallbackInfoReturnable<Boolean> cir) {
        if (viewer == MinecraftClient.getInstance().player && ModuleManager.isOn(SeeInvisible.class)) {
            cir.setReturnValue(false);
        }
    }
}
