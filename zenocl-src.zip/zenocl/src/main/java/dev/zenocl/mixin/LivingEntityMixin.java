package dev.zenocl.mixin;

import dev.zenocl.core.ModuleManager;
import dev.zenocl.modules.visual.Swing;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public class LivingEntityMixin {
    @Inject(method = "getHandSwingDuration", at = @At("RETURN"), cancellable = true, require = 0)
    private void zenocl$swing(CallbackInfoReturnable<Integer> cir) {
        if ((Object) this == MinecraftClient.getInstance().player && ModuleManager.isOn(Swing.class)) {
            cir.setReturnValue(ModuleManager.get(Swing.class).duration());
        }
    }
}
