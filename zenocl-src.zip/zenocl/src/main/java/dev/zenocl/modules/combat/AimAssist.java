package dev.zenocl.modules.combat;

import dev.zenocl.core.BoolSetting;
import dev.zenocl.core.Category;
import dev.zenocl.core.ModeSetting;
import dev.zenocl.core.Module;
import dev.zenocl.core.NumSetting;
import dev.zenocl.util.Rotations;
import dev.zenocl.util.Targets;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;

public class AimAssist extends Module {
    private final NumSetting range = add(new NumSetting("Range", 4.5, 1.0, 8.0, 0.1));
    private final NumSetting speed = add(new NumSetting("Speed", 12, 2, 90, 1));
    private final NumSetting fov = add(new NumSetting("FOV", 90, 10, 360, 5));
    private final ModeSetting aimPoint = add(new ModeSetting("AimPoint", "Chest", "Head", "Chest", "Legs"));
    private final BoolSetting onlyClick = add(new BoolSetting("OnlyClick", false));
    private final BoolSetting players = add(new BoolSetting("Players", true));
    private final BoolSetting mobs = add(new BoolSetting("Mobs", false));

    public AimAssist() {
        super("AimAssist", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc().currentScreen != null) {
            return;
        }
        if (onlyClick.get() && !mc().options.attackKey.isPressed()) {
            return;
        }
        LivingEntity t = Targets.pick(range.get(), players.get(), mobs.get(), false, false, fov.get());
        if (t == null) {
            return;
        }
        Targets.mark(t);
        // человеческое наведение: затухание у цели, шум скорости, шаг мыши (GCD); speed - потолок градусов за тик
        var aim = t.getEntityPos().add(0, t.getHeight() * (aimPoint.is("Head") ? 0.9 : aimPoint.is("Legs") ? 0.25 : 0.7), 0);
        Rotations.faceHuman(mc().player, aim, speed.getFloat() * 20f, 10f, 0.05f, 0.4f, true);
    }
}
