package dev.zenocl.modules.combat;

import dev.zenocl.core.Category;
import dev.zenocl.core.Module;
import dev.zenocl.core.NumSetting;
import net.minecraft.text.Text;

/** Выходит с сервера, когда здоровье падает ниже порога. */
public class AutoLog extends Module {
    private final NumSetting health = add(new NumSetting("Health", 5, 1, 19, 1));

    public AutoLog() {
        super("AutoLog", Category.COMBAT);
    }

    @Override
    public void onTick() {
        var p = mc().player;
        if (p.getHealth() + p.getAbsorptionAmount() <= health.getFloat() && p.networkHandler != null) {
            setEnabled(false);
            p.networkHandler.getConnection().disconnect(Text.literal("[ZenoCL] AutoLog: HP " + (int) p.getHealth()));
        }
    }
}
