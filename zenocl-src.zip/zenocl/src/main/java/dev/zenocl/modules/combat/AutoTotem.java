package dev.zenocl.modules.combat;

import dev.zenocl.core.Category;
import dev.zenocl.core.Module;
import dev.zenocl.core.NumSetting;
import dev.zenocl.util.Inv;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

public class AutoTotem extends Module {
    private final NumSetting health = add(new NumSetting("Health", 20, 1, 20, 1));
    private final NumSetting delay = add(new NumSetting("Delay", 2, 0, 10, 1));
    private int timer;

    public AutoTotem() {
        super("AutoTotem", Category.COMBAT);
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc().player;
        if (timer > 0) {
            timer--;
            return;
        }
        if (p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) {
            return;
        }
        if (p.getHealth() + p.getAbsorptionAmount() > health.getFloat()) {
            return;
        }
        int idx = Inv.findAny(p, Items.TOTEM_OF_UNDYING);
        if (idx < 0) {
            return;
        }
        // SWAP с кнопкой 40 = обмен с левой рукой
        mc().interactionManager.clickSlot(p.playerScreenHandler.syncId, Inv.toScreenSlot(idx), 40, SlotActionType.SWAP, p);
        timer = delay.getInt();
    }
}
