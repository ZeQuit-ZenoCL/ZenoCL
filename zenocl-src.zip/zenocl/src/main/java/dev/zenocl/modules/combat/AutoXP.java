package dev.zenocl.modules.combat;

import dev.zenocl.core.BoolSetting;
import dev.zenocl.core.Category;
import dev.zenocl.core.Module;
import dev.zenocl.core.NumSetting;
import dev.zenocl.util.Inv;
import dev.zenocl.util.Throw;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

/** Чинит броню бутылками опыта, когда рядом нет врагов. */
public class AutoXP extends Module {
    private static final EquipmentSlot[] ARMOR = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    private static final double SAFE_RADIUS = 10.0;
    private final NumSetting damaged = add(new NumSetting("DamagedPercent", 30, 5, 90, 5));
    private final NumSetting delay = add(new NumSetting("Delay", 3, 1, 20, 1));
    private final BoolSetting onlySafe = add(new BoolSetting("OnlyWhenSafe", true));
    private int timer;

    public AutoXP() {
        super("AutoXP", Category.COMBAT);
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc().player;
        if (timer > 0) {
            timer--;
            return;
        }
        int slot = Inv.findHotbar(p, Items.EXPERIENCE_BOTTLE);
        if (mc().currentScreen != null || slot < 0 || !needsRepair(p) || (onlySafe.get() && enemyNear(p))) {
            return;
        }
        Throw.use(p, slot, 90f);
        timer = delay.getInt();
    }

    private boolean needsRepair(ClientPlayerEntity p) {
        for (EquipmentSlot es : ARMOR) {
            ItemStack s = p.getEquippedStack(es);
            if (!s.isEmpty() && s.isDamaged() && s.getDamage() * 100 > s.getMaxDamage() * damaged.getInt()) {
                return true;
            }
        }
        return false;
    }

    private boolean enemyNear(ClientPlayerEntity p) {
        for (PlayerEntity o : mc().world.getPlayers()) {
            if (o != p && o.distanceTo(p) < SAFE_RADIUS) {
                return true;
            }
        }
        return false;
    }
}
