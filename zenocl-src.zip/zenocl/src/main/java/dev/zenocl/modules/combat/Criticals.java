package dev.zenocl.modules.combat;

import dev.zenocl.core.BoolSetting;
import dev.zenocl.core.Category;
import dev.zenocl.core.ModeSetting;
import dev.zenocl.core.Module;
import dev.zenocl.util.Crits;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

/**
 * Критические удары с земли. Перед каждым ударом (своим, KillAura, TriggerBot - хук стоит на самом attackEntity)
 * на сервер уходят два пакета позиции: на долю блока вверх и обратно, оба с onGround=false.
 * Сервер видит падение (fallDistance > 0, не на земле) и засчитывает крит; на клиенте игрок не двигается.
 * Не срабатывает, если игрок и так падает, в воде, на лестнице, в транспорте или ослеплён.
 * Сервер не даёт крит в спринте, поэтому спринт перед ударом снимается (настройка Unsprint).
 * Серверные античиты, которые проверяют onGround и дальность прыжка, такие пакеты могут флагать.
 */
public class Criticals extends Module {
    private final ModeSetting mode = add(new ModeSetting("Mode", "Packet", "Packet", "Mini"));
    private final BoolSetting unsprint = add(new BoolSetting("Unsprint", true));

    public Criticals() {
        super("Criticals", Category.COMBAT);
    }

    /** Вызывается из ClientPlayerInteractionManagerMixin перед каждой атакой. */
    public void beforeAttack(ClientPlayerEntity p, Entity target) {
        if (!(target instanceof LivingEntity) || !p.isOnGround()) {
            // в воздухе падение уже настоящее: Crits.canCrit решает, нужен ли хоть что-то (достаточно снять спринт)
            if (!(target instanceof LivingEntity) || !Crits.canCrit(p)) {
                return;
            }
            if (unsprint.get()) {
                Crits.unsprint(p);
            }
            return;
        }
        if (p.isTouchingWater() || p.isInLava() || p.isClimbing() || p.hasVehicle()) {
            return;
        }
        ClientPlayNetworkHandler net = MinecraftClient.getInstance().getNetworkHandler();
        if (net == null) {
            return;
        }
        if (unsprint.get()) {
            Crits.unsprint(p);
        }
        double x = p.getX();
        double y = p.getY();
        double z = p.getZ();
        boolean hc = p.horizontalCollision;
        double up = mode.is("Mini") ? 0.0111 : 0.0625;
        net.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(x, y + up, z, false, hc));
        net.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(x, y, z, false, hc));
    }
}
