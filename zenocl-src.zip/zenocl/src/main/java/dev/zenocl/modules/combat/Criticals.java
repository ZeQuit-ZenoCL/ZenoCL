package dev.zenocl.modules.combat;

import dev.zenocl.core.BoolSetting;
import dev.zenocl.core.Category;
import dev.zenocl.core.ModeSetting;
import dev.zenocl.core.Module;
import dev.zenocl.util.Crits;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

/**
 * Критические удары. Legit (по умолчанию) - только настоящие: удар ждёт падения после прыжка, без ложных пакетов.
 * Packet/Mini - с земли: перед ударом на сервер уходят два пакета позиции: чуть вверх и обратно, оба "не на земле".
 * Сервер видит падение и засчитывает крит; на клиенте игрок не двигается. Хук стоит на самом attackEntity (ручные удары,
 * KillAura, TriggerBot). Сервер не даёт крит в спринте, поэтому спринт снимается (Unsprint).
 * Античиты, которые проверяют onGround и высоту прыжка, такие пакеты могут флагать.
 */
public class Criticals extends Module {
    private static long lastFake;
    private final ModeSetting mode = add(new ModeSetting("Mode", "Legit", "Legit", "Packet", "Mini"));
    private final BoolSetting autoJump = add(new BoolSetting("AutoJump", true));
    private final BoolSetting unsprint = add(new BoolSetting("Unsprint", true));

    public Criticals() {
        super("Criticals", Category.COMBAT);
        autoJump.showIf(() -> mode.is("Legit"));
    }

    /** Пакетный крит; вызывается и из KillAura (режим Crits: Packet), независимо от включения модуля. */
    public static void fake(ClientPlayerEntity p, boolean unsprint, boolean mini) {
        if (p.isTouchingWater() || p.isInLava() || p.isClimbing() || p.hasVehicle()) {
            return;
        }
        if (!p.isOnGround()) {
            // в воздухе падение настоящее; нужно лишь снять спринт
            if (Crits.canCrit(p) && unsprint) {
                Crits.unsprint(p);
            }
            return;
        }
        ClientPlayNetworkHandler net = MinecraftClient.getInstance().getNetworkHandler();
        if (net == null) {
            return;
        }
        if (unsprint) {
            Crits.unsprint(p);
        }
        double x = p.getX();
        double y = p.getY();
        double z = p.getZ();
        boolean hc = p.horizontalCollision;
        double up = mini ? 0.0111 : 0.0625;
        net.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(x, y + up, z, false, hc));
        net.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(x, y, z, false, hc));
        lastFake = System.nanoTime();
    }

    /**
     * Вызывается из ClientPlayerInteractionManagerMixin перед каждой атакой.
     * Legit: удар разрешён, только когда крит настоящий (игрок падает), иначе он отменяется, а при AutoJump игрок прыгает сам -
     * сервер видит только обычную физику, подмены пакетов нет. Packet/Mini: ложные пакеты позиции, дают крит с земли, но античиты с проверкой физики их флагают.
     * @return true - атаку нужно отменить
     */
    public boolean beforeAttack(ClientPlayerEntity p, Entity target) {
        if (!(target instanceof LivingEntity)) {
            return false;
        }
        if (mode.is("Legit")) {
            if (Crits.cannotCrit(p) || Crits.canCrit(p)) {
                if (unsprint.get() && Crits.canCrit(p)) {
                    Crits.unsprint(p);
                }
                return false;
            }
            if (autoJump.get() && p.isOnGround() && !p.isSneaking()) {
                p.jump();
            }
            return true;
        }
        // KillAura уже отправила пакеты для этого удара
        if (System.nanoTime() - lastFake < 80_000_000L) {
            return false;
        }
        fake(p, unsprint.get(), mode.is("Mini"));
        return false;
    }
}
