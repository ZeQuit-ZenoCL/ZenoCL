package dev.zenocl.modules.combat;

import dev.zenocl.core.BoolSetting;
import dev.zenocl.core.Category;
import dev.zenocl.core.ModeSetting;
import dev.zenocl.core.Module;
import dev.zenocl.core.NumSetting;
import dev.zenocl.util.Crits;
import dev.zenocl.util.EvaRot;
import dev.zenocl.util.Inv;
import dev.zenocl.util.Rotations;
import dev.zenocl.util.SilentRot;
import dev.zenocl.util.Targets;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class KillAura extends Module {
    private final NumSetting range = add(new NumSetting("Range", 3.0, 1.0, 6.0, 0.1));
    private final NumSetting fov = add(new NumSetting("FOV", 360, 30, 360, 10));
    private final NumSetting turn = add(new NumSetting("TurnSpeed", 90, 10, 180, 5));
    private final ModeSetting priority = add(new ModeSetting("Priority", "Distance", "Distance", "Health"));
    private final ModeSetting crits = add(new ModeSetting("Crits", "Smart", "Smart", "Packet", "Off", "Falling", "Jump"));
    private final ModeSetting rotation = add(new ModeSetting("Rotation", "Server", "Server", "Snap", "Linear", "Matrix2", "Vulcan", "HolyWorld", "SpookyTime", "FunTime", "LonyGrief", "Smooth", "Grim", "Matrix", "HvH", "Silent", "None"));
    private final ModeSetting aimPoint = add(new ModeSetting("AimPoint", "Chest", "Head", "Chest", "Legs"));
    private final NumSetting jitter = add(new NumSetting("Jitter", 0.0, 0.0, 0.3, 0.02));
    private final NumSetting hitChance = add(new NumSetting("HitChance", 100, 10, 100, 5));
    private final BoolSetting throughWalls = add(new BoolSetting("ThroughWalls", true));
    private final BoolSetting cooldown = add(new BoolSetting("Cooldown", true));
    private final BoolSetting sprintReset = add(new BoolSetting("SprintReset", true));
    private final BoolSetting autoWeapon = add(new BoolSetting("AutoWeapon", true));
    private final BoolSetting noEat = add(new BoolSetting("NoAttackIfEat", false));
    private final BoolSetting unblock = add(new BoolSetting("AlwaysShield", false));
    private final BoolSetting shieldBreak = add(new BoolSetting("ShieldBreak", true));
    private final BoolSetting players = add(new BoolSetting("Players", true));
    private final BoolSetting mobs = add(new BoolSetting("Mobs", false));
    private final BoolSetting invisible = add(new BoolSetting("Invisible", true));

    /** Шум скорости поворота 0..1 (режимы Smooth/Grim/Matrix): ровная скорость - признак программы. */
    private final NumSetting rotNoise = add(new NumSetting("RotationNoise", 0.3, 0.0, 1.0, 0.05));
    /** Квантование поворота под шаг мыши. В Grim и Matrix включено всегда, для Smooth - по этой настройке. */
    private final BoolSetting gcdFix = add(new BoolSetting("GcdFix", true));
    private final NumSetting smooth = add(new NumSetting("Smoothness", 14, 4, 40, 1));
    // Target: персонаж прыгает и очень быстро бегает по кругу вокруг цели (скорость в блоках за тик)
    private final BoolSetting orbit = add(new BoolSetting("Target", false));
    private final NumSetting orbitSpeed = add(new NumSetting("OrbitSpeed", 0.8, 0.2, 2.0, 0.05));
    private final NumSetting orbitRadius = add(new NumSetting("OrbitRadius", 2.5, 1.0, 4.0, 0.1));
    private final BoolSetting behind = add(new BoolSetting("Behind", false));
    private final BoolSetting orbitJump = add(new BoolSetting("OrbitJump", true));
    private int orbitSign = 1;
    private int orbitFlip;
    private final BoolSetting rayCheck = add(new BoolSetting("RayCheck", true));
    private final BoolSetting targetLock = add(new BoolSetting("TargetLock", true));
    private LivingEntity lock;
    private Vec3d serverAim;
    // режим Client: тик лишь выбирает точку, а камера плавно доворачивается каждый кадр (frame)
    private Vec3d aimTarget;
    private long aimStamp;
    private long lastFrame = System.nanoTime();

    public KillAura() {
        super("KillAura", Category.COMBAT);
        orbitSpeed.showIf(() -> orbit.get() || behind.get());
        orbitRadius.showIf(() -> orbit.get() || behind.get());
        orbitJump.showIf(() -> orbit.get() || behind.get());
    }

    @Override
    public void onDisable() {
        lock = null;
        orbitFlip = 0;
        aimTarget = null;
        Rotations.resetHuman();
    }

    /** Точный (с шагом мыши) поворот на сервер без изменения камеры: сервер видит удар строго в цель. */
    private void sendServerRotation(ClientPlayerEntity p, Vec3d aim) {
        var net = mc().getNetworkHandler();
        if (net == null) {
            return;
        }
        float[] r = Rotations.to(p.getEyePos(), aim);
        float g = Rotations.gcdStep();
        float ly = SilentRot.serverYaw(p);
        float lp = SilentRot.serverPitch(p);
        float yaw = ly + Math.round(MathHelper.wrapDegrees(r[0] - ly) / g) * g;
        float pitch = MathHelper.clamp(lp + Math.round((r[1] - lp) / g) * g, -90f, 90f);
        net.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(yaw, pitch, p.isOnGround(), p.horizontalCollision));
        SilentRot.sent(yaw, pitch);
    }

    /** Режимы, где камера доворачивается каждый кадр, а тик лишь выбирает точку. */
    private boolean perFrame() {
        return rotation.is("Smooth") || rotation.is("Grim") || rotation.is("Matrix");
    }

    /** Вызывается каждый кадр из HUD-колбэка: поворот камеры не зависит от 20 тиков в секунду. */
    public void frame() {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - lastFrame) / 1.0e9f);
        lastFrame = now;
        ClientPlayerEntity p = mc().player;
        // точка устаревает за 150 мс: цель пропала - камера сразу отпускается
        if (!isEnabled() || p == null || aimTarget == null || now - aimStamp > 150_000_000L
                || !perFrame() || mc().currentScreen != null) {
            if (aimTarget != null && now - aimStamp > 150_000_000L) {
                Rotations.resetHuman(); // цель потеряна: накопленный остаток квантования не должен дёрнуть камеру при новой цели
            }
            return;
        }
        float cap = turn.getFloat() * 20f;
        float sharp = smooth.getFloat();
        float noise = 0f;
        boolean gcd = gcdFix.get();
        if (rotation.is("Grim")) {
            // потолок 25 град/тик, мягче сближение, шум скорости, шаг мыши
            cap = Math.min(cap, 500f);
            sharp = Math.min(sharp, 12f);
            noise = rotNoise.getFloat();
            gcd = true;
        } else if (rotation.is("Matrix")) {
            // потолок 18 град/тик, ещё мягче, шум не меньше 0.4, редкие микро-паузы
            cap = Math.min(cap, 360f);
            sharp = Math.min(sharp, 9f);
            noise = Math.max(rotNoise.getFloat(), 0.4f);
            gcd = true;
            if (Math.random() < 0.03) {
                return;
            }
        } else {
            noise = rotNoise.getFloat() * 0.5f;
        }
        Rotations.faceHuman(p, aimTarget, cap, sharp, dt, noise, gcd);
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc().player;
        if (mc().currentScreen != null) {
            return;
        }
        // дальность считаем до хитбокса: именно так сервер проверяет досягаемость удара
        LivingEntity t = keepLock(p);
        if (t == null) {
            t = Targets.pick(range.get(), players.get(), mobs.get(), invisible.get(), priority.is("Health"), fov.get(), true);
            lock = t;
        }
        if (t == null) {
            return;
        }
        if (!throughWalls.get() && !p.canSee(t)) {
            return;
        }
        Targets.mark(t);
        if (orbit.get() || behind.get()) {
            orbit(p, t);
        }
        Vec3d aim = aimPoint(p, t);
        // Server: камера не двигается, точный поворот уходит на сервер отдельным пакетом прямо перед ударом
        serverAim = rotation.is("Server") ? aim : null;
        boolean ready = !cooldown.get() || p.getAttackCooldownProgress(0.5f) >= 0.93f;
        if (EvaRot.has(rotation.get())) {
            evaRotate(p, t, aim, ready);
        } else if (perFrame()) {
            aimTarget = aim;
            aimStamp = System.nanoTime();
        } else if (rotation.is("HvH")) {
            // резкий режим: до TurnSpeed градусов за тик по каждой оси, камера двигается раз в тик
            Rotations.aim(p, aim, turn.getFloat(), "Client");
        } else {
            Rotations.aim(p, aim, turn.getFloat(), rotation.get());
        }
        pickWeapon(p, t);

        if (Math.random() * 100.0 >= hitChance.get()) {
            return;
        }
        if (!ready || (noEat.get() && p.isUsingItem() && !p.isBlocking())) {
            return;
        }
        // Удар уходит сразу, а повёрнутые углы доходят до сервера только со следующим пакетом движения.
        // Поэтому бьём лишь когда последние ОТПРАВЛЕННЫЕ углы уже смотрят в цель - иначе сервер видит удар под старым углом.
        if (serverAim != null) {
            sendServerRotation(p, serverAim);
        }
        if (rayCheck.get() && !onTarget(p, t)) {
            return;
        }

        // Крит-режимы: Falling ждёт падения, Jump сам прыгает с земли и бьёт в падении
        if (unblock.get() && p.isBlocking()) {
            mc().interactionManager.stopUsingItem(p);
        }
        if (crits.is("Packet")) {
            Criticals.fake(p, true, false);
        } else if (crits.is("Smart")) {
            // как в EvaWare: на земле без прыжка бьём сразу, в воздухе ждём падения; в воде, на лестнице и т.п. крита нет - бьём обычно
            boolean grounded = p.isOnGround() && !mc().options.jumpKey.isPressed();
            if (!grounded && !Crits.canCrit(p) && !noCrit(p)) {
                return;
            }
            if (!grounded) {
                Crits.unsprint(p);
            }
        } else if (!crits.is("Off")) {
            if (crits.is("Jump") && p.isOnGround() && !p.isSneaking()) {
                p.jump();
                return;
            }
            if (!Crits.canCrit(p)) {
                return;
            }
            Crits.unsprint(p);
        } else if (sprintReset.get()) {
            Crits.unsprint(p);
        }

        // Criticals (Legit) отменил удар на земле и сам прыгнул: взмах без удара не отправляем
        if (dev.zenocl.core.ModuleManager.isOn(Criticals.class) && dev.zenocl.core.ModuleManager.get(Criticals.class).beforeAttack(p, t)) {
            return;
        }
        mc().interactionManager.attackEntity(p, t);
        p.swingHand(Hand.MAIN_HAND);
    }

    private static boolean noCrit(ClientPlayerEntity p) {
        return p.hasStatusEffect(net.minecraft.entity.effect.StatusEffects.BLINDNESS)
                || p.hasStatusEffect(net.minecraft.entity.effect.StatusEffects.LEVITATION)
                || p.hasStatusEffect(net.minecraft.entity.effect.StatusEffects.SLOW_FALLING)
                || p.isInLava() || p.isClimbing() || p.hasVehicle() || p.isSubmergedInWater()
                || p.hasNoGravity() || p.getAbilities().flying;
    }

    /** Режимы из EvaWare: пошагово считаем новые углы от последних отправленных серверу и отдаём их тихо, камера не двигается. */
    private void evaRotate(ClientPlayerEntity p, LivingEntity t, Vec3d aim, boolean canAttack) {
        float[] want = Rotations.to(p.getEyePos(), aim);
        float cy = SilentRot.serverYaw(p);
        float cp = SilentRot.serverPitch(p);
        boolean touching = p.getBoundingBox().expand(0.05).intersects(t.getBoundingBox());
        boolean moving = p.forwardSpeed != 0f || p.sidewaysSpeed != 0f;
        var ctx = new EvaRot.Ctx(onTarget(p, t), touching, canAttack, moving, p.age, (float) p.distanceTo(t), range.getFloat(), p.getYaw());
        float[] r = EvaRot.step(rotation.get(), cy, cp, want[0], want[1], ctx);
        if (r == null) {
            return;
        }
        // шаг мыши (GCD): углы кратны чувствительности, как при настоящем движении мыши
        float g = Rotations.gcdStep();
        float yaw = cy + Math.round(MathHelper.wrapDegrees(r[0] - cy) / g) * g;
        float pitch = MathHelper.clamp(cp + Math.round((r[1] - cp) / g) * g, -90f, 90f);
        SilentRot.set(yaw, pitch);
    }

    /** Бег по окружности вокруг цели: угловая скорость = OrbitSpeed / радиус, при упоре в стену направление меняется. */
    private void orbit(ClientPlayerEntity p, LivingEntity t) {
        if (p.hasVehicle() || p.isTouchingWater() || p.isClimbing()) {
            return;
        }
        if (p.horizontalCollision && orbitFlip <= 0) {
            orbitSign = -orbitSign;
            orbitFlip = 8;
        }
        if (orbitFlip > 0) {
            orbitFlip--;
        }
        // радиус не больше дальности удара, иначе по кругу бежали бы вне досягаемости
        double r = Math.min(orbitRadius.get(), range.get() + 0.2);
        double speed = orbitSpeed.get();
        double angle = Math.atan2(p.getZ() - t.getZ(), p.getX() - t.getX()) + orbitSign * (speed / r);
        if (behind.get()) {
            // позиция строго за спиной цели: противоположна её взгляду (корпус), поэтому цель не видит нас перед собой
            double back = Math.toRadians(t.getBodyYaw() + 90.0) + Math.PI;
            double diff = MathHelper.wrapDegrees((float) Math.toDegrees(back - Math.atan2(p.getZ() - t.getZ(), p.getX() - t.getX())));
            angle = Math.atan2(p.getZ() - t.getZ(), p.getX() - t.getX()) + Math.toRadians(MathHelper.clamp(diff, -(float) Math.toDegrees(speed / r), (float) Math.toDegrees(speed / r)));
        }
        double mx = t.getX() + Math.cos(angle) * r - p.getX();
        double mz = t.getZ() + Math.sin(angle) * r - p.getZ();
        double len = Math.sqrt(mx * mx + mz * mz);
        if (len > speed) {
            mx = mx / len * speed;
            mz = mz / len * speed;
        }
        if (orbitJump.get() && p.isOnGround()) {
            p.jump();
        }
        Vec3d v = p.getVelocity();
        p.setVelocity(v.x + (mx - v.x) * 0.6, v.y, v.z + (mz - v.z) * 0.6);
    }

    /** Держит текущую цель, пока она жива и в зоне: без метаний между двумя близкими игроками. */
    private LivingEntity keepLock(ClientPlayerEntity p) {
        LivingEntity l = lock;
        if (!targetLock.get() || l == null || l.isRemoved() || !Targets.valid(l, players.get(), mobs.get(), invisible.get())) {
            return null;
        }
        if (Targets.reachDist(l) > range.get() + 0.25) {
            return null;
        }
        if (fov.get() < 360 && Targets.angleTo(l) > fov.get() / 2.0) {
            return null;
        }
        return l;
    }

    /** Точка на хитбоксе, ближайшая к глазам на выбранной высоте: луч в неё всегда попадает в цель. */
    private Vec3d aimPoint(ClientPlayerEntity p, LivingEntity t) {
        double aimY = aimPoint.is("Head") ? 0.9 : aimPoint.is("Legs") ? 0.25 : 0.65;
        Box b = t.getBoundingBox();
        Vec3d eye = p.getEyePos();
        double j = jitter.get();
        // небольшой шум точки прицеливания: движения выглядят живее; запас 0.1 от края, чтобы не промахиваться по краю
        double x = MathHelper.clamp(eye.x + (Math.random() - 0.5) * j * 2, b.minX + 0.1, b.maxX - 0.1);
        double z = MathHelper.clamp(eye.z + (Math.random() - 0.5) * j * 2, b.minZ + 0.1, b.maxZ - 0.1);
        return new Vec3d(x, b.minY + t.getHeight() * aimY, z);
    }

    /** Попадает ли луч из глаз по последним отправленным серверу углам в хитбокс цели в пределах дальности. */
    private boolean onTarget(ClientPlayerEntity p, LivingEntity t) {
        Vec3d eye = p.getEyePos();
        Vec3d end = eye.add(Vec3d.fromPolar(SilentRot.serverPitch(p), SilentRot.serverYaw(p)).multiply(range.get()));
        return t.getBoundingBox().expand(0.05).raycast(eye, end).isPresent();
    }

    private void pickWeapon(ClientPlayerEntity p, LivingEntity t) {
        int slot = -1;
        if (shieldBreak.get() && t instanceof PlayerEntity pl && pl.isBlocking()) {
            slot = Inv.findBestHotbar(p, "_axe");
        }
        if (slot < 0 && autoWeapon.get() && !Inv.isWeapon(p.getMainHandStack())) {
            slot = Inv.findBestHotbar(p, "_sword");
            if (slot < 0) {
                slot = Inv.findBestHotbar(p, "_axe");
            }
        }
        if (slot >= 0 && slot != p.getInventory().getSelectedSlot()) {
            p.getInventory().setSelectedSlot(slot);
        }
    }
}
