package dev.zenocl.modules.combat;

import dev.zenocl.core.Category;
import dev.zenocl.core.Module;
import dev.zenocl.core.NumSetting;
import dev.zenocl.util.Inv;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/** Окружает ноги обсидианом с четырёх сторон (защита от краст-атак по блокам вокруг). */
public class Surround extends Module {
    private static final Direction[] SIDES = {Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST};
    private final NumSetting perTick = add(new NumSetting("PerTick", 2, 1, 4, 1));

    public Surround() {
        super("Surround", Category.COMBAT);
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc().player;
        if (mc().currentScreen != null || !p.isOnGround()) {
            return;
        }
        int slot = Inv.findHotbar(p, Items.OBSIDIAN);
        if (slot < 0) {
            return;
        }
        BlockPos base = p.getBlockPos();
        int prev = p.getInventory().getSelectedSlot();
        int placed = 0;
        for (Direction d : SIDES) {
            if (placed >= perTick.getInt()) {
                break;
            }
            BlockPos pos = base.offset(d);
            BlockPos support = pos.down();
            // ставим только в свободную клетку при наличии опоры снизу
            if (!mc().world.getBlockState(pos).isReplaceable() || mc().world.getBlockState(support).isReplaceable()) {
                continue;
            }
            p.getInventory().setSelectedSlot(slot);
            Vec3d hit = new Vec3d(support.getX() + 0.5, support.getY() + 1.0, support.getZ() + 0.5);
            mc().interactionManager.interactBlock(p, Hand.MAIN_HAND, new BlockHitResult(hit, Direction.UP, support, false));
            p.swingHand(Hand.MAIN_HAND);
            placed++;
        }
        if (placed > 0) {
            p.getInventory().setSelectedSlot(prev);
        }
    }
}
