package dev.zenocl.modules.misc;

import dev.zenocl.core.Category;
import dev.zenocl.core.Module;
import dev.zenocl.core.NumSetting;
import net.minecraft.util.Hand;

public class AntiAFK extends Module {
    private final NumSetting seconds = add(new NumSetting("Interval", 20, 5, 120, 5));
    private int ticks;

    public AntiAFK() {
        super("AntiAFK", Category.MISC);
    }

    @Override
    public void onTick() {
        if (++ticks < seconds.getInt() * 20) {
            return;
        }
        ticks = 0;
        var p = mc().player;
        if (p.isOnGround()) {
            p.jump();
        }
        p.swingHand(Hand.MAIN_HAND);
    }
}
