package dev.zenocl.modules.misc;

import dev.zenocl.core.BoolSetting;
import dev.zenocl.core.Category;
import dev.zenocl.core.ModeSetting;
import dev.zenocl.core.Module;
import dev.zenocl.core.NumSetting;
import dev.zenocl.hud.Theme;

/** Общие настройки клиента (тема, фон, шрифт, префикс команд). Не включается/выключается. */
public class ClientSettings extends Module {
    public static ClientSettings INSTANCE;

    /** Профиль графики (Low/Medium/High/Ultra): см. hud.Graphics. */
    public final ModeSetting graphics = add(new ModeSetting("Graphics", "High", "Low", "Medium", "High", "Ultra"));
    public final ModeSetting theme = add(new ModeSetting("Theme", "Crimson", Theme.names()));
    // Цвета для темы Custom
    public final NumSetting r1 = add(new NumSetting("CustomR1", 224, 0, 255, 1));
    public final NumSetting g1 = add(new NumSetting("CustomG1", 20, 0, 255, 1));
    public final NumSetting b1 = add(new NumSetting("CustomB1", 60, 0, 255, 1));
    public final NumSetting r2 = add(new NumSetting("CustomR2", 138, 0, 255, 1));
    public final NumSetting g2 = add(new NumSetting("CustomG2", 15, 0, 255, 1));
    public final NumSetting b2 = add(new NumSetting("CustomB2", 36, 0, 255, 1));
    public final NumSetting gradientSpeed = add(new NumSetting("GradientSpeed", 1.0, 0.0, 4.0, 0.1));
    public final NumSetting background = add(new NumSetting("Background", 0.8, 0.3, 1.0, 0.05));
    /** Vanilla - шрифт игры (всегда читается). Inter и Machine (латиница и цифры, русский берётся из шрифта игры) - свои шрифты; если он не загрузился, текст сам возвращается на Vanilla. */
    public final ModeSetting font = add(new ModeSetting("Font", "Vanilla", "Vanilla", "Inter", "Machine"));
    public final BoolSetting textShadow = add(new BoolSetting("TextShadow", true));
    public final BoolSetting notifications = add(new BoolSetting("Notifications", true));
    public final BoolSetting chatFeedback = add(new BoolSetting("ChatFeedback", true));
    public final ModeSetting prefix = add(new ModeSetting("Prefix", ".", ".", ",", "-", "#"));

    public ClientSettings() {
        super("Client", Category.MISC);
        INSTANCE = this;
    }

    @Override
    public boolean isSettingsOnly() {
        return true;
    }
}
