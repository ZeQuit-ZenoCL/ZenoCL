package dev.zenocl.modules.misc;

import dev.zenocl.core.Category;
import dev.zenocl.core.Module;
import dev.zenocl.core.ModuleManager;

/** Одним нажатием выключает все функции клиента (и сам себя). */
public class Panic extends Module {
    public Panic() {
        super("Panic", Category.MISC);
    }

    @Override
    public void onTick() {
        for (Module m : ModuleManager.all()) {
            if (m != this && m.isEnabled() && !m.isSettingsOnly()) {
                m.setEnabled(false);
            }
        }
        setEnabled(false);
    }
}
