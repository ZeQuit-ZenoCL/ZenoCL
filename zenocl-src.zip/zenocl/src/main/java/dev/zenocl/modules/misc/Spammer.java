package dev.zenocl.modules.misc;

import dev.zenocl.core.BoolSetting;
import dev.zenocl.core.Category;
import dev.zenocl.core.ModeSetting;
import dev.zenocl.core.Module;
import dev.zenocl.core.NumSetting;
import dev.zenocl.core.TextSetting;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Отправляет в чат твои сообщения по кругу или в случайном порядке. Список задаётся чат-командами:
 * .spam add Текст | .spam remove НОМЕР | .spam list | .spam clear | .spam set Текст (оставить одно сообщение).
 * Сообщение, начинающееся с "/", отправляется как команда сервера.
 */
public class Spammer extends Module {
    private static final int TICKS_PER_SECOND = 20;
    private static final int MAX_LEN = 256;
    private static final int MAX_MESSAGES = 20;
    private final TextSetting messages = add(new TextSetting("Messages", "ZenoCL on top\ngg\nez"));
    private final ModeSetting order = add(new ModeSetting("Order", "Sequential", "Sequential", "Random"));
    private final NumSetting delay = add(new NumSetting("Delay", 8, 1, 120, 1));
    // суффикс обходит антиспам-фильтры, которые режут одинаковые сообщения
    private final BoolSetting random = add(new BoolSetting("RandomSuffix", false));
    private final Random rng = new Random();
    private int timer;
    private int index;

    public Spammer() {
        super("Spammer", Category.MISC);
    }

    public List<String> list() {
        List<String> out = new ArrayList<>();
        for (String s : messages.get().split("\n")) {
            if (!s.isBlank()) {
                out.add(s);
            }
        }
        return out;
    }

    private void store(List<String> l) {
        messages.set(String.join("\n", l));
    }

    /** @return текст ответа для чата, null - успех без пояснений. */
    public String add(String text) {
        List<String> l = list();
        if (l.size() >= MAX_MESSAGES) {
            return "Максимум сообщений: " + MAX_MESSAGES;
        }
        l.add(text.length() > MAX_LEN ? text.substring(0, MAX_LEN) : text);
        store(l);
        return null;
    }

    public boolean remove(int number) {
        List<String> l = list();
        if (number < 1 || number > l.size()) {
            return false;
        }
        l.remove(number - 1);
        store(l);
        return true;
    }

    public void clear() {
        store(new ArrayList<>());
    }

    @Override
    public void onTick() {
        if (mc().player == null || ++timer < delay.getInt() * TICKS_PER_SECOND) {
            return;
        }
        timer = 0;
        List<String> l = list();
        if (l.isEmpty()) {
            return;
        }
        String msg;
        if (order.is("Random")) {
            msg = l.get(rng.nextInt(l.size()));
        } else {
            index = index % l.size();
            msg = l.get(index++);
        }
        if (random.get() && !msg.startsWith("/")) {
            msg += " " + (1000 + rng.nextInt(9000));
        }
        if (msg.startsWith("/")) {
            mc().player.networkHandler.sendChatCommand(msg.substring(1));
        } else {
            mc().player.networkHandler.sendChatMessage(msg);
        }
    }

    @Override
    public void onEnable() {
        timer = 0;
        index = 0;
    }
}
