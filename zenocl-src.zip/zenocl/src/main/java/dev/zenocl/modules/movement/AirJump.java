package dev.zenocl.modules.movement;

import dev.zenocl.core.Category;
import dev.zenocl.core.Module;
import dev.zenocl.core.NumSetting;

/** Дополнительные прыжки в воздухе по нажатию пробела. */
public class AirJump extends Module {
    private static final double JUMP_VELOCITY = 0.42;
    private final NumSetting jumps = add(new NumSetting("Jumps", 2, 1, 10, 1));
    private final NumSetting delay = add(new NumSetting("Delay", 6, 2, 20, 1));
    private int used;
    private int cooldown;

    public AirJump() {
        super("AirJump", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        var p = mc().player;
        if (p.isOnGround()) {
            used = 0;
            cooldown = 0;
            return;
        }
        if (cooldown > 0) {
            cooldown--;
            return;
        }
        if (mc().options.jumpKey.isPressed() && used < jumps.getInt() && mc().currentScreen == null) {
            var v = p.getVelocity();
            p.setVelocity(v.x, JUMP_VELOCITY, v.z);
            p.fallDistance = 0f;
            used++;
            cooldown = delay.getInt();
        }
    }
}
