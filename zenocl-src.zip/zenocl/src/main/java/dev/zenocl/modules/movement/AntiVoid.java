package dev.zenocl.modules.movement;

import dev.zenocl.core.Category;
import dev.zenocl.core.Module;
import dev.zenocl.core.NumSetting;

/** Запоминает последнюю безопасную точку и возвращает игрока, если он падает в бездну. */
public class AntiVoid extends Module {
    private final NumSetting margin = add(new NumSetting("Depth", 4, 1, 30, 1));
    private double sx;
    private double sy;
    private double sz;
    private boolean hasSafe;

    public AntiVoid() {
        super("AntiVoid", Category.MOVEMENT);
    }

    @Override
    public void onEnable() {
        hasSafe = false;
    }

    @Override
    public void onTick() {
        var p = mc().player;
        int bottom = mc().world.getBottomY();
        if (p.isOnGround() && p.getY() > bottom + 2) {
            sx = p.getX();
            sy = p.getY();
            sz = p.getZ();
            hasSafe = true;
        } else if (hasSafe && p.getY() < bottom - margin.get()) {
            p.setPosition(sx, sy, sz);
            p.setVelocity(0, 0, 0);
            p.fallDistance = 0f;
        }
    }
}
