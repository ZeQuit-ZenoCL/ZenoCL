package dev.zenocl.modules.movement;

import dev.zenocl.core.Category;
import dev.zenocl.core.Module;
import dev.zenocl.core.NumSetting;

public class FastFall extends Module {
    private final NumSetting speed = add(new NumSetting("Speed", 1.2, 0.4, 3.0, 0.1));

    public FastFall() {
        super("FastFall", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        var p = mc().player;
        var v = p.getVelocity();
        if (!p.isOnGround() && v.y < -0.3 && p.fallDistance > 0.5f && !p.isTouchingWater()) {
            p.setVelocity(v.x, -speed.get(), v.z);
        }
    }
}
