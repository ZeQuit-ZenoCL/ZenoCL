package dev.zenocl.modules.movement;

import dev.zenocl.core.Category;
import dev.zenocl.core.Module;
import dev.zenocl.core.NumSetting;
import net.minecraft.util.math.Vec3d;

public class HighJump extends Module {
    private final NumSetting height = add(new NumSetting("Power", 0.8, 0.45, 2.0, 0.05));

    public HighJump() {
        super("HighJump", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        var p = mc().player;
        if (p.isOnGround() && mc().options.jumpKey.isPressed()) {
            Vec3d v = p.getVelocity();
            p.setVelocity(v.x, height.get(), v.z);
        }
    }
}
