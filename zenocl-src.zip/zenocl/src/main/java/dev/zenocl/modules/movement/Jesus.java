package dev.zenocl.modules.movement;

import dev.zenocl.core.BoolSetting;
import dev.zenocl.core.Category;
import dev.zenocl.core.ModeSetting;
import dev.zenocl.core.Module;
import dev.zenocl.core.NumSetting;
import net.minecraft.util.math.Vec3d;

/**
 * Vanilla - как зажатый прыжок в воде: каждый тик +0.04 вверх (ванильное всплытие). Держит у поверхности и плывёт,
 * ничего нестандартного серверу не отправляется. Solid - стоит на воде: толкает вверх, быстрее, но античиты это видят.
 */
public class Jesus extends Module {
    private final ModeSetting mode = add(new ModeSetting("Mode", "Vanilla", "Vanilla", "Solid"));
    private final NumSetting speed = add(new NumSetting("Speed", 1.0, 1.0, 1.6, 0.05));
    private final BoolSetting lava = add(new BoolSetting("Lava", false));

    public Jesus() {
        super("Jesus", Category.MOVEMENT);
        speed.showIf(() -> mode.is("Solid"));
    }

    @Override
    public void onTick() {
        var p = mc().player;
        if (p.isSneaking() || p.hasVehicle()) {
            return; // Shift - нырнуть
        }
        boolean inFluid = p.isTouchingWater() || (lava.get() && p.isInLava());
        if (!inFluid) {
            return;
        }
        Vec3d v = p.getVelocity();
        if (mode.is("Vanilla")) {
            p.setVelocity(v.x, v.y + 0.04, v.z);
        } else {
            p.setVelocity(v.x * speed.get(), Math.max(v.y, 0.11), v.z * speed.get());
        }
        p.fallDistance = 0f;
    }
}
