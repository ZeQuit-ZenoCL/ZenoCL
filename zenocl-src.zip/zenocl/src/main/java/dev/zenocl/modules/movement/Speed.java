package dev.zenocl.modules.movement;

import dev.zenocl.core.BoolSetting;
import dev.zenocl.core.Category;
import dev.zenocl.core.ModeSetting;
import dev.zenocl.core.Module;
import dev.zenocl.core.NumSetting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;

/**
 * Grim - только то, что может сделать честный игрок: спринт и прыжок в момент приземления, скорость не трогается.
 * Античит с симуляцией движения (Grim) предсказывает игрока по ванильной физике и флагает любое отклонение скорости,
 * поэтому здесь клиент ничего не подставляет в вектор движения. Прибавка небольшая: это спринт-бхоп как в ваниле.
 * Entity - Grim плюс прибавка от столкновений с сущностями. В ванили пересекающиеся сущности отталкивают друг друга
 * (до 0.05 блока за тик на каждую), а античит не знает точных позиций соседей и оставляет на это запас. Здесь прибавка
 * направлена по ходу движения и считается только пока хитбоксы реально пересекаются, не больше MaxEntities штук.
 * Работает рядом с игроками и мобами, в одиночку ничего не даёт. Принимает ли это конкретная версия античита - проверять на сервере.
 * Custom - ускорение поверх ванильной физики (множитель Boost, AirStrafe): быстрее, но на предсказывающих античитах флагает.
 */
public class Speed extends Module {
    private final ModeSetting mode = add(new ModeSetting("Mode", "Grim", "Grim", "Entity", "Custom"));
    private final NumSetting boost = add(new NumSetting("Boost", 1.10, 1.0, 1.6, 0.01));
    private final NumSetting strength = add(new NumSetting("Strength", 1.0, 0.5, 3.0, 0.1));
    private final NumSetting maxEntities = add(new NumSetting("MaxEntities", 2, 1, 4, 1));
    private final BoolSetting hop = add(new BoolSetting("Hop", true));
    private final BoolSetting airStrafe = add(new BoolSetting("AirStrafe", true));

    public Speed() {
        super("Speed", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        var p = mc().player;
        if (mode.is("Grim") || mode.is("Entity")) {
            // прыжок только вперёд в спринте: именно такой прыжок даёт ванильную прибавку, и он входит в набор действий игрока
            if (hop.get() && p.isOnGround() && mc().options.forwardKey.isPressed() && !Move.blocked(p)
                    && p.getHungerManager().getFoodLevel() > 6) {
                p.setSprinting(true);
                p.jump();
            }
            if (mode.is("Entity")) {
                entityPush(p);
            }
            return;
        }
        Move.run(p, boost.get(), hop.get(), airStrafe.get());
    }

    /** Прибавка по ходу движения за каждое реально пересекающееся с игроком тело (как ванильное отталкивание, но в нужную сторону). */
    private void entityPush(ClientPlayerEntity p) {
        if (!Move.moving() || Move.blocked(p)) {
            return;
        }
        int n = 0;
        for (Entity e : mc().world.getOtherEntities(p, p.getBoundingBox(), x -> x.isAlive() && !x.isSpectator() && x.isPushable())) {
            if (++n >= maxEntities.getInt()) {
                break;
            }
        }
        if (n == 0) {
            return;
        }
        double push = 0.05 * n * strength.get();
        double[] d = Move.dir();
        p.addVelocity(d[0] * push, 0, d[1] * push);
    }
}
