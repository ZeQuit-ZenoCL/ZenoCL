package dev.zenocl.modules.movement;

import dev.zenocl.core.BoolSetting;
import dev.zenocl.core.Category;
import dev.zenocl.core.ModeSetting;
import dev.zenocl.core.Module;
import dev.zenocl.core.NumSetting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;

/**
 * Legacy - постоянная скорость (как в первой версии): самый быстрый режим, но античиты с предсказанием его видят.
 * Grim - только законные действия: спринт и прыжок при приземлении, скорость не трогается.
 * Entity - Grim плюс прибавка от реальных столкновений с сущностями (до 0.05 блока за тик на каждую, по ходу движения).
 * Water - разгон в воде до WaterSpeed (нужно ведро воды в инвентаре, если включён NeedBucket).
 * Custom - множитель Boost к ванильной скорости и мгновенная смена направления в воздухе.
 * Какой режим пройдёт конкретную версию античита - проверять на сервере, гарантий нет.
 */
public class Speed extends Module {
    private final ModeSetting mode = add(new ModeSetting("Mode", "Grim", "Legacy", "Grim", "Entity", "Custom", "Water"));
    private final NumSetting speed = add(new NumSetting("Speed", 0.32, 0.1, 1.0, 0.01));
    private final BoolSetting hop = add(new BoolSetting("Hop", true));
    private final NumSetting boost = add(new NumSetting("Boost", 1.10, 1.0, 1.6, 0.01));
    private final BoolSetting airStrafe = add(new BoolSetting("AirStrafe", true));
    private final NumSetting strength = add(new NumSetting("Strength", 1.0, 0.5, 3.0, 0.1));
    private final NumSetting waterSpeed = add(new NumSetting("WaterSpeed", 0.6, 0.2, 1.2, 0.05));
    private final BoolSetting needBucket = add(new BoolSetting("NeedBucket", true));
    private final NumSetting maxEntities = add(new NumSetting("MaxEntities", 2, 1, 4, 1));

    public Speed() {
        super("Speed", Category.MOVEMENT);
        speed.showIf(() -> mode.is("Legacy"));
        boost.showIf(() -> mode.is("Custom"));
        airStrafe.showIf(() -> mode.is("Custom"));
        strength.showIf(() -> mode.is("Entity"));
        maxEntities.showIf(() -> mode.is("Entity"));
        waterSpeed.showIf(() -> mode.is("Water"));
        needBucket.showIf(() -> mode.is("Water"));
        hop.showIf(() -> !mode.is("Water"));
    }

    @Override
    public void onTick() {
        var p = mc().player;
        if (mode.is("Water")) {
            water(p);
        } else if (mode.is("Legacy")) {
            if (!Move.moving() || Move.blocked(p)) {
                return;
            }
            if (hop.get() && p.isOnGround()) {
                p.jump();
            }
            Move.set(p, speed.get(), Move.dir());
        } else if (mode.is("Custom")) {
            Move.run(p, boost.get(), hop.get(), airStrafe.get());
        } else {
            if (hop.get() && p.isOnGround() && mc().options.forwardKey.isPressed() && !Move.blocked(p)
                    && p.getHungerManager().getFoodLevel() > 6) {
                p.setSprinting(true);
                p.jump();
            }
            if (mode.is("Entity")) {
                entityPush(p);
            }
        }
    }

    /** В воде скорость нарастает на 0.05 за тик до WaterSpeed. NeedBucket: работает только при ведре воды в инвентаре. */
    private void water(ClientPlayerEntity p) {
        if (!p.isTouchingWater() || !Move.moving() || p.hasVehicle()) {
            return;
        }
        if (needBucket.get()) {
            boolean has = false;
            for (int i = 0; i < p.getInventory().size() && !has; i++) {
                has = p.getInventory().getStack(i).isOf(net.minecraft.item.Items.WATER_BUCKET);
            }
            if (!has) {
                return;
            }
        }
        var v = p.getVelocity();
        double cur = Math.sqrt(v.x * v.x + v.z * v.z);
        double target = Math.min(waterSpeed.get(), Math.max(cur, 0.1) + 0.05);
        double[] d = Move.dir();
        p.setVelocity(d[0] * target, v.y, d[1] * target);
    }

    /** Прибавка по ходу движения за каждое реально пересекающееся с игроком тело (как ванильное отталкивание, но в нужную сторону). */
    private void entityPush(ClientPlayerEntity p) {
        if (!Move.moving() || Move.blocked(p)) {
            return;
        }
        int n = 0;
        for (Entity e : mc().world.getOtherEntities(p, p.getBoundingBox(), x -> x.isAlive() && !x.isSpectator() && x.isPushable())) {
            if (++n >= maxEntities.getInt()) {
                break;
            }
        }
        if (n == 0) {
            return;
        }
        double push = 0.05 * n * strength.get();
        double[] d = Move.dir();
        p.addVelocity(d[0] * push, 0, d[1] * push);
    }
}
