package dev.zenocl.modules.movement;

import dev.zenocl.core.Category;
import dev.zenocl.core.ModeSetting;
import dev.zenocl.core.Module;
import dev.zenocl.core.NumSetting;
import net.minecraft.util.math.Vec3d;

/** Climb - лезет по стене со скоростью Speed (0.2 - как по лестнице). Hop - прыгает у стены с земли, поднимает на один блок. */
public class Spider extends Module {
    private final ModeSetting mode = add(new ModeSetting("Mode", "Climb", "Climb", "Hop"));
    private final NumSetting speed = add(new NumSetting("Speed", 0.2, 0.1, 0.6, 0.01));

    public Spider() {
        super("Spider", Category.MOVEMENT);
        speed.showIf(() -> mode.is("Climb"));
    }

    @Override
    public void onTick() {
        var p = mc().player;
        if (!p.horizontalCollision || p.isSneaking() || p.isClimbing()) {
            return;
        }
        if (mode.is("Hop")) {
            if (p.isOnGround()) {
                p.jump();
            }
            return;
        }
        Vec3d v = p.getVelocity();
        p.setVelocity(v.x, v.y + (speed.get() - v.y) * 0.7, v.z);
        p.fallDistance = 0f;
    }
}
