package dev.zenocl.modules.movement;

import dev.zenocl.core.Category;
import dev.zenocl.core.Module;

/** Сам запрыгивает на блоки, в которые упирается при ходьбе. */
public class Step extends Module {
    public Step() {
        super("Step", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        var p = mc().player;
        if (p.isOnGround() && p.horizontalCollision && Move.moving() && !p.isSneaking()) {
            p.jump();
        }
    }
}
