package dev.zenocl.modules.movement;

import dev.zenocl.core.Category;
import dev.zenocl.core.Module;

/** Управление в воздухе: направление меняется сразу, модуль скорости сохраняется (без искусственного разгона). */
public class Strafe extends Module {
    public Strafe() {
        super("Strafe", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        Move.run(mc().player, 1.0, false, true);
    }
}
