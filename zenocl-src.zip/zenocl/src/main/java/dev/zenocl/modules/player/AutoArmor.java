package dev.zenocl.modules.player;

import dev.zenocl.core.Category;
import dev.zenocl.core.Module;
import dev.zenocl.core.NumSetting;
import dev.zenocl.util.Inv;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

/** Надевает лучшую броню из инвентаря (по материалу: незерит > алмаз > железо ...). */
public class AutoArmor extends Module {
    private static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    private static final String[] SUFFIX = {"_helmet", "_chestplate", "_leggings", "_boots"};

    private final NumSetting delay = add(new NumSetting("Delay", 3, 1, 10, 1));
    private int timer;

    public AutoArmor() {
        super("AutoArmor", Category.PLAYER);
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc().player;
        if (mc().currentScreen != null) {
            return;
        }
        if (timer > 0) {
            timer--;
            return;
        }
        int sync = p.playerScreenHandler.syncId;
        for (int i = 0; i < 4; i++) {
            ItemStack worn = p.getEquippedStack(SLOTS[i]);
            if (worn.isOf(Items.ELYTRA)) {
                continue;
            }
            int wornTier = worn.isEmpty() ? -1 : Inv.tier(Inv.path(worn));

            int bestIdx = -1;
            int bestTier = wornTier;
            for (int s = 0; s < 36; s++) {
                String path = Inv.path(p.getInventory().getStack(s));
                if (path.endsWith(SUFFIX[i]) && Inv.tier(path) > bestTier) {
                    bestTier = Inv.tier(path);
                    bestIdx = s;
                }
            }
            if (bestIdx < 0) {
                continue;
            }
            if (worn.isEmpty()) {
                // shift-клик кладёт броню в пустой слот брони
                mc().interactionManager.clickSlot(sync, Inv.toScreenSlot(bestIdx), 0, SlotActionType.QUICK_MOVE, p);
            } else {
                // снимаем худшую, на следующем шаге наденется лучшая
                mc().interactionManager.clickSlot(sync, 5 + i, 0, SlotActionType.QUICK_MOVE, p);
            }
            timer = delay.getInt();
            return;
        }
    }
}
