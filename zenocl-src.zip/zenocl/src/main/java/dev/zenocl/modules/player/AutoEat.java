package dev.zenocl.modules.player;

import dev.zenocl.core.Category;
import dev.zenocl.core.Module;
import dev.zenocl.core.NumSetting;
import dev.zenocl.util.Inv;
import net.minecraft.item.Item;
import net.minecraft.item.Items;

/** Ест еду из хотбара, когда голод ниже порога, затем возвращает прежний слот. */
public class AutoEat extends Module {
    private static final Item[] FOOD = {
            Items.COOKED_BEEF, Items.COOKED_PORKCHOP, Items.COOKED_MUTTON, Items.COOKED_CHICKEN,
            Items.COOKED_SALMON, Items.COOKED_COD, Items.BAKED_POTATO, Items.BREAD,
            Items.GOLDEN_CARROT, Items.PUMPKIN_PIE, Items.CARROT, Items.APPLE
    };
    private final NumSetting hunger = add(new NumSetting("Hunger", 14, 1, 19, 1));
    private int prevSlot = -1;

    public AutoEat() {
        super("AutoEat", Category.PLAYER);
    }

    @Override
    public void onTick() {
        var p = mc().player;
        if (mc().currentScreen != null) {
            return;
        }
        if (prevSlot >= 0) {
            // доедаем, пока предмет используется и голод не полный
            if (!p.isUsingItem() || p.getHungerManager().getFoodLevel() >= 20) {
                finish();
            }
            return;
        }
        if (p.getHungerManager().getFoodLevel() > hunger.getInt()) {
            return;
        }
        for (Item food : FOOD) {
            int slot = Inv.findHotbar(p, food);
            if (slot >= 0) {
                prevSlot = p.getInventory().getSelectedSlot();
                p.getInventory().setSelectedSlot(slot);
                mc().options.useKey.setPressed(true);
                return;
            }
        }
    }

    @Override
    public void onDisable() {
        if (prevSlot >= 0) {
            finish();
        }
    }

    private void finish() {
        mc().options.useKey.setPressed(false);
        mc().player.getInventory().setSelectedSlot(prevSlot);
        prevSlot = -1;
    }
}
