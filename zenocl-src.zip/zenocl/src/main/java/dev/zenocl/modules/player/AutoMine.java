package dev.zenocl.modules.player;

import dev.zenocl.core.Category;
import dev.zenocl.core.Module;

/** Удерживает кнопку атаки: непрерывная добыча блока, на который смотришь. */
public class AutoMine extends Module {
    public AutoMine() {
        super("AutoMine", Category.PLAYER);
    }

    @Override
    public void onTick() {
        if (mc().currentScreen == null) {
            mc().options.attackKey.setPressed(true);
        }
    }

    @Override
    public void onDisable() {
        mc().options.attackKey.setPressed(false);
    }
}
