package dev.zenocl.modules.player;

import dev.zenocl.core.Category;
import dev.zenocl.core.Module;

public class AutoRespawn extends Module {
    public AutoRespawn() {
        super("AutoRespawn", Category.PLAYER);
    }

    @Override
    public void onTick() {
        if (mc().player.isDead()) {
            mc().player.requestRespawn();
        }
    }
}
