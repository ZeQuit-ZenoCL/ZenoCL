package dev.zenocl.modules.player;

import dev.zenocl.core.Category;
import dev.zenocl.core.Module;

public class AutoSneak extends Module {
    public AutoSneak() {
        super("AutoSneak", Category.PLAYER);
    }

    @Override
    public void onTick() {
        if (mc().currentScreen == null) {
            mc().options.sneakKey.setPressed(true);
        }
    }

    @Override
    public void onDisable() {
        mc().options.sneakKey.setPressed(false);
    }
}
