package dev.zenocl.modules.player;

import dev.zenocl.core.Category;
import dev.zenocl.core.Module;
import dev.zenocl.core.NumSetting;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;

/** В открытом сундуке быстро переносит все предметы себе в инвентарь. */
public class ChestStealer extends Module {
    private final NumSetting delay = add(new NumSetting("Delay", 1, 0, 10, 1));
    private int timer;

    public ChestStealer() {
        super("ChestStealer", Category.PLAYER);
    }

    @Override
    public void onTick() {
        if (!(mc().currentScreen instanceof GenericContainerScreen screen)) {
            return;
        }
        if (timer > 0) {
            timer--;
            return;
        }
        GenericContainerScreenHandler h = screen.getScreenHandler();
        int size = h.getRows() * 9;
        for (int i = 0; i < size; i++) {
            if (h.getSlot(i).hasStack()) {
                mc().interactionManager.clickSlot(h.syncId, i, 0, SlotActionType.QUICK_MOVE, mc().player);
                timer = delay.getInt();
                return;
            }
        }
    }
}
