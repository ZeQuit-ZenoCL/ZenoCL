package dev.zenocl.modules.player;

import dev.zenocl.core.Category;
import dev.zenocl.core.Module;
import dev.zenocl.mixin.MinecraftClientAccessor;

public class FastPlace extends Module {
    public FastPlace() {
        super("FastPlace", Category.PLAYER);
    }

    @Override
    public void onTick() {
        ((MinecraftClientAccessor) mc()).zenocl$setItemUseCooldown(0);
    }
}
