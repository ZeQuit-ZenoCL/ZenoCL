package dev.zenocl.modules.player;

import dev.zenocl.core.Category;
import dev.zenocl.core.Module;
import dev.zenocl.util.Friends;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/** Средняя кнопка мыши по игроку добавляет или убирает его из друзей. */
public class MiddleClickFriend extends Module {
    private boolean wasDown;

    public MiddleClickFriend() {
        super("MiddleClickFriend", Category.PLAYER);
    }

    @Override
    public void onTick() {
        long win = mc().getWindow().getHandle();
        boolean down = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_MIDDLE) == GLFW.GLFW_PRESS;
        if (down && !wasDown && mc().currentScreen == null && mc().targetedEntity instanceof PlayerEntity pl) {
            String n = pl.getName().getString();
            boolean added = !Friends.is(n);
            if (added) {
                Friends.add(n);
            } else {
                Friends.remove(n);
            }
            mc().player.sendMessage(Text.literal("§d[ZenoCL] §f" + n + (added ? " добавлен в друзья" : " удалён из друзей")), false);
        }
        wasDown = down;
    }
}
