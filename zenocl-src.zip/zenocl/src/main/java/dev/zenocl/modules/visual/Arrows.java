package dev.zenocl.modules.visual;

import dev.zenocl.core.BoolSetting;
import dev.zenocl.core.NumSetting;
import dev.zenocl.hud.HudModule;
import dev.zenocl.hud.Render;
import dev.zenocl.util.Friends;
import dev.zenocl.util.Project;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Стрелки по кругу вокруг прицела: показывают, где находятся игроки, в том числе позади. */
public class Arrows extends HudModule {
    private final NumSetting radius = add(new NumSetting("Radius", 90, 40, 200, 5));
    private final NumSetting range = add(new NumSetting("Range", 60, 10, 150, 5));
    private final BoolSetting offscreenOnly = add(new BoolSetting("OffscreenOnly", true));

    public Arrows() {
        super("Arrows");
    }

    @Override
    public boolean movable() {
        return false;
    }

    @Override
    public void render(DrawContext ctx, int sw, int sh) {
        MinecraftClient mc = MinecraftClient.getInstance();
        var me = mc.player;
        Vec3d mine = me.getLerpedPos(Project.partial());
        double yaw = Math.toRadians(me.getYaw());
        double sin = Math.sin(yaw);
        double cos = Math.cos(yaw);
        double r = range.get();
        int cx = sw / 2;
        int cy = sh / 2;
        int rad = radius.getInt();
        for (PlayerEntity pl : mc.world.getPlayers()) {
            if (pl == me || !pl.isAlive()) {
                continue;
            }
            Vec3d pos = pl.getLerpedPos(Project.partial());
            double dx = pos.x - mine.x;
            double dz = pos.z - mine.z;
            double dist = Math.sqrt(dx * dx + dz * dz);
            if (dist > r || dist < 0.5) {
                continue;
            }
            if (offscreenOnly.get() && Project.ready()) {
                double[] s = Project.project(pos.x, pos.y + pl.getHeight() * 0.5, pos.z);
                if (s != null && s[0] >= 0 && s[0] <= sw && s[1] >= 0 && s[1] <= sh) {
                    continue;
                }
            }
            // те же оси, что у Radar: вправо и вперёд относительно взгляда
            double right = -dx * cos - dz * sin;
            double fwd = -dx * sin + dz * cos;
            double a = Math.atan2(right, fwd);
            int color = Friends.is(pl.getName().getString()) ? 0xFF55FF77 : Render.lerp(0xFFFF3B3B, 0xFFFFB347, (float) (dist / r));
            chevron(ctx, cx, cy, rad, a, color);
        }
    }

    /** Острие и два крыла, повёрнутые по направлению a; хвост бледнее. */
    private static void chevron(DrawContext ctx, int cx, int cy, int rad, double a, int color) {
        int tx = cx + (int) Math.round(Math.sin(a) * rad);
        int ty = cy - (int) Math.round(Math.cos(a) * rad);
        Render.fill(ctx, tx - 2, ty - 2, tx + 2, ty + 2, color);
        for (int side = -1; side <= 1; side += 2) {
            double wa = a + side * 2.5;
            int wx = tx + (int) Math.round(Math.sin(wa) * 5);
            int wy = ty - (int) Math.round(Math.cos(wa) * 5);
            Render.fill(ctx, wx - 1, wy - 1, wx + 2, wy + 2, Render.withAlpha(color, 0.85f));
        }
        int hx = tx - (int) Math.round(Math.sin(a) * 6);
        int hy = ty + (int) Math.round(Math.cos(a) * 6);
        Render.fill(ctx, hx - 1, hy - 1, hx + 1, hy + 1, Render.withAlpha(color, 0.45f));
    }
}
