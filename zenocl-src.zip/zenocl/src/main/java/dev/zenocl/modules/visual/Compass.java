package dev.zenocl.modules.visual;

import dev.zenocl.hud.HudModule;
import dev.zenocl.hud.Render;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** Лента компаса: стороны света и градусы, плавно едут при повороте, по краям гаснут. */
public class Compass extends HudModule {
    private static final int W = 200;
    private static final int H = 18;
    private static final String[] DIRS = {"С", "СВ", "В", "ЮВ", "Ю", "ЮЗ", "З", "СЗ"};

    public Compass() {
        super("Compass");
    }

    @Override
    public void render(DrawContext ctx, int sw, int sh) {
        float yaw = MinecraftClient.getInstance().player.getYaw();
        // Minecraft: yaw 0 смотрит на юг, поэтому азимут от севера = yaw + 180
        double bearing = ((yaw + 180.0) % 360.0 + 360.0) % 360.0;
        int[] pp = place(sw / 2 - W / 2, 24, W, H, sw, sh);
        int x = pp[0];
        int y = pp[1];
        Render.rrect(ctx, x, y, W, H, Render.bg());

        int cx = x + W / 2;
        double span = 90.0; // видимый диапазон: ±45 градусов
        for (int deg = (int) (Math.floor((bearing - span / 2) / 5) * 5); deg <= bearing + span / 2; deg += 5) {
            double off = deg - bearing;
            int px = cx + (int) (off / (span / 2) * (W / 2 - 4));
            float fade = (float) Math.max(0, 1 - Math.abs(off) / (span / 2));
            int norm = ((deg % 360) + 360) % 360;
            if (norm % 45 == 0) {
                String d = DIRS[norm / 45];
                Render.text(ctx, d, px - Render.width(d) / 2, y + 5, Render.withAlpha(norm % 90 == 0 ? Render.accent(0) : Render.TEXT, fade));
            } else if (norm % 15 == 0) {
                Render.fill(ctx, px, y + 6, px + 1, y + 12, Render.withAlpha(Render.TEXT_DIM, fade));
            } else {
                Render.fill(ctx, px, y + 8, px + 1, y + 11, Render.withAlpha(Render.TEXT_DIM, fade * 0.6f));
            }
        }
        Render.fill(ctx, cx, y + H - 3, cx + 1, y + H - 1, Render.accent(0));
        String deg = (int) bearing + "°";
        Render.text(ctx, deg, cx - Render.width(deg) / 2, y + H + 3, Render.TEXT);
    }
}
