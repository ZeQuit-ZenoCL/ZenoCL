package dev.zenocl.modules.visual;

import dev.zenocl.core.BoolSetting;
import dev.zenocl.core.ModeSetting;
import dev.zenocl.core.NumSetting;
import dev.zenocl.hud.HudModule;
import dev.zenocl.hud.Render;
import dev.zenocl.util.Friends;
import dev.zenocl.util.Project;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.HashSet;
import java.util.Set;

/**
 * Подсветка сущностей. Box - 2D-рамка, Box3D - каркас хитбокса, Skeleton - скелет, Glow - контур игры (виден сквозь стены).
 * Фигуры строятся из интерполированной позиции сущности и точной проекции камеры (см. Project), поэтому стоят на игроке
 * и не "плывут" при беге. Скелет статичный: рисуется по хитбоксу и повороту корпуса, без анимации конечностей.
 */
public class ESP extends HudModule {
    private static final int FRIEND = 0xFF55FF77;
    private static final int MOB = 0xFFFFC857;
    private static final int ITEM = 0xFF6FD3FF;

    private final ModeSetting mode = add(new ModeSetting("Mode", "Box", "Box", "Box3D", "Skeleton", "Glow"));
    private final BoolSetting fill = add(new BoolSetting("Fill", false));
    private final BoolSetting players = add(new BoolSetting("Players", true));
    private final BoolSetting mobs = add(new BoolSetting("Mobs", false));
    private final BoolSetting items = add(new BoolSetting("Items", true));
    private final BoolSetting health = add(new BoolSetting("Health", true));
    private final BoolSetting names = add(new BoolSetting("Names", true));
    private final BoolSetting distance = add(new BoolSetting("Distance", true));
    private final NumSetting range = add(new NumSetting("Range", 64, 16, 128, 8));

    /** id сущностей, которым ESP включил свечение: только их и гасим, чужое свечение не трогаем. */
    private final Set<Integer> glowed = new HashSet<>();

    public ESP() {
        super("ESP");
        health.showIf(() -> mode.is("Box"));
    }

    @Override
    public boolean movable() {
        return false;
    }

    @Override
    public void onTick() {
        boolean glow = mode.is("Glow");
        for (Entity e : mc().world.getEntities()) {
            if (e == mc().player) {
                continue;
            }
            boolean want = glow && ((players.get() && e instanceof PlayerEntity) || (mobs.get() && e instanceof MobEntity));
            if (want) {
                e.setGlowing(true);
                glowed.add(e.getId());
            } else if (glowed.remove(e.getId())) {
                e.setGlowing(false);
            }
        }
    }

    @Override
    public void onDisable() {
        if (mc().world != null) {
            for (Entity e : mc().world.getEntities()) {
                if (glowed.contains(e.getId())) {
                    e.setGlowing(false);
                }
            }
        }
        glowed.clear();
    }

    @Override
    public void render(DrawContext ctx, int sw, int sh) {
        Project.use();
        if (!Project.ready()) {
            return;
        }
        MinecraftClient mc = MinecraftClient.getInstance();
        double r = range.get();
        double r2 = r * r;
        boolean glow = mode.is("Glow");
        for (Entity e : mc.world.getEntities()) {
            if (e == mc.player || mc.player.squaredDistanceTo(e) > r2) {
                continue;
            }
            if (e instanceof ItemEntity ie) {
                if (items.get()) {
                    item(ctx, ie);
                }
                continue;
            }
            if (glow || !(e instanceof LivingEntity le) || !le.isAlive()) {
                continue;
            }
            boolean isPlayer = e instanceof PlayerEntity;
            if (!(isPlayer && players.get()) && !(e instanceof MobEntity && mobs.get())) {
                continue;
            }
            double dist = mc.player.distanceTo(e);
            String name = e.getName().getString();
            int color = !isPlayer ? MOB : Friends.is(name) ? FRIEND : Render.accent(dist * 0.05);
            double[] b = Project.box(e);
            if (b == null) {
                continue;
            }
            switch (mode.get()) {
                case "Box3D" -> box3d(ctx, le, color);
                case "Skeleton" -> skeleton(ctx, le, color);
                default -> box2d(ctx, le, b, color);
            }
            int x1 = (int) b[0];
            int x2 = (int) b[2];
            int y1 = (int) b[1];
            int y2 = (int) b[3];
            if (names.get()) {
                Render.text(ctx, name, (x1 + x2) / 2 - Render.width(name) / 2, y1 - 11, Render.TEXT);
            }
            if (distance.get()) {
                String d = String.format("%.0fm", dist);
                Render.text(ctx, d, (x1 + x2) / 2 - Render.width(d) / 2, y2 + 3, Render.TEXT_DIM);
            }
        }
    }

    private void box2d(DrawContext ctx, LivingEntity le, double[] b, int color) {
        int x1 = (int) b[0];
        int y1 = (int) b[1];
        int x2 = (int) b[2];
        int y2 = (int) b[3];
        if (x2 - x1 < 3 || y2 - y1 < 3) {
            return;
        }
        if (fill.get()) {
            Render.fill(ctx, x1, y1, x2, y2, Render.withAlpha(color, 0.22f));
        }
        outline(ctx, x1 - 1, y1 - 1, x2 + 1, y2 + 1, 0xB0000000);
        outline(ctx, x1, y1, x2, y2, color);
        if (health.get()) {
            float ratio = MathHelper.clamp((le.getHealth() + le.getAbsorptionAmount()) / Math.max(1f, le.getMaxHealth()), 0f, 1f);
            int top = y2 - (int) ((y2 - y1) * ratio);
            Render.fill(ctx, x1 - 5, y1 - 1, x1 - 2, y2 + 1, 0xB0000000);
            Render.fill(ctx, x1 - 4, top, x1 - 3, y2, Render.lerp(0xFFFF3B3B, 0xFF4DFF7A, ratio));
        }
    }

    private void box3d(DrawContext ctx, LivingEntity e, int color) {
        Vec3d pos = e.getLerpedPos(Project.partial());
        double hw = e.getWidth() / 2.0;
        double h = e.getHeight();
        double[][] p = new double[8][];
        double minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9;
        for (int i = 0; i < 8; i++) {
            p[i] = Project.project(pos.x + ((i & 1) == 0 ? -hw : hw), pos.y + ((i & 2) == 0 ? 0 : h), pos.z + ((i & 4) == 0 ? -hw : hw));
            if (p[i] == null) {
                return;
            }
            minX = Math.min(minX, p[i][0]);
            maxX = Math.max(maxX, p[i][0]);
            minY = Math.min(minY, p[i][1]);
            maxY = Math.max(maxY, p[i][1]);
        }
        if (fill.get()) {
            Render.fill(ctx, (int) minX, (int) minY, (int) maxX, (int) maxY, Render.withAlpha(color, 0.14f));
        }
        for (int i = 0; i < 8; i++) {
            for (int bit = 1; bit <= 4; bit <<= 1) {
                if ((i & bit) == 0) {
                    int j = i | bit;
                    Render.line(ctx, p[i][0], p[i][1], p[j][0], p[j][1], color, 1);
                }
            }
        }
    }

    /** Скелет по хитбоксу: голова, позвоночник, плечи, руки и ноги. Поворот корпуса - сглаженный bodyYaw. */
    private void skeleton(DrawContext ctx, LivingEntity e, int color) {
        float pt = Project.partial();
        Vec3d pos = e.getLerpedPos(pt);
        double h = e.getHeight();
        double yaw = Math.toRadians(MathHelper.lerp(pt, e.lastBodyYaw, e.bodyYaw));
        // вправо относительно взгляда корпуса
        double rx = -Math.cos(yaw);
        double rz = -Math.sin(yaw);
        double sh = 0.30;
        double hp = 0.12;
        double[] head = Project.project(pos.x, pos.y + h * 0.91, pos.z);
        double[] neck = Project.project(pos.x, pos.y + h * 0.82, pos.z);
        double[] hip = Project.project(pos.x, pos.y + h * 0.47, pos.z);
        double[] sl = Project.project(pos.x - rx * sh, pos.y + h * 0.80, pos.z - rz * sh);
        double[] sr = Project.project(pos.x + rx * sh, pos.y + h * 0.80, pos.z + rz * sh);
        double[] hl = Project.project(pos.x - rx * sh, pos.y + h * 0.47, pos.z - rz * sh);
        double[] hr = Project.project(pos.x + rx * sh, pos.y + h * 0.47, pos.z + rz * sh);
        double[] ll = Project.project(pos.x - rx * hp, pos.y + h * 0.47, pos.z - rz * hp);
        double[] lr = Project.project(pos.x + rx * hp, pos.y + h * 0.47, pos.z + rz * hp);
        double[] fl = Project.project(pos.x - rx * hp, pos.y, pos.z - rz * hp);
        double[] fr = Project.project(pos.x + rx * hp, pos.y, pos.z + rz * hp);
        if (head == null || neck == null || hip == null || sl == null || sr == null || hl == null || hr == null
                || ll == null || lr == null || fl == null || fr == null) {
            return;
        }
        double hr0 = Math.max(2.5, Project.scaleAt(head[2]) * 0.16);
        Render.line(ctx, neck[0], neck[1], hip[0], hip[1], color, 1);
        Render.line(ctx, sl[0], sl[1], sr[0], sr[1], color, 1);
        Render.line(ctx, sl[0], sl[1], hl[0], hl[1], color, 1);
        Render.line(ctx, sr[0], sr[1], hr[0], hr[1], color, 1);
        Render.line(ctx, ll[0], ll[1], lr[0], lr[1], color, 1);
        Render.line(ctx, ll[0], ll[1], fl[0], fl[1], color, 1);
        Render.line(ctx, lr[0], lr[1], fr[0], fr[1], color, 1);
        int c = (int) Math.round(hr0);
        int hx = (int) head[0];
        int hy = (int) head[1] - c / 2;
        if (fill.get()) {
            Render.fill(ctx, hx - c, hy - c, hx + c, hy + c, Render.withAlpha(color, 0.3f));
        }
        outline(ctx, hx - c, hy - c, hx + c, hy + c, color);
    }

    private void item(DrawContext ctx, ItemEntity ie) {
        double[] b = Project.box(ie);
        if (b == null) {
            return;
        }
        int x1 = (int) b[0] - 2;
        int y1 = (int) b[1] - 2;
        int x2 = (int) b[2] + 2;
        int y2 = (int) b[3] + 1;
        if (fill.get()) {
            Render.fill(ctx, x1, y1, x2, y2, Render.withAlpha(ITEM, 0.2f));
        }
        outline(ctx, x1, y1, x2, y2, ITEM);
        if (names.get()) {
            var st = ie.getStack();
            String n = st.getName().getString() + (st.getCount() > 1 ? " x" + st.getCount() : "");
            Render.text(ctx, n, (x1 + x2) / 2 - Render.width(n) / 2, y1 - 10, Render.TEXT);
        }
    }

    private static void outline(DrawContext ctx, int x1, int y1, int x2, int y2, int c) {
        Render.fill(ctx, x1, y1, x2, y1 + 1, c);
        Render.fill(ctx, x1, y2 - 1, x2, y2, c);
        Render.fill(ctx, x1, y1, x1 + 1, y2, c);
        Render.fill(ctx, x2 - 1, y1, x2, y2, c);
    }
}
