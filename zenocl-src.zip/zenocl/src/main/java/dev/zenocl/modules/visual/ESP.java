package dev.zenocl.modules.visual;

import dev.zenocl.core.BoolSetting;
import dev.zenocl.core.ModeSetting;
import dev.zenocl.core.NumSetting;
import dev.zenocl.hud.HudModule;
import dev.zenocl.hud.Render;
import dev.zenocl.util.Friends;
import dev.zenocl.util.Project;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;

import java.util.HashSet;
import java.util.Set;

/**
 * Подсветка сущностей: 2D-рамки с полосой здоровья, именем и дистанцией и/или контур Glow (виден сквозь стены).
 * Рамки считаются без матриц рендера (см. Project), поэтому приблизительны при необычном FOV.
 */
public class ESP extends HudModule {
    private static final int FRIEND = 0xFF55FF77;
    private static final int MOB = 0xFFFFC857;

    private final ModeSetting mode = add(new ModeSetting("Mode", "Both", "Both", "Box", "Glow"));
    private final BoolSetting players = add(new BoolSetting("Players", true));
    private final BoolSetting mobs = add(new BoolSetting("Mobs", false));
    private final BoolSetting health = add(new BoolSetting("Health", true));
    private final BoolSetting names = add(new BoolSetting("Names", true));
    private final BoolSetting distance = add(new BoolSetting("Distance", true));
    private final NumSetting range = add(new NumSetting("Range", 64, 16, 128, 8));

    /** id сущностей, которым ESP включил свечение: только их и гасим, чужое свечение не трогаем. */
    private final Set<Integer> glowed = new HashSet<>();

    public ESP() {
        super("ESP");
    }

    @Override
    public boolean movable() {
        return false;
    }

    @Override
    public void onTick() {
        boolean glow = !mode.is("Box");
        for (Entity e : mc().world.getEntities()) {
            if (e == mc().player) {
                continue;
            }
            boolean want = glow && ((players.get() && e instanceof PlayerEntity) || (mobs.get() && e instanceof MobEntity));
            if (want) {
                e.setGlowing(true);
                glowed.add(e.getId());
            } else if (glowed.remove(e.getId())) {
                e.setGlowing(false);
            }
        }
    }

    @Override
    public void onDisable() {
        if (mc().world != null) {
            for (Entity e : mc().world.getEntities()) {
                if (glowed.contains(e.getId())) {
                    e.setGlowing(false);
                }
            }
        }
        glowed.clear();
    }

    @Override
    public void render(DrawContext ctx, int sw, int sh) {
        if (!Project.ready() || mode.is("Glow")) {
            return;
        }
        MinecraftClient mc = MinecraftClient.getInstance();
        double r = range.get();
        for (Entity e : mc.world.getEntities()) {
            if (e == mc.player || !(e instanceof LivingEntity le) || !le.isAlive()) {
                continue;
            }
            boolean isPlayer = e instanceof PlayerEntity;
            if (!(isPlayer && players.get()) && !(e instanceof MobEntity && mobs.get())) {
                continue;
            }
            double dist = mc.player.distanceTo(e);
            if (dist > r) {
                continue;
            }
            double[] b = Project.box(e);
            if (b == null) {
                continue;
            }
            int x1 = (int) b[0];
            int y1 = (int) b[1];
            int x2 = (int) b[2];
            int y2 = (int) b[3];
            if (x2 - x1 < 3 || y2 - y1 < 3) {
                continue;
            }
            String name = e.getName().getString();
            int color = !isPlayer ? MOB : Friends.is(name) ? FRIEND : Render.accent(dist * 0.05);

            outline(ctx, x1 - 1, y1 - 1, x2 + 1, y2 + 1, 0xB0000000);
            outline(ctx, x1, y1, x2, y2, color);
            if (health.get()) {
                float ratio = Math.max(0f, Math.min(1f, (le.getHealth() + le.getAbsorptionAmount()) / Math.max(1f, le.getMaxHealth())));
                int top = y2 - (int) ((y2 - y1) * ratio);
                Render.fill(ctx, x1 - 5, y1 - 1, x1 - 2, y2 + 1, 0xB0000000);
                Render.fill(ctx, x1 - 4, top, x1 - 3, y2, Render.lerp(0xFFFF3B3B, 0xFF4DFF7A, ratio));
            }
            if (names.get()) {
                Render.text(ctx, name, (x1 + x2) / 2 - Render.width(name) / 2, y1 - 11, Render.TEXT);
            }
            if (distance.get()) {
                String d = String.format("%.0fm", dist);
                Render.text(ctx, d, (x1 + x2) / 2 - Render.width(d) / 2, y2 + 3, Render.TEXT_DIM);
            }
        }
    }

    private static void outline(DrawContext ctx, int x1, int y1, int x2, int y2, int c) {
        Render.fill(ctx, x1, y1, x2, y1 + 1, c);
        Render.fill(ctx, x1, y2 - 1, x2, y2, c);
        Render.fill(ctx, x1, y1, x1 + 1, y2, c);
        Render.fill(ctx, x2 - 1, y1, x2, y2, c);
    }
}
