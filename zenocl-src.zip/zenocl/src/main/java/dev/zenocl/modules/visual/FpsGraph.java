package dev.zenocl.modules.visual;

import dev.zenocl.hud.HudModule;
import dev.zenocl.hud.Render;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** График времени кадра за последние 60 кадров: зелёные столбики - ровно, красные - просадки. */
public class FpsGraph extends HudModule {
    private static final int SAMPLES = 60;
    private static final int W = SAMPLES * 2 + 8;
    private static final int H = 42;
    private final float[] ms = new float[SAMPLES];
    private int head;
    private long last = System.nanoTime();

    public FpsGraph() {
        super("FpsGraph");
    }

    @Override
    public void render(DrawContext ctx, int sw, int sh) {
        long now = System.nanoTime();
        ms[head] = Math.min(100f, (now - last) / 1.0e6f);
        head = (head + 1) % SAMPLES;
        last = now;

        int[] pp = place(6, 34, W, H, sw, sh);
        int x = pp[0];
        int y = pp[1];
        Render.rrect(ctx, x, y, W, H, Render.bg());
        String s = MinecraftClient.getInstance().getCurrentFps() + " fps";
        Render.text(ctx, s, x + 5, y + 4, Render.TEXT);
        // 33 мс (30 fps) - верх графика
        int base = y + H - 4;
        int maxH = 22;
        for (int i = 0; i < SAMPLES; i++) {
            float v = ms[(head + i) % SAMPLES];
            float t = Math.min(1f, v / 33.3f);
            int bh = Math.max(1, (int) (maxH * t));
            Render.fill(ctx, x + 4 + i * 2, base - bh, x + 6 + i * 2, base, Render.lerp(0xFF4DFF7A, 0xFFFF3B3B, t));
        }
    }
}
