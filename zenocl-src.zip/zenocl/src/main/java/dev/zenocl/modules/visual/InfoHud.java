package dev.zenocl.modules.visual;

import dev.zenocl.core.BoolSetting;
import dev.zenocl.hud.HudModule;
import dev.zenocl.hud.Render;
import dev.zenocl.util.Inv;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.List;

public class InfoHud extends HudModule {
    private final BoolSetting coords = add(new BoolSetting("Coords", true));
    private final BoolSetting speed = add(new BoolSetting("Speed", true));
    private final BoolSetting items = add(new BoolSetting("Totems/Crystals", true));

    public InfoHud() {
        super("Info");
    }

    @Override
    public void render(DrawContext ctx, int sw, int sh) {
        var p = MinecraftClient.getInstance().player;
        List<String> lines = new ArrayList<>();
        if (coords.get()) {
            lines.add(String.format("XYZ  %.1f  %.1f  %.1f", p.getX(), p.getY(), p.getZ()));
        }
        if (speed.get()) {
            double v = Math.sqrt(p.getVelocity().x * p.getVelocity().x + p.getVelocity().z * p.getVelocity().z) * 20;
            lines.add(String.format("Speed  %.1f b/s", v));
        }
        if (items.get()) {
            lines.add("Totems  " + Inv.count(p, Items.TOTEM_OF_UNDYING) + "   Crystals  " + Inv.count(p, Items.END_CRYSTAL));
        }
        if (lines.isEmpty()) {
            return;
        }
        int w = 0;
        for (String s : lines) {
            w = Math.max(w, Render.width(s));
        }
        w += 14;
        int h = lines.size() * 11 + 6;
        int x = 6, y = sh - h - 6;
        int[] pp = place(x, y, w, h, sw, sh);
        x = pp[0];
        y = pp[1];
        Render.rrect(ctx, x, y, w, h, Render.bg());
        Render.gradient(ctx, x + 1, y + 2, x + 3, y + h - 2, Render.accent(0), Render.accent(2));
        for (int i = 0; i < lines.size(); i++) {
            Render.text(ctx, lines.get(i), x + 8, y + 4 + i * 11, Render.TEXT);
        }
    }
}
