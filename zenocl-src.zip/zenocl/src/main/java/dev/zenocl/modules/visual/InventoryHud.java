package dev.zenocl.modules.visual;

import dev.zenocl.hud.HudModule;
import dev.zenocl.hud.Render;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;

public class InventoryHud extends HudModule {
    public InventoryHud() {
        super("Inventory");
    }

    @Override
    public void render(DrawContext ctx, int sw, int sh) {
        MinecraftClient mc = MinecraftClient.getInstance();
        int x = 6, y = 30;
        int w = 9 * 18 + 8, h = 3 * 18 + 18;
        int[] pp = place(x, y, w, h, sw, sh);
        x = pp[0];
        y = pp[1];
        Render.rrect(ctx, x, y, w, h, Render.bg());
        Render.text(ctx, "Inventory", x + 5, y + 4, Render.accent(0));
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                ItemStack s = mc.player.getInventory().getStack(9 + row * 9 + col);
                int ix = x + 4 + col * 18;
                int iy = y + 16 + row * 18;
                if (!s.isEmpty()) {
                    ctx.drawItem(s, ix, iy);
                    ctx.drawStackOverlay(mc.textRenderer, s, ix, iy);
                }
            }
        }
    }
}
