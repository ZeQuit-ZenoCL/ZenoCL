package dev.zenocl.modules.visual;

import dev.zenocl.hud.HudModule;
import dev.zenocl.hud.Render;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.GameOptions;

public class Keystrokes extends HudModule {
    private static final int KEY = 18;
    private static final int GAP = 2;
    private final float[] glow = new float[6];
    private long last = System.nanoTime();

    public Keystrokes() {
        super("Keystrokes");
    }

    @Override
    public void render(DrawContext ctx, int sw, int sh) {
        GameOptions o = MinecraftClient.getInstance().options;
        long now = System.nanoTime();
        float dt = Math.min(0.05f, (now - last) / 1.0e9f);
        last = now;
        int x = 6;
        int y = sh / 2 - 30;
        int[] pp = place(x, y, KEY * 3 + GAP * 2, KEY * 3 + GAP * 2, sw, sh);
        x = pp[0];
        y = pp[1];
        key(ctx, 0, "W", o.forwardKey.isPressed(), x + KEY + GAP, y, KEY, dt);
        key(ctx, 1, "A", o.leftKey.isPressed(), x, y + KEY + GAP, KEY, dt);
        key(ctx, 2, "S", o.backKey.isPressed(), x + KEY + GAP, y + KEY + GAP, KEY, dt);
        key(ctx, 3, "D", o.rightKey.isPressed(), x + 2 * (KEY + GAP), y + KEY + GAP, KEY, dt);
        int bw = (KEY * 3 + GAP * 2 - GAP) / 2;
        key(ctx, 4, "LMB", o.attackKey.isPressed(), x, y + 2 * (KEY + GAP), bw, dt);
        key(ctx, 5, "RMB", o.useKey.isPressed(), x + bw + GAP, y + 2 * (KEY + GAP), bw, dt);
    }

    private void key(DrawContext ctx, int i, String label, boolean down, int x, int y, int w, float dt) {
        float t = down ? 1f : 0f;
        glow[i] += (t - glow[i]) * Math.min(1f, dt * 18f);
        Render.rrect(ctx, x, y, w, KEY, Render.lerp(Render.bg(), Render.accent(i * 0.4), glow[i] * 0.85f));
        Render.text(ctx, label, x + w / 2 - Render.width(label) / 2, y + 5, Render.lerp(Render.TEXT_DIM, Render.TEXT, glow[i]));
    }
}
