package dev.zenocl.modules.visual;

import dev.zenocl.core.BoolSetting;
import dev.zenocl.core.NumSetting;
import dev.zenocl.hud.Graphics;
import dev.zenocl.hud.HudModule;
import dev.zenocl.hud.Render;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** Красная виньетка по краям экрана при низком здоровье (пульсирует тем быстрее, чем меньше HP) и вспышка при уроне. */
public class LowHealth extends HudModule {
    private final NumSetting threshold = add(new NumSetting("Hearts", 6, 2, 10, 1));
    private final NumSetting intensity = add(new NumSetting("Intensity", 0.7, 0.2, 1.0, 0.05));
    private final BoolSetting damageFlash = add(new BoolSetting("DamageFlash", true));

    public LowHealth() {
        super("LowHealth");
    }

    @Override
    public boolean movable() {
        return false;
    }

    @Override
    public void render(DrawContext ctx, int sw, int sh) {
        var p = MinecraftClient.getInstance().player;
        float limit = threshold.getFloat() * 2f;
        float hp = p.getHealth();
        float low = hp < limit ? 1f - hp / limit : 0f;
        float flash = damageFlash.get() ? p.hurtTime / 10f : 0f;
        float strength = Math.max(low, flash * 0.8f);
        if (strength <= 0.01f) {
            return;
        }
        // при низком HP - пульс, скорость растёт к нулю здоровья; вспышка при уроне без пульса
        float pulse = low > 0f ? (float) (0.75 + 0.25 * Math.sin(System.currentTimeMillis() / (600.0 - 350.0 * low))) : 1f;
        int depth = (int) (sh * 0.22f);
        int step = Graphics.index() == 0 ? 6 : 3; // на Low полос вдвое меньше
        for (int i = 0; i < depth; i += step) {
            float t = 1f - i / (float) depth;
            int c = Render.withAlpha(0xFFE02040, intensity.getFloat() * strength * pulse * t * t * 0.6f);
            Render.fill(ctx, i, 0, i + step, sh, c);
            Render.fill(ctx, sw - i - step, 0, sw - i, sh, c);
            Render.fill(ctx, 0, i, sw, i + step, c);
            Render.fill(ctx, 0, sh - i - step, sw, sh - i, c);
        }
    }
}
