package dev.zenocl.modules.visual;

import dev.zenocl.hud.HudModule;
import dev.zenocl.hud.Render;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.effect.StatusEffectInstance;

import java.util.ArrayList;
import java.util.List;

public class PotionsHud extends HudModule {
    public PotionsHud() {
        super("Potions");
    }

    @Override
    public void render(DrawContext ctx, int sw, int sh) {
        List<String[]> rows = new ArrayList<>();
        for (StatusEffectInstance e : MinecraftClient.getInstance().player.getStatusEffects()) {
            String name = e.getEffectType().value().getName().getString() + " " + (e.getAmplifier() + 1);
            int secs = e.getDuration() / 20;
            rows.add(new String[]{name, e.isInfinite() ? "inf" : String.format("%d:%02d", secs / 60, secs % 60)});
        }
        if (rows.isEmpty()) {
            if (!editing) {
                return;
            }
            rows.add(new String[]{"Speed 2", "1:30"}); // заглушка для редактора
        }
        int w = 0;
        for (String[] r : rows) {
            w = Math.max(w, Render.width(r[0]) + Render.width(r[1]) + 20);
        }
        int x = 6;
        int y = sh / 2 - 40;
        int[] pp = place(x, y, w, rows.size() * 16 - 2, sw, sh);
        x = pp[0];
        y = pp[1];
        for (String[] r : rows) {
            Render.rrect(ctx, x, y, w, 14, Render.bg());
            Render.fill(ctx, x + 1, y + 2, x + 3, y + 12, Render.accent(y * 0.05));
            Render.text(ctx, r[0], x + 7, y + 3, Render.TEXT);
            Render.text(ctx, r[1], x + w - 6 - Render.width(r[1]), y + 3, Render.TEXT_DIM);
            y += 16;
        }
    }
}
