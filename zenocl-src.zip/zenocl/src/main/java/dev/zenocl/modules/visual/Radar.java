package dev.zenocl.modules.visual;

import dev.zenocl.core.NumSetting;
import dev.zenocl.hud.HudModule;
import dev.zenocl.hud.Render;
import dev.zenocl.util.Friends;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerEntity;

/** Мини-радар: игроки вокруг, вверх на экране - направление взгляда. */
public class Radar extends HudModule {
    private static final int SIZE = 76;
    private static final int FRIEND_COLOR = 0xFF55FF77;
    private final NumSetting range = add(new NumSetting("Range", 40, 10, 100, 5));

    public Radar() {
        super("Radar");
    }

    @Override
    public void render(DrawContext ctx, int sw, int sh) {
        MinecraftClient mc = MinecraftClient.getInstance();
        var me = mc.player;
        int x = sw - SIZE - 6;
        int y = sh - SIZE - 40;
        int[] pp = place(x, y, SIZE, SIZE, sw, sh);
        x = pp[0];
        y = pp[1];
        int cx = x + SIZE / 2;
        int cy = y + SIZE / 2;
        Render.rrect(ctx, x, y, SIZE, SIZE, Render.bg());
        Render.fill(ctx, cx, y + 3, cx + 1, y + SIZE - 3, 0x18FFFFFF);
        Render.fill(ctx, x + 3, cy, x + SIZE - 3, cy + 1, 0x18FFFFFF);
        Render.fill(ctx, cx - 1, cy - 1, cx + 2, cy + 2, Render.accent(0));

        double yaw = Math.toRadians(me.getYaw());
        double sin = Math.sin(yaw);
        double cos = Math.cos(yaw);
        double r = range.get();
        double half = SIZE / 2.0 - 4;
        for (PlayerEntity pl : mc.world.getPlayers()) {
            if (pl == me) {
                continue;
            }
            double dx = pl.getX() - me.getX();
            double dz = pl.getZ() - me.getZ();
            double right = -dx * cos - dz * sin;
            double fwd = -dx * sin + dz * cos;
            double px = Math.max(-half, Math.min(half, right / r * half));
            double py = Math.max(-half, Math.min(half, fwd / r * half));
            int color = Friends.is(pl.getName().getString()) ? FRIEND_COLOR : 0xFFFF4D4D;
            int ix = cx + (int) px;
            int iy = cy - (int) py;
            Render.fill(ctx, ix - 1, iy - 1, ix + 2, iy + 2, color);
        }
    }
}
