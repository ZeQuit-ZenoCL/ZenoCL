package dev.zenocl.modules.visual;

import dev.zenocl.core.NumSetting;
import dev.zenocl.hud.HudModule;
import dev.zenocl.hud.Render;
import dev.zenocl.util.Project;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

/**
 * Показывает невидимых игроков: игра рисует их полупрозрачным "призраком" (как для наблюдателя),
 * а поверх рисуется заливка силуэта, насыщенность которой задаёт Visibility (10-100%) - при 100% невидимку не пропустить.
 */
public class SeeInvisible extends HudModule {
    private final NumSetting visibility = add(new NumSetting("Visibility", 60, 10, 100, 5));

    public SeeInvisible() {
        super("SeeInvisible");
    }

    @Override
    public boolean movable() {
        return false;
    }

    @Override
    public void render(DrawContext ctx, int sw, int sh) {
        Project.use();
        if (!Project.ready()) {
            return;
        }
        MinecraftClient mc = MinecraftClient.getInstance();
        float a = visibility.getFloat() / 100f * 0.55f;
        for (Entity e : mc.world.getEntities()) {
            if (e == mc.player || !(e instanceof PlayerEntity) || !e.isInvisible() || !((LivingEntity) e).isAlive()
                    || mc.player.squaredDistanceTo(e) > 96 * 96) {
                continue;
            }
            double[] b = Project.box(e);
            if (b == null) {
                continue;
            }
            int c = Render.accent(0);
            Render.fill(ctx, (int) b[0], (int) b[1], (int) b[2], (int) b[3], Render.withAlpha(c, a));
        }
    }
}
