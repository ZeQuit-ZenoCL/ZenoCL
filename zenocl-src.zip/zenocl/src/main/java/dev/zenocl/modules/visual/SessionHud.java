package dev.zenocl.modules.visual;

import dev.zenocl.hud.HudModule;
import dev.zenocl.hud.Render;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** Время сессии и пройденное расстояние. */
public class SessionHud extends HudModule {
    private long startedAt = System.currentTimeMillis();
    private double distance;
    private double lastX;
    private double lastZ;
    private boolean hasLast;

    public SessionHud() {
        super("Session");
    }

    @Override
    public void onEnable() {
        startedAt = System.currentTimeMillis();
        distance = 0;
        hasLast = false;
    }

    @Override
    public void onTick() {
        var p = mc().player;
        if (hasLast) {
            distance += Math.hypot(p.getX() - lastX, p.getZ() - lastZ);
        }
        lastX = p.getX();
        lastZ = p.getZ();
        hasLast = true;
    }

    @Override
    public void render(DrawContext ctx, int sw, int sh) {
        long sec = (System.currentTimeMillis() - startedAt) / 1000;
        String s = String.format("%02d:%02d:%02d  |  %d m", sec / 3600, (sec / 60) % 60, sec % 60, (int) distance);
        int w = Render.width(s) + 14;
        int x = sw / 2 - w / 2;
        int y = 6;
        int[] pp = place(x, y, w, 15, sw, sh);
        x = pp[0];
        y = pp[1];
        Render.rrect(ctx, x, y, w, 15, Render.bg());
        Render.gradient(ctx, x + 2, y + 13, x + w - 2, y + 14, Render.accent(0), Render.accent(2));
        Render.text(ctx, s, x + 7, y + 4, Render.TEXT);
    }
}
