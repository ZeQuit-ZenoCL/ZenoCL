package dev.zenocl.modules.visual;

import dev.zenocl.core.Category;
import dev.zenocl.core.Module;
import dev.zenocl.core.NumSetting;

/** Скорость анимации взмаха руки (в тиках): в ванили 6, больше - медленнее и плавнее. На кулдаун атаки не влияет. */
public class Swing extends Module {
    private final NumSetting duration = add(new NumSetting("Duration", 12, 2, 24, 1));

    public Swing() {
        super("Swing", Category.VISUAL);
    }

    public int duration() {
        return duration.getInt();
    }
}
