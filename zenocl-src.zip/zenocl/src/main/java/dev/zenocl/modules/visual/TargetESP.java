package dev.zenocl.modules.visual;

import dev.zenocl.core.ModeSetting;
import dev.zenocl.core.NumSetting;
import dev.zenocl.hud.HudModule;
import dev.zenocl.hud.Render;
import dev.zenocl.util.Project;
import dev.zenocl.util.Targets;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Эффект на цели KillAura (последняя атакованная сущность): 10 вариантов. Фигуры строятся в мировых координатах и проецируются. */
public class TargetESP extends HudModule {
    private final ModeSetting mode = add(new ModeSetting("Mode", "Ring", "Ring", "Circle", "Brackets", "Cube", "Diamond", "Ghosts",
            "Meteors", "Orbit", "Crosshair", "Spiral"));
    private final NumSetting size = add(new NumSetting("Size", 1.0, 0.5, 2.0, 0.1));

    private LivingEntity last;
    private float fade;
    private long stamp = System.nanoTime();

    public TargetESP() {
        super("TargetESP");
    }

    @Override
    public boolean movable() {
        return false;
    }

    @Override
    public void render(DrawContext ctx, int sw, int sh) {
        Project.use();
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - stamp) / 1e9f);
        stamp = now;
        LivingEntity t = Targets.recent();
        if (t != null && t.isAlive()) {
            last = t;
            fade = Math.min(1f, fade + dt * 5f);
        } else {
            fade = Math.max(0f, fade - dt * 5f);
        }
        if (last == null || fade <= 0.01f || !Project.ready()) {
            return;
        }
        Vec3d p = last.getLerpedPos(Project.partial());
        double w = last.getWidth() * size.get();
        double h = last.getHeight();
        double time = now / 1e9;
        int c0 = Render.withAlpha(Render.accent(0), fade);
        int c1 = Render.withAlpha(Render.accent(1.5), fade);
        switch (mode.get()) {
            case "Circle" -> ring(ctx, p.x, p.y + 0.02, p.z, w + 0.2, 0, 28, c0, 2);
            case "Brackets" -> brackets(ctx, last, c0);
            case "Cube" -> cube(ctx, p, w / 2, h, c0);
            case "Diamond" -> diamond(ctx, p.x, p.y + h + 0.45 + Math.sin(time * 3) * 0.06, p.z, time, c0, c1);
            case "Ghosts" -> {
                for (int i = 0; i < 3; i++) {
                    double a = time * 2.2 + i * Math.PI * 2 / 3;
                    double y = p.y + h * (0.3 + 0.2 * i) + Math.sin(time * 3 + i) * 0.15;
                    glow(ctx, p.x + Math.cos(a) * (w + 0.3), y, p.z + Math.sin(a) * (w + 0.3), 6, i == 1 ? c1 : c0);
                }
            }
            case "Meteors" -> {
                for (int i = 0; i < 6; i++) {
                    double a = i * 1.047 + time * 0.5;
                    double ph = (time * 0.9 + i * 0.37) % 1.0;
                    double x = p.x + Math.cos(a) * (w + 0.4);
                    double z = p.z + Math.sin(a) * (w + 0.4);
                    double y = p.y + h + 1.2 - ph * (h + 1.4);
                    for (int k = 0; k < 5; k++) {
                        int cc = Render.withAlpha(c0, fade * (1f - k * 0.2f) * (float) Math.sin(ph * Math.PI));
                        glow(ctx, x - k * 0.04, y + k * 0.14, z - k * 0.04, 3 - k / 3, cc);
                    }
                }
            }
            case "Orbit" -> {
                ring(ctx, p.x, p.y + h / 2, p.z, w + 0.5, time, 28, c0, 1);
                ring(ctx, p.x, p.y + h / 2, p.z, w + 0.5, time + 1.4, 28, c1, 1);
                glow(ctx, p.x + Math.cos(time * 3) * (w + 0.5), p.y + h / 2, p.z + Math.sin(time * 3) * (w + 0.5), 5, c1);
            }
            case "Crosshair" -> crosshair(ctx, p.x, p.y + h * 0.55, p.z, time, c0);
            case "Spiral" -> {
                for (int i = 0; i < 24; i++) {
                    double f = i / 24.0;
                    double a = time * 2 + f * Math.PI * 4;
                    glow(ctx, p.x + Math.cos(a) * (w + 0.25), p.y + f * h, p.z + Math.sin(a) * (w + 0.25), 3,
                            Render.withAlpha(c0, fade * (float) (0.4 + 0.6 * f)));
                }
            }
            default -> ring(ctx, p.x, p.y + (0.5 + 0.5 * Math.sin(time * 2.5)) * h, p.z, w + 0.2, 0, 28, c0, 2); // Ring: поднимающийся обруч
        }
    }

    private static void ring(DrawContext ctx, double x, double y, double z, double r, double tilt, int n, int color, int th) {
        double[] prev = null;
        for (int i = 0; i <= n; i++) {
            double a = i * Math.PI * 2 / n;
            double yy = y + Math.sin(a) * Math.sin(tilt) * r * 0.5;
            double[] s = Project.project(x + Math.cos(a) * r, yy, z + Math.sin(a) * r);
            if (s != null && prev != null) {
                Render.line(ctx, prev[0], prev[1], s[0], s[1], color, th);
            }
            prev = s;
        }
    }

    private static void glow(DrawContext ctx, double x, double y, double z, int px, int color) {
        double[] s = Project.project(x, y, z);
        if (s == null) {
            return;
        }
        int sx = (int) s[0];
        int sy = (int) s[1];
        Render.fill(ctx, sx - px - 1, sy - px - 1, sx + px + 1, sy + px + 1, Render.withAlpha(color, 0.25f));
        Render.fill(ctx, sx - px / 2, sy - px / 2, sx + px / 2 + 1, sy + px / 2 + 1, color);
    }

    private static void brackets(DrawContext ctx, LivingEntity e, int c) {
        double[] b = Project.box(e);
        if (b == null) {
            return;
        }
        int x1 = (int) b[0] - 3;
        int y1 = (int) b[1] - 3;
        int x2 = (int) b[2] + 3;
        int y2 = (int) b[3] + 3;
        int l = Math.max(5, Math.min(x2 - x1, y2 - y1) / 4);
        corner(ctx, x1, y1, l, 1, 1, c);
        corner(ctx, x2, y1, l, -1, 1, c);
        corner(ctx, x1, y2, l, 1, -1, c);
        corner(ctx, x2, y2, l, -1, -1, c);
    }

    private static void corner(DrawContext ctx, int x, int y, int l, int dx, int dy, int c) {
        Render.fill(ctx, Math.min(x, x + dx * l), y - (dy > 0 ? 0 : 1), Math.max(x, x + dx * l), y + (dy > 0 ? 1 : 0), c);
        Render.fill(ctx, x - (dx > 0 ? 0 : 1), Math.min(y, y + dy * l), x + (dx > 0 ? 1 : 0), Math.max(y, y + dy * l), c);
    }

    private static void cube(DrawContext ctx, Vec3d p, double hw, double h, int c) {
        double[][] q = new double[8][];
        for (int i = 0; i < 8; i++) {
            q[i] = Project.project(p.x + ((i & 1) == 0 ? -hw : hw), p.y + ((i & 2) == 0 ? 0 : h), p.z + ((i & 4) == 0 ? -hw : hw));
            if (q[i] == null) {
                return;
            }
        }
        for (int i = 0; i < 8; i++) {
            for (int bit = 1; bit <= 4; bit <<= 1) {
                if ((i & bit) == 0) {
                    Render.line(ctx, q[i][0], q[i][1], q[i | bit][0], q[i | bit][1], c, 1);
                }
            }
        }
    }

    /** Двойная пирамида над головой, вращается вокруг вертикальной оси. */
    private static void diamond(DrawContext ctx, double x, double y, double z, double time, int c0, int c1) {
        double[] top = Project.project(x, y + 0.28, z);
        double[] bot = Project.project(x, y - 0.28, z);
        if (top == null || bot == null) {
            return;
        }
        double[][] m = new double[4][];
        for (int i = 0; i < 4; i++) {
            double a = time * 2 + i * Math.PI / 2;
            m[i] = Project.project(x + Math.cos(a) * 0.22, y, z + Math.sin(a) * 0.22);
            if (m[i] == null) {
                return;
            }
        }
        for (int i = 0; i < 4; i++) {
            Render.line(ctx, top[0], top[1], m[i][0], m[i][1], c0, 1);
            Render.line(ctx, bot[0], bot[1], m[i][0], m[i][1], c1, 1);
            Render.line(ctx, m[i][0], m[i][1], m[(i + 1) % 4][0], m[(i + 1) % 4][1], c0, 1);
        }
    }

    private static void crosshair(DrawContext ctx, double x, double y, double z, double time, int c) {
        double[] s = Project.project(x, y, z);
        if (s == null) {
            return;
        }
        double r = MathHelper.clamp(Project.scaleAt(s[2]) * 0.45, 8, 50);
        double rot = time * 1.5;
        for (int i = 0; i < 4; i++) {
            double a = rot + i * Math.PI / 2;
            double ca = Math.cos(a);
            double sa = Math.sin(a);
            Render.line(ctx, s[0] + ca * r * 0.45, s[1] + sa * r * 0.45, s[0] + ca * r, s[1] + sa * r, c, 2);
        }
        Render.fill(ctx, (int) s[0] - 1, (int) s[1] - 1, (int) s[0] + 2, (int) s[1] + 2, c);
    }
}
