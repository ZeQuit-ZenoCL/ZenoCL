package dev.zenocl.modules.visual;

import dev.zenocl.hud.HudModule;
import dev.zenocl.hud.Render;
import dev.zenocl.util.Targets;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;

public class TargetInfo extends HudModule {
    private float shown;

    public TargetInfo() {
        super("TargetInfo");
    }

    @Override
    public void render(DrawContext ctx, int sw, int sh) {
        LivingEntity t = Targets.recent();
        if (t == null && editing) {
            t = net.minecraft.client.MinecraftClient.getInstance().player; // заглушка, чтобы элемент можно было двигать
        }
        if (t == null) {
            return;
        }
        float hp = t.getHealth() + t.getAbsorptionAmount();
        float max = Math.max(1f, t.getMaxHealth());
        shown += (Math.min(1f, hp / max) - shown) * 0.12f;

        int w = 130, h = 34;
        int x = sw / 2 + 24, y = sh / 2 + 24;
        int[] pp = place(x, y, w, h, sw, sh);
        x = pp[0];
        y = pp[1];
        Render.rrect(ctx, x, y, w, h, Render.bg());
        Render.text(ctx, t.getName().getString(), x + 7, y + 6, Render.TEXT);
        Render.text(ctx, String.format("%.1f HP", hp), x + w - 7 - Render.width(String.format("%.1f HP", hp)), y + 6, Render.TEXT_DIM);

        int bx = x + 7, by = y + 21, bw = w - 14;
        Render.fill(ctx, bx, by, bx + bw, by + 5, Render.BG_LIGHT);
        int fill = (int) (bw * Math.max(0f, Math.min(1f, shown)));
        Render.gradient(ctx, bx, by, bx + fill, by + 5, Render.accent(0), Render.accent(1.5));
    }
}
