package dev.zenocl.modules.visual;

import dev.zenocl.hud.HudModule;
import dev.zenocl.hud.Render;
import dev.zenocl.util.Targets;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;

/**
 * Слева 2D-"голова" (квадрат с инициалом: настоящая текстура скина здесь не используется, чтобы не зависеть от смены API игры),
 * справа ник, под ником полоска здоровья без цифр, ниже броня цели.
 */
public class TargetInfo extends HudModule {
    private static final EquipmentSlot[] ARMOR = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    private float shown;
    private float appear;
    private long stamp = System.nanoTime();

    public TargetInfo() {
        super("TargetInfo");
    }

    @Override
    public void render(DrawContext ctx, int sw, int sh) {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - stamp) / 1e9f);
        stamp = now;
        LivingEntity t = Targets.recent();
        appear = t != null ? Math.min(1f, appear + dt * 6f) : Math.max(0f, appear - dt * 6f);
        if (t == null || appear <= 0.01f) {
            return;
        }
        float hp = t.getHealth() + t.getAbsorptionAmount();
        float max = Math.max(1f, t.getMaxHealth());
        shown += (Math.min(1f, hp / max) - shown) * Math.min(1f, dt * 8f);

        int w = 142;
        int h = 46;
        int x = sw / 2 + 24;
        int y = sh / 2 + 24;
        int[] pp = place(x, y, w, h, sw, sh);
        x = pp[0];
        y = pp[1] + (int) ((1f - appear) * 6f);
        float saved = Render.hudAlpha;
        Render.hudAlpha = saved * appear;

        Render.rrect(ctx, x, y, w, h, Render.bg());
        // голова
        int hx = x + 6;
        int hy = y + 7;
        Render.rrect(ctx, hx, hy, 32, 32, Render.BG_LIGHT);
        Render.gradient(ctx, hx + 1, hy + 1, hx + 31, hy + 31, Render.withAlpha(Render.accent(0), 0.55f), Render.withAlpha(Render.accent(1.5), 0.55f));
        String name = t.getName().getString();
        String ini = name.isEmpty() ? "?" : name.substring(0, 1).toUpperCase();
        Render.text(ctx, ini, hx + 16 - Render.width(ini) / 2, hy + 12, Render.TEXT);

        int tx = x + 44;
        Render.text(ctx, name, tx, y + 8, Render.TEXT);
        int bw = w - 44 - 8;
        int by = y + 21;
        Render.fill(ctx, tx, by, tx + bw, by + 5, Render.BG_LIGHT);
        int fill = (int) (bw * Math.max(0f, Math.min(1f, shown)));
        Render.gradient(ctx, tx, by, tx + fill, by + 5, Render.accent(0), Render.accent(1.5));

        // броня: четыре предмета уменьшенными иконками
        var m = ctx.getMatrices();
        for (int i = 0; i < ARMOR.length; i++) {
            ItemStack s = t.getEquippedStack(ARMOR[i]);
            if (s.isEmpty()) {
                continue;
            }
            m.pushMatrix();
            m.translate(tx + i * 14, y + 29);
            m.scale(0.75f, 0.75f);
            ctx.drawItem(s, 0, 0);
            m.popMatrix();
        }
        Render.hudAlpha = saved;
    }
}
