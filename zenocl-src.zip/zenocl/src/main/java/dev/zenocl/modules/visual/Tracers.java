package dev.zenocl.modules.visual;

import dev.zenocl.core.BoolSetting;
import dev.zenocl.core.ModeSetting;
import dev.zenocl.core.NumSetting;
import dev.zenocl.hud.HudModule;
import dev.zenocl.hud.Render;
import dev.zenocl.util.Friends;
import dev.zenocl.util.Project;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Линии от прицела или низа экрана к игрокам. Ближние ярче, дальние бледнее. Игроки позади камеры не рисуются (для них есть Arrows). */
public class Tracers extends HudModule {
    private static final int MAX_LINES = 16;

    private final NumSetting range = add(new NumSetting("Range", 80, 16, 200, 8));
    private final ModeSetting from = add(new ModeSetting("From", "Bottom", "Bottom", "Center"));
    private final ModeSetting target = add(new ModeSetting("Target", "Chest", "Feet", "Chest", "Head"));
    private final BoolSetting mobs = add(new BoolSetting("Mobs", false));

    public Tracers() {
        super("Tracers");
    }

    @Override
    public boolean movable() {
        return false;
    }

    @Override
    public void render(DrawContext ctx, int sw, int sh) {
        if (!Project.ready()) {
            return;
        }
        MinecraftClient mc = MinecraftClient.getInstance();
        double r = range.get();
        float yFrac = target.is("Feet") ? 0.05f : target.is("Head") ? 0.95f : 0.55f;
        int x0 = sw / 2;
        int y0 = from.is("Center") ? sh / 2 : sh;
        int drawn = 0;
        for (Entity e : mc.world.getEntities()) {
            if (drawn >= MAX_LINES) {
                break;
            }
            if (e == mc.player || !e.isAlive()) {
                continue;
            }
            boolean isPlayer = e instanceof PlayerEntity;
            if (!isPlayer && !(mobs.get() && e instanceof MobEntity)) {
                continue;
            }
            double dist = mc.player.distanceTo(e);
            if (dist > r) {
                continue;
            }
            Vec3d p = e.getLerpedPos(Project.partial());
            double[] s = Project.project(p.x, p.y + e.getHeight() * yFrac, p.z);
            if (s == null) {
                continue;
            }
            int color = !isPlayer ? 0xFFFFC857 : Friends.is(e.getName().getString()) ? 0xFF55FF77 : Render.accent(dist * 0.05);
            float fade = (float) Math.max(0.3, 1.0 - dist / r * 0.7);
            line(ctx, x0, y0, (int) s[0], (int) s[1], Render.withAlpha(color, fade));
            drawn++;
        }
    }

    /** Линия из квадратиков 2x2 с шагом 2 px: без матриц и шейдеров, длина ограничена, чтобы кадр не страдал. */
    private static void line(DrawContext ctx, int x0, int y0, int x1, int y1, int color) {
        double dx = x1 - x0;
        double dy = y1 - y0;
        int steps = (int) Math.min(600, Math.max(Math.abs(dx), Math.abs(dy)) / 2);
        if (steps < 1) {
            return;
        }
        for (int i = 0; i <= steps; i++) {
            int x = x0 + (int) (dx * i / steps);
            int y = y0 + (int) (dy * i / steps);
            Render.fill(ctx, x - 1, y - 1, x + 1, y + 1, color);
        }
    }
}
