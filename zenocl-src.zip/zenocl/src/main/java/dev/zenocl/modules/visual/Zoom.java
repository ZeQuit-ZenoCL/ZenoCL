package dev.zenocl.modules.visual;

import dev.zenocl.core.Category;
import dev.zenocl.core.Module;
import dev.zenocl.core.NumSetting;

/** Приближение через уменьшение FOV; при выключении возвращает прежнее значение. */
public class Zoom extends Module {
    private final NumSetting fov = add(new NumSetting("FOV", 40, 30, 60, 1));
    private int previous = 70;

    public Zoom() {
        super("Zoom", Category.VISUAL);
    }

    @Override
    public void onEnable() {
        previous = mc().options.getFov().getValue();
    }

    @Override
    public void onTick() {
        mc().options.getFov().setValue(fov.getInt());
    }

    @Override
    public void onDisable() {
        mc().options.getFov().setValue(previous);
    }
}
