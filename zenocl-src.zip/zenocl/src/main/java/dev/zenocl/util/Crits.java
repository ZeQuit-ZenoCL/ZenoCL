package dev.zenocl.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;

/** Условия критического удара в 1.21: падение, не на земле, не в воде/лестнице, не слепота, не спринт. */
public final class Crits {
    private Crits() {
    }

    public static boolean canCrit(ClientPlayerEntity p) {
        return p.fallDistance > 0.0f
                && !p.isOnGround()
                && !p.isClimbing()
                && !p.isTouchingWater()
                && !p.hasVehicle()
                && !p.hasStatusEffect(StatusEffects.BLINDNESS);
    }

    /** Снимает спринт сразу и на сервере (иначе пакет уйдёт уже после удара и крита не будет). */
    public static void unsprint(ClientPlayerEntity p) {
        if (!p.isSprinting()) {
            return;
        }
        p.setSprinting(false);
        var net = MinecraftClient.getInstance().getNetworkHandler();
        if (net != null) {
            net.sendPacket(new ClientCommandC2SPacket(p, ClientCommandC2SPacket.Mode.STOP_SPRINTING));
        }
    }
}
