package dev.zenocl.util;

import net.minecraft.util.math.MathHelper;

/**
 * Пошаговые режимы поворота, перенесённые из EvaWare (Aura): каждый тик берёт текущие углы и целевые и возвращает новые.
 * Это имитации "человеческого" поведения под конкретные серверные античиты, никакой гарантии обхода нет.
 * Упрощения относительно оригинала: проверки столкновения и блоков вокруг заменены флагом touching (хитбоксы касаются).
 */
public final class EvaRot {
    public static final String[] MODES = {"Snap", "Linear", "Matrix2", "Vulcan", "HolyWorld", "SpookyTime", "FunTime", "LonyGrief"};

    /** Состояние тика: tracing - луч по текущим углам попадает в цель; attack - удар возможен прямо сейчас. */
    public record Ctx(boolean tracing, boolean touching, boolean attack, boolean moving, int age, float dist, float reach, float playerYaw) {
    }

    // Universal
    private static float uLastYaw, uLastPitch;
    private static int uSwitch, uPitchDir, uJopa;
    // Matrix2
    private static float mLastYaw;
    // Spooky
    private static float sSlowYaw, sSlowPitch;
    // FunTime
    private static long ftLastAttack;
    private static boolean ftFirst = true;
    private static int ftAttackedTicks;
    private static int ftAttackCount;
    private static int ftId;
    private static float ftJitter;
    private static boolean ftPrevAttack;
    // LonyGrief
    private static int lTicks;
    private static int lNext = 8;
    private static float lYawMul, lPitchMul;

    private EvaRot() {
    }

    public static boolean has(String mode) {
        for (String m : MODES) {
            if (m.equals(mode)) {
                return true;
            }
        }
        return false;
    }

    private static float rnd(float a, float b) {
        return a + (float) Math.random() * (b - a);
    }

    private static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    /** @return {yaw, pitch} или null, если в этом тике менять углы не нужно (Snap без удара). */
    public static float[] step(String mode, float cy, float cp, float ty, float tp, Ctx c) {
        float yd = MathHelper.wrapDegrees(ty - cy);
        float pd = tp - cp;
        return switch (mode) {
            case "Snap" -> c.attack() ? new float[]{ty, tp} : null;
            case "Linear" -> linear(cy, cp, yd, pd);
            case "Matrix2" -> matrix(cy, cp, yd, pd, c);
            case "Vulcan" -> universal(cy, cp, yd, pd, 120f, 60f, false, false, c);
            case "HolyWorld" -> universal(cy, cp, yd, pd, rnd(125f, 155f), rnd(30f, 60f), true, true, c);
            case "SpookyTime" -> spooky(cy, cp, yd, pd, c);
            case "FunTime" -> funTime(cy, cp, ty, tp, c);
            case "LonyGrief" -> lony(cy, cp, yd, pd, c);
            default -> null;
        };
    }

    private static float[] linear(float cy, float cp, float yd, float pd) {
        float diff = (float) Math.hypot(Math.abs(yd), Math.abs(pd));
        if (diff < 1e-4f) {
            return new float[]{cy, cp};
        }
        float ly = Math.abs(yd / diff) * (180f / 9f);
        float lp = Math.abs(pd / diff) * (90f / 9f);
        return new float[]{cy + MathHelper.clamp(yd, -ly, ly), cp + MathHelper.clamp(pd, -lp, lp)};
    }

    private static float[] matrix(float cy, float cp, float yd, float pd, Ctx c) {
        float yawSpeed = rnd(58f, 60f);
        float pitchSpeed = c.attack() ? Math.abs(pd) : 0.333f;
        float pitchStep = Math.max(pd, 2f + (float) Math.random() * 2f);
        pd = pd > 0 ? pitchStep : -pitchStep;
        float jitter = 3f;
        if (Math.abs(yd - mLastYaw) >= jitter) {
            yd += yd > 0 ? jitter + 0.1f : -(jitter + 0.1f);
        }
        mLastYaw = yd;
        return new float[]{cy + MathHelper.clamp(yd, -yawSpeed, yawSpeed), cp + MathHelper.clamp(pd, -pitchSpeed, pitchSpeed)};
    }

    private static float[] universal(float cy, float cp, float yd, float pd, float maxYaw, float maxPitch, boolean spooky, boolean huly, Ctx c) {
        float my = maxYaw / 3f;
        float mp = maxPitch / 3f;
        if ((pd < 0f && uLastPitch > 0f) || (pd > 0f && uLastPitch < 0f)) {
            uSwitch = 0;
        } else {
            uSwitch++;
        }
        if (uSwitch == 0 && Math.abs(pd) > 5f) {
            pd = (pd - 1f) * 0.3f;
            mp *= 0.4f;
        }
        if (Math.abs(pd) < 0.05f) {
            pd -= (float) (Math.random() * 0.05f - 0.225f);
        }
        if (Math.abs(yd - uLastYaw) < 0.08f) {
            yd -= (float) (Math.random() * 0.15f - 0.125f);
        }
        if (Math.abs(pd) < 0.01f) {
            pd -= (float) (Math.random() * 0.01f - 0.005f);
        }
        float ay = Math.abs(yd);
        float ap = Math.abs(pd);
        if (ay > 15f && ap < 0.1f) {
            my *= 0.7f;
        }
        if (ay < 0.05f && ap < 0.05f) {
            my *= 1.1f;
            mp *= 1.1f;
        }
        if (yd > 1.25f && uLastYaw > 1.25f) {
            yd -= uLastYaw;
            my *= 3;
        }
        if (ay > 0.5f && ap < 0.05f) {
            my *= 0.7f;
            mp *= 1.05f;
        }
        if (ay > 20f && ap < 0.1f) {
            my *= 0.5f;
            mp *= 1.1f;
        }
        if (ay > 0.25f && ap > 0.25f && ap < 20f && ay < 20f) {
            my *= 0.95f;
            mp *= 0.85f;
        }
        if (ay > 0.1f && ap > 0.1f && ay < 20f && ap < 20f) {
            my *= 0.9f;
            mp *= 0.8f;
        }
        if (ay > 0.75f && ap > 0.75f) {
            my *= 0.8f;
            mp *= 0.75f;
        }
        int dir = pd > 0 ? 1 : -1;
        if (uPitchDir != 0 && dir != uPitchDir) {
            mp *= 0.2f;
        }
        uPitchDir = dir;
        if (spooky) {
            if (c.touching()) {
                float k = huly ? 13f : 30f;
                pd /= k;
                yd /= k;
                uJopa = 20;
            }
            if (!huly && !c.touching()) {
                my *= c.tracing() ? 1.1f : 1.25f;
                mp *= c.tracing() ? 1.3f : 1.1f;
            }
            if (uJopa-- > 0) {
                float d = Math.max(1f, (uJopa / 20f) * 15f);
                yd /= d;
                pd /= d;
            }
        }
        uLastYaw = yd;
        uLastPitch = pd;
        return new float[]{cy + MathHelper.clamp(yd, -my, my), cp + MathHelper.clamp(pd, -mp, mp)};
    }

    private static float[] spooky(float cy, float cp, float yd, float pd, Ctx c) {
        float reach = Math.max(1f, c.reach());
        float df = MathHelper.clamp(0.3f + 0.7f * (c.dist() / reach), 0f, 1f);
        float tr = c.tracing() ? 0.4f : 1f;
        if (c.touching()) {
            yd /= 30f;
        }
        float rand = rnd(0.5f, 0.7f);
        float ys = rnd(25f, 31f);
        float ps = rnd(6f, 7.5f);
        if (c.tracing()) {
            sSlowYaw = lerp(sSlowYaw, 0.7f, 0.6f);
            sSlowPitch = lerp(sSlowPitch, 0.5f, 0.5f);
        } else {
            sSlowYaw = lerp(sSlowYaw, 1f, 0.9f);
            sSlowPitch = lerp(sSlowPitch, 1f, 0.2f);
        }
        ys *= sSlowYaw;
        ps *= sSlowPitch;
        long t = System.currentTimeMillis();
        yd += (float) (Math.cos(t / 50.0) * (3f * df));
        pd += (float) (Math.sin(t / 60.0) * (9f * df));
        return new float[]{
                cy + MathHelper.clamp(yd, -ys, ys) * rand,
                cp + MathHelper.clamp(pd, -ps, ps) * rand / Math.max(0.5f, ys) * 14f * tr};
    }

    private static float[] funTime(float cy, float cp, float ty, float tp, Ctx c) {
        if (c.attack() && !ftPrevAttack) {
            ftAttackCount++;
            if (ftFirst && ftAttackCount >= 2) {
                ftFirst = false;
                ftAttackCount = 0;
            }
            ftJitter = rnd(5f, 15f);
            ftLastAttack = System.currentTimeMillis();
            ftId = Math.random() < 0.5 ? 0 : 1;
            ftAttackedTicks = (int) rnd(12f, 16f) * 3;
        }
        ftPrevAttack = c.attack();
        if (ftAttackedTicks > 0) {
            ftAttackedTicks--;
        }
        long since = System.currentTimeMillis() - ftLastAttack;
        boolean intensive = since < 500;
        boolean late = since > 800;
        if (!c.moving() && !c.attack() && ftAttackedTicks > 27) {
            float power = 45f + ftJitter;
            ty += ftFirst ? 0f : ftId == 0 ? -power : power;
        }
        float swing = (float) (Math.sin(c.age() * 0.9f) * rnd(16.8f, 17.1f));
        float ys = 69f / 3f;
        float ps = 15f / 3f;
        if (late) {
            ftFirst = true;
            ty = c.playerYaw();
            ys *= 0.2f;
        }
        float yd = MathHelper.wrapDegrees(ty - cy);
        float pd = tp - cp;
        boolean glitch = !c.attack() && intensive && c.moving();
        float fy = glitch ? swing / 3f : yd + swing;
        float fp = glitch ? 0f : pd;
        return new float[]{cy + MathHelper.clamp(fy, -ys, ys), cp + MathHelper.clamp(fp, -ps, ps)};
    }

    private static float[] lony(float cy, float cp, float yd, float pd, Ctx c) {
        float acc = 0.03f;
        if (Math.abs(yd) > 15f) {
            acc = rnd(0.06f, 0.32f);
            yd *= 1.5f;
        }
        if (!c.tracing()) {
            lYawMul = lerp(lYawMul, 1f, acc);
            lPitchMul = lerp(lPitchMul, 1f, acc);
        } else {
            lYawMul = lerp(lYawMul, 0f, 0.55f);
            lPitchMul = lerp(lPitchMul, 0f, 0.55f);
        }
        float by = rnd(38f, 48f);
        float bp = rnd(12f, 19f);
        float df = MathHelper.clamp(Math.abs(yd) / 15f, 0.2f, 1f);
        float ys = by * lYawMul * lYawMul * (3 - 2 * lYawMul) * df;
        float ps = bp * lPitchMul * lPitchMul * (3 - 2 * lPitchMul);
        long t = System.currentTimeMillis();
        if (Math.abs(yd) > 5f) {
            yd += (float) Math.sin(t / 20.0) * 5f;
        }
        if (Math.abs(pd) > 3f) {
            pd += (float) Math.cos(t / 20.0) * 155.5f;
        }
        if (++lTicks >= lNext) {
            if (Math.abs(yd) <= 15f && c.tracing()) {
                yd *= rnd(0.4f, 0.8f);
                pd *= rnd(0.5f, 0.9f);
            }
            lTicks = 0;
            lNext = 4 + (int) (Math.random() * 7);
        }
        float dy = MathHelper.clamp(yd, -ys, ys);
        float dp = MathHelper.clamp(pd, -ps, ps);
        if (c.tracing() && Math.abs(dy) < 0.2f) {
            dy = 0f;
        }
        return new float[]{cy + dy, cp + dp};
    }
}
