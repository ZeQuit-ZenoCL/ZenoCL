package dev.zenocl.util;

import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Set;

/** Друзья: их не атакуют KillAura, TriggerBot, AimAssist, AutoCrystal и TargetStrafe. */
public final class Friends {
    private static final Set<String> NAMES = new LinkedHashSet<>();

    private Friends() {
    }

    public static boolean is(String name) {
        return NAMES.contains(name.toLowerCase());
    }

    public static boolean add(String name) {
        return NAMES.add(name.toLowerCase());
    }

    public static boolean remove(String name) {
        return NAMES.remove(name.toLowerCase());
    }

    public static void clear() {
        NAMES.clear();
    }

    public static Set<String> all() {
        return NAMES;
    }

    public static String serialize() {
        return String.join(",", NAMES);
    }

    public static void load(String s) {
        NAMES.clear();
        Arrays.stream(s.split(",")).map(String::trim).filter(x -> !x.isEmpty()).forEach(x -> NAMES.add(x.toLowerCase()));
    }
}
