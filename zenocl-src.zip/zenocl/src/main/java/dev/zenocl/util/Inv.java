package dev.zenocl.util;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;

public final class Inv {
    private Inv() {
    }

    /** Слот хотбара (0-8) с предметом или -1. */
    public static int findHotbar(ClientPlayerEntity p, Item item) {
        for (int i = 0; i < 9; i++) {
            if (p.getInventory().getStack(i).isOf(item)) {
                return i;
            }
        }
        return -1;
    }

    /** Индекс слота инвентаря (0-35) с предметом или -1. */
    public static int findAny(ClientPlayerEntity p, Item item) {
        for (int i = 0; i < 36; i++) {
            if (p.getInventory().getStack(i).isOf(item)) {
                return i;
            }
        }
        return -1;
    }

    /** Преобразует индекс инвентаря в слот playerScreenHandler. */
    public static int toScreenSlot(int invIndex) {
        return invIndex < 9 ? invIndex + 36 : invIndex;
    }

    public static int count(ClientPlayerEntity p, Item item) {
        int n = 0;
        for (int i = 0; i < 36; i++) {
            if (p.getInventory().getStack(i).isOf(item)) {
                n += p.getInventory().getStack(i).getCount();
            }
        }
        if (p.getOffHandStack().isOf(item)) {
            n += p.getOffHandStack().getCount();
        }
        return n;
    }

    public static String path(ItemStack s) {
        return Registries.ITEM.getId(s.getItem()).getPath();
    }

    /** Уровень материала по имени предмета: netherite 5 ... wooden/leather 0. */
    public static int tier(String path) {
        if (path.startsWith("netherite_")) return 5;
        if (path.startsWith("diamond_")) return 4;
        if (path.startsWith("iron_")) return 3;
        if (path.startsWith("stone_") || path.startsWith("chainmail_")) return 2;
        if (path.startsWith("golden_") || path.startsWith("turtle_")) return 1;
        return 0;
    }

    public static boolean isWeapon(ItemStack s) {
        String p = path(s);
        return p.endsWith("_sword") || p.endsWith("_axe");
    }

    /** Лучший по материалу предмет в хотбаре с таким суффиксом (например "_sword") или -1. */
    public static int findBestHotbar(ClientPlayerEntity p, String suffix) {
        int best = -1;
        int bestTier = -1;
        for (int i = 0; i < 9; i++) {
            String path = path(p.getInventory().getStack(i));
            if (path.endsWith(suffix) && tier(path) > bestTier) {
                bestTier = tier(path);
                best = i;
            }
        }
        return best;
    }
}
