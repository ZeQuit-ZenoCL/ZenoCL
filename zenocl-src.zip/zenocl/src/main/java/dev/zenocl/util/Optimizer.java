package dev.zenocl.util;

import dev.zenocl.modules.misc.ClientSettings;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.particle.ParticlesMode;

import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/**
 * Оптимизация настроек Minecraft одной галочкой (Client -> Optimize). Перед применением старые значения сохраняются
 * в config/zenocl-options-backup.properties, поэтому выключение галочки (даже после перезапуска игры) возвращает всё как было.
 * Трогаются только настройки, влияющие на FPS: дальность прорисовки и симуляции, частицы, тени сущностей и смешивание биомов.
 */
public final class Optimizer {
    private static final Path BACKUP = FabricLoader.getInstance().getConfigDir().resolve("zenocl-options-backup.properties");
    private static boolean applied;

    private Optimizer() {
    }

    /** Каждый тик: сравнивает галочку с тем, что применено. */
    public static void sync() {
        ClientSettings cs = ClientSettings.INSTANCE;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (cs == null || mc == null || mc.options == null) {
            return;
        }
        boolean want = cs.optimize.get();
        if (want == applied) {
            return;
        }
        applied = want;
        try {
            if (want) {
                apply(mc.options);
            } else {
                restore(mc.options);
            }
            mc.options.write();
        } catch (Exception ignored) {
            // настройки не критичны: при сбое просто остаются как есть
        }
    }

    private static void apply(GameOptions o) throws Exception {
        if (!Files.exists(BACKUP)) {
            Properties p = new Properties();
            p.setProperty("view", Integer.toString(o.getViewDistance().getValue()));
            p.setProperty("sim", Integer.toString(o.getSimulationDistance().getValue()));
            p.setProperty("particles", o.getParticles().getValue().name());
            p.setProperty("shadows", Boolean.toString(o.getEntityShadows().getValue()));
            p.setProperty("blend", Integer.toString(o.getBiomeBlendRadius().getValue()));
            try (Writer w = Files.newBufferedWriter(BACKUP, StandardCharsets.UTF_8)) {
                p.store(w, "ZenoCL: settings before optimization");
            }
        }
        o.getViewDistance().setValue(Math.min(o.getViewDistance().getValue(), 8));
        o.getSimulationDistance().setValue(Math.min(o.getSimulationDistance().getValue(), 6));
        o.getParticles().setValue(ParticlesMode.MINIMAL);
        o.getEntityShadows().setValue(false);
        o.getBiomeBlendRadius().setValue(0);
    }

    private static void restore(GameOptions o) throws Exception {
        if (!Files.exists(BACKUP)) {
            return;
        }
        Properties p = new Properties();
        try (Reader r = Files.newBufferedReader(BACKUP, StandardCharsets.UTF_8)) {
            p.load(r);
        }
        o.getViewDistance().setValue(Integer.parseInt(p.getProperty("view", "12")));
        o.getSimulationDistance().setValue(Integer.parseInt(p.getProperty("sim", "12")));
        o.getParticles().setValue(ParticlesMode.valueOf(p.getProperty("particles", "ALL")));
        o.getEntityShadows().setValue(Boolean.parseBoolean(p.getProperty("shadows", "true")));
        o.getBiomeBlendRadius().setValue(Integer.parseInt(p.getProperty("blend", "2")));
        Files.deleteIfExists(BACKUP);
    }
}
