package dev.zenocl.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * Проекция мировых точек на экран для 2D-визуалов. Камера считается так же, как в игре: позиция и углы игрока
 * по настоящему прогрессу тика этого кадра, высота глаз и множитель FOV сглаживаются по тикам как в ванили.
 * Покачивание камеры при ходьбе в проекцию не входит, поэтому пока работают эти визуалы, view bobbing выключается
 * (настройка Client -> NoBobbing) и потом возвращается. В виде от третьего лица проекция отключена.
 */
public final class Project {
    private static float tp;
    private static boolean ok;
    private static boolean inited;
    private static int sw;
    private static int sh;
    private static double cx, cy, cz;
    private static double fx, fy, fz, rx, rz, ux, uy, uz;
    private static double k;
    private static float fm, lastFm, camY, lastCamY;
    private static long lastUse;
    private static boolean bobForced;
    private static boolean bobWas;

    private Project() {
    }

    /** Модуль, которому нужна точная проекция, зовёт это каждый кадр. */
    public static void use() {
        lastUse = System.currentTimeMillis();
    }

    public static float partial() {
        return tp;
    }

    public static boolean ready() {
        return ok;
    }

    /** Каждый клиентский тик: сглаживание FOV и высоты глаз как в Camera/GameRenderer, управление bobbing. */
    public static void tick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        var p = mc.player;
        if (p == null) {
            inited = false;
            return;
        }
        float walk = p.getAbilities().getWalkSpeed();
        float target = 1f;
        if (walk > 0f && Float.isFinite(walk)) {
            target = (p.getMovementSpeed() / walk + 1f) / 2f;
            if (p.getAbilities().flying) {
                target *= 1.1f;
            }
        }
        target = MathHelper.clamp(target, 0.1f, 1.5f);
        float eye = p.getEyeHeight();
        if (!inited) {
            fm = lastFm = target;
            camY = lastCamY = eye;
            inited = true;
        }
        lastFm = fm;
        fm += (target - fm) * 0.5f;
        lastCamY = camY;
        camY += (eye - camY) * 0.5f;

        boolean want = System.currentTimeMillis() - lastUse < 500
                && dev.zenocl.modules.misc.ClientSettings.INSTANCE != null
                && dev.zenocl.modules.misc.ClientSettings.INSTANCE.noBobbing.get();
        var bob = mc.options.getBobView();
        if (want && !bobForced) {
            bobWas = bob.getValue();
            bob.setValue(false);
            bobForced = true;
        } else if (!want && bobForced) {
            bob.setValue(bobWas);
            bobForced = false;
        }
    }

    /** Один раз за кадр перед отрисовкой визуалов; progress - прогресс тика этого кадра. */
    public static void begin(MinecraftClient mc, int width, int height, float progress) {
        ok = false;
        var p = mc.player;
        if (p == null || !inited || !mc.options.getPerspective().isFirstPerson()) {
            return;
        }
        tp = progress;
        sw = width;
        sh = height;
        Vec3d pos = p.getLerpedPos(tp);
        cx = pos.x;
        cy = pos.y + MathHelper.lerp(tp, lastCamY, camY);
        cz = pos.z;
        double yaw = Math.toRadians(p.getYaw(tp));
        double pitch = Math.toRadians(p.getPitch(tp));
        double sy = Math.sin(yaw), cyw = Math.cos(yaw), sp = Math.sin(pitch), cp = Math.cos(pitch);
        fx = -sy * cp;
        fy = -sp;
        fz = cyw * cp;
        rx = -cyw;
        rz = -sy;
        ux = -sy * sp;
        uy = cp;
        uz = cyw * sp;
        double fov = mc.options.getFov().getValue() * MathHelper.lerp(tp, lastFm, fm);
        k = (height / 2.0) / Math.tan(Math.toRadians(fov) / 2.0);
        ok = true;
    }

    /** {экранный x, экранный y, глубина} или null, если точка позади камеры. */
    public static double[] project(double x, double y, double z) {
        double dx = x - cx;
        double dy = y - cy;
        double dz = z - cz;
        double depth = dx * fx + dy * fy + dz * fz;
        if (depth < 0.05) {
            return null;
        }
        double right = dx * rx + dz * rz;
        double up = dx * ux + dy * uy + dz * uz;
        return new double[]{sw / 2.0 + right / depth * k, sh / 2.0 - up / depth * k, depth};
    }

    /** Масштаб в пикселях на 1 блок на данной глубине. */
    public static double scaleAt(double depth) {
        return k / depth;
    }

    /** Экранный прямоугольник хитбокса {minX, minY, maxX, maxY} или null (позади камеры / вне экрана). */
    public static double[] box(Entity e) {
        Vec3d pos = e.getLerpedPos(tp);
        double hw = e.getWidth() / 2.0;
        double h = e.getHeight();
        double minX = Double.MAX_VALUE, minY = Double.MAX_VALUE, maxX = -Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
        for (int i = 0; i < 8; i++) {
            double[] s = project(pos.x + ((i & 1) == 0 ? -hw : hw), pos.y + ((i & 2) == 0 ? 0 : h), pos.z + ((i & 4) == 0 ? -hw : hw));
            if (s == null) {
                return null;
            }
            minX = Math.min(minX, s[0]);
            maxX = Math.max(maxX, s[0]);
            minY = Math.min(minY, s[1]);
            maxY = Math.max(maxY, s[1]);
        }
        if (maxX < 0 || minX > sw || maxY < 0 || minY > sh) {
            return null;
        }
        return new double[]{minX, minY, maxX, maxY};
    }
}
