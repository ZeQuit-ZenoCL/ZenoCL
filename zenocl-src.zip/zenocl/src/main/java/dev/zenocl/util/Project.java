package dev.zenocl.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;

/**
 * Проекция мировых точек на экран для 2D-визуалов (ESP-рамки, трассеры, стрелки).
 * Матрицы рендера не используются, камера считается по игроку, поэтому точность приблизительная:
 * не учитываются подводный/«низкое здоровье» эффекты FOV и сторонние моды на камеру. Поправка FOV от
 * скорости (спринт, зелье) считается так же, как в ванили. В виде от третьего лица проекция отключена.
 */
public final class Project {
    private static long tickStamp = System.nanoTime();
    private static long lastFrame = System.nanoTime();
    private static float fovMult = 1f;
    private static boolean ok;
    private static int sw;
    private static int sh;
    private static double cx, cy, cz;       // позиция камеры
    private static double fx, fy, fz;       // вперёд
    private static double rx, rz;           // вправо (по y = 0)
    private static double ux, uy, uz;       // вверх
    private static double k;                // пикселей на единицу tan

    private Project() {
    }

    /** Вызывается каждый клиентский тик: от этого момента считается доля тика для интерполяции. */
    public static void tick() {
        tickStamp = System.nanoTime();
    }

    public static float partial() {
        return Math.max(0f, Math.min(1f, (System.nanoTime() - tickStamp) / 5.0e7f));
    }

    public static boolean ready() {
        return ok;
    }

    /** Один раз за кадр перед отрисовкой визуалов. */
    public static void begin(MinecraftClient mc, int width, int height) {
        ok = false;
        var p = mc.player;
        if (p == null || !mc.options.getPerspective().isFirstPerson()) {
            return;
        }
        sw = width;
        sh = height;
        Vec3d pos = p.getLerpedPos(partial());
        cx = pos.x;
        cy = pos.y + (p.getEyeY() - p.getY());
        cz = pos.z;

        double yaw = Math.toRadians(p.getYaw());
        double pitch = Math.toRadians(p.getPitch());
        double sy = Math.sin(yaw), cyw = Math.cos(yaw), sp = Math.sin(pitch), cp = Math.cos(pitch);
        fx = -sy * cp;
        fy = -sp;
        fz = cyw * cp;
        rx = -cyw;
        rz = -sy;
        ux = -sy * sp;
        uy = cp;
        uz = cyw * sp;

        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - lastFrame) / 1.0e9f);
        lastFrame = now;
        // как AbstractClientPlayerEntity.getFovMultiplier: FOV растёт со скоростью, игра сглаживает его по тикам
        float target = (p.getMovementSpeed() / 0.1f + 1f) / 2f;
        if (p.getAbilities().flying) {
            target *= 1.1f;
        }
        target = Math.max(0.5f, Math.min(2f, target));
        fovMult += (target - fovMult) * (1f - (float) Math.exp(-dt * 14f));
        double fov = Math.toRadians(mc.options.getFov().getValue() * fovMult);
        k = (height / 2.0) / Math.tan(fov / 2.0);
        ok = true;
    }

    /** {экранный x, экранный y, глубина} или null, если точка позади камеры. */
    public static double[] project(double x, double y, double z) {
        double dx = x - cx;
        double dy = y - cy;
        double dz = z - cz;
        double depth = dx * fx + dy * fy + dz * fz;
        if (depth < 0.05) {
            return null;
        }
        double right = dx * rx + dz * rz;
        double up = dx * ux + dy * uy + dz * uz;
        return new double[]{sw / 2.0 + right / depth * k, sh / 2.0 - up / depth * k, depth};
    }

    /** Экранный прямоугольник хитбокса {minX, minY, maxX, maxY} или null (позади камеры / вне экрана). */
    public static double[] box(Entity e) {
        Vec3d pos = e.getLerpedPos(partial());
        double hw = e.getWidth() / 2.0;
        double h = e.getHeight();
        double minX = Double.MAX_VALUE, minY = Double.MAX_VALUE, maxX = -Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
        for (int i = 0; i < 8; i++) {
            double[] s = project(pos.x + ((i & 1) == 0 ? -hw : hw), pos.y + ((i & 2) == 0 ? 0 : h), pos.z + ((i & 4) == 0 ? -hw : hw));
            if (s == null) {
                return null;
            }
            minX = Math.min(minX, s[0]);
            maxX = Math.max(maxX, s[0]);
            minY = Math.min(minY, s[1]);
            maxY = Math.max(maxY, s[1]);
        }
        if (maxX < 0 || minX > sw || maxY < 0 || minY > sh) {
            return null;
        }
        return new double[]{minX, minY, maxX, maxY};
    }
}
