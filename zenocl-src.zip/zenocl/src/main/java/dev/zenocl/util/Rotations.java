package dev.zenocl.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class Rotations {
    private Rotations() {
    }

    public static float[] to(Vec3d from, Vec3d target) {
        double dx = target.x - from.x;
        double dy = target.y - from.y;
        double dz = target.z - from.z;
        double flat = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, flat));
        return new float[]{yaw, MathHelper.clamp(pitch, -90f, 90f)};
    }

    /** Режимы: Silent - углы только в пакетах (камера не двигается), Client - крутит камеру, None - не поворачивает. */
    public static void aim(ClientPlayerEntity p, Vec3d target, float maxStep, String mode) {
        if (mode.equalsIgnoreCase("Silent")) {
            SilentRot.aim(p, target, maxStep);
        } else if (mode.equalsIgnoreCase("Client")) {
            face(p, target, maxStep);
        }
    }

    /**
     * Плавный покадровый поворот: экспоненциальное сближение (быстро издалека, мягко у цели) по прямой линии
     * в пространстве углов, а не по осям отдельно. Потолок - maxDegPerSec; sharpness - резкость сближения (1/сек).
     */
    public static void faceSmooth(ClientPlayerEntity p, Vec3d target, float maxDegPerSec, float sharpness, float dt) {
        float[] r = to(p.getEyePos(), target);
        float dyaw = MathHelper.wrapDegrees(r[0] - p.getYaw());
        float dpitch = r[1] - p.getPitch();
        float d = (float) Math.hypot(dyaw, dpitch);
        if (d < 0.02f) {
            return;
        }
        // минимальная скорость 25 град/сек, чтобы у самой цели наведение не "залипало" на бесконечном затухании
        float step = Math.min(d, Math.min(maxDegPerSec * dt, d * (1f - (float) Math.exp(-sharpness * dt)) + 25f * dt));
        p.setYaw(p.getYaw() + dyaw / d * step);
        p.setPitch(MathHelper.clamp(p.getPitch() + dpitch / d * step, -90f, 90f));
    }

    private static float resYaw;
    private static float resPitch;

    public static void resetHuman() {
        resYaw = 0f;
        resPitch = 0f;
    }

    /**
     * Минимальный шаг поворота мыши в градусах при текущей чувствительности: в ваниле угол меняется только
     * кратно этому числу (дельта пикселей * (sens*0.6+0.2)^3 * 8 * 0.15). Поворот, не кратный шагу, отличает программу от мыши.
     */
    public static float gcdStep() {
        double f = MinecraftClient.getInstance().options.getMouseSensitivity().getValue() * 0.6 + 0.2;
        return (float) (f * f * f * 8.0 * 0.15);
    }

    /**
     * Человекоподобный покадровый поворот: сближение с затуханием по прямой в пространстве углов, шум скорости
     * (noise 0..1) и, при gcd, квантование под шаг мыши с накоплением остатка (мелкие кадровые шаги не пропадают, а копятся до целого шага).
     */
    public static void faceHuman(ClientPlayerEntity p, Vec3d target, float maxDegPerSec, float sharpness, float dt, float noise, boolean gcd) {
        float[] r = to(p.getEyePos(), target);
        float dyaw = MathHelper.wrapDegrees(r[0] - p.getYaw());
        float dpitch = r[1] - p.getPitch();
        float d = (float) Math.hypot(dyaw, dpitch);
        if (d < 0.02f) {
            return;
        }
        float step = Math.min(maxDegPerSec * dt, d * (1f - (float) Math.exp(-sharpness * dt)) + 25f * dt);
        if (noise > 0f) {
            step *= 1f + (float) ((Math.random() - 0.5) * 0.6 * noise);
        }
        step = Math.min(step, d);
        float ay = dyaw / d * step;
        float ap = dpitch / d * step;
        if (gcd) {
            float g = gcdStep();
            resYaw += ay;
            resPitch += ap;
            int ny = (int) (resYaw / g);
            int np = (int) (resPitch / g);
            ay = ny * g;
            ap = np * g;
            resYaw -= ay;
            resPitch -= ap;
        }
        if (ay == 0f && ap == 0f) {
            return;
        }
        p.setYaw(p.getYaw() + ay);
        p.setPitch(MathHelper.clamp(p.getPitch() + ap, -90f, 90f));
    }

    /** Поворачивает игрока к точке не быстрее maxStep градусов за тик. */
    public static void face(ClientPlayerEntity p, Vec3d target, float maxStep) {
        float[] r = to(p.getEyePos(), target);
        float dyaw = MathHelper.wrapDegrees(r[0] - p.getYaw());
        float dpitch = r[1] - p.getPitch();
        dyaw = MathHelper.clamp(dyaw, -maxStep, maxStep);
        dpitch = MathHelper.clamp(dpitch, -maxStep, maxStep);
        p.setYaw(p.getYaw() + dyaw);
        p.setPitch(MathHelper.clamp(p.getPitch() + dpitch, -90f, 90f));
    }
}
