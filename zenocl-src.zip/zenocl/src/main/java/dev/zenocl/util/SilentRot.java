package dev.zenocl.util;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * Тихие ротации: сервер получает повёрнутые углы в пакетах движения, а камера игрока не двигается.
 * Подмену углов делает ClientPlayerEntityMixin только на время отправки пакета.
 */
public final class SilentRot {
    /** Сколько отправок пакета держится подмена после последнего aim(). */
    private static final int HOLD_PACKETS = 2;
    private static float yaw;
    private static float pitch;
    private static int hold;
    // углы последнего отправленного пакета движения: именно их знает сервер в момент нашей атаки
    private static float lastYaw = Float.NaN;
    private static float lastPitch;

    private SilentRot() {
    }

    /** Поворот к цели не быстрее step градусов за тик, начиная с последних серверных углов. */
    public static void aim(ClientPlayerEntity p, Vec3d target, float step) {
        float[] want = Rotations.to(p.getEyePos(), target);
        float fromYaw = hold > 0 ? yaw : p.getYaw();
        float fromPitch = hold > 0 ? pitch : p.getPitch();
        float dy = MathHelper.clamp(MathHelper.wrapDegrees(want[0] - fromYaw), -step, step);
        float dp = MathHelper.clamp(want[1] - fromPitch, -step, step);
        yaw = fromYaw + dy;
        pitch = MathHelper.clamp(fromPitch + dp, -90f, 90f);
        hold = HOLD_PACKETS;
    }

    public static void sent(float y, float p) {
        lastYaw = y;
        lastPitch = p;
    }

    public static float serverYaw(ClientPlayerEntity p) {
        return Float.isNaN(lastYaw) ? p.getYaw() : lastYaw;
    }

    public static float serverPitch(ClientPlayerEntity p) {
        return Float.isNaN(lastYaw) ? p.getPitch() : lastPitch;
    }

    public static boolean active() {
        return hold > 0;
    }

    public static float yaw() {
        return yaw;
    }

    public static float pitch() {
        return pitch;
    }

    public static void consume() {
        if (hold > 0) {
            hold--;
        }
    }
}
