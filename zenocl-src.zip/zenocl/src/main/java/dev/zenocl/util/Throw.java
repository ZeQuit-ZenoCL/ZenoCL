package dev.zenocl.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.Hand;

/** Бросок/использование предмета из хотбара с временной сменой слота и (опционально) наклона головы. */
public final class Throw {
    private Throw() {
    }

    /** pitch == null - бросок по текущему взгляду. */
    public static void use(ClientPlayerEntity p, int slot, Float pitch) {
        int prevSlot = p.getInventory().getSelectedSlot();
        float prevPitch = p.getPitch();
        p.getInventory().setSelectedSlot(slot);
        if (pitch != null) {
            p.setPitch(pitch);
        }
        MinecraftClient.getInstance().interactionManager.interactItem(p, Hand.MAIN_HAND);
        p.getInventory().setSelectedSlot(prevSlot);
        if (pitch != null) {
            p.setPitch(prevPitch);
        }
    }
}
